System.register(['./store.base.developer.js'], function () {
  'use strict';
  var _export, addToUnscopables, arrayIncludes, functionBindContext, global_1, objectDefineProperty, objectGetPrototypeOf, wellKnownSymbol, uid, objectSetPrototypeOf, classof, createNonEnumerableProperty, descriptors, has, isObject, redefine, createCommonjsModule, unwrapExports, toIndexedObject, objectKeys, objectPropertyIsEnumerable, path, toPropertyKey, createPropertyDescriptor, ownKeys, objectGetOwnPropertyDescriptor, toString_1, requireObjectCoercible, toInteger, toLength, engineUserAgent, classofRaw, toObject, aFunction, iterate, fails, copyConstructorProperties, anObject, shared, objectCreate, internalState, stringMultibyte, createIteratorConstructor, speciesConstructor, getGlobalThis, indexedObject, objectGetOwnPropertySymbols, iteratorClose, getIteratorMethod, isArrayIteratorMethod, getBuiltIn, redefineAll, setToStringTag, anInstance, objectDefineProperties, runtimeLogger, getGlobal, isNumber, isArray$1, SyncCallManager, baseLibModuleBuilder, ReceiverType, isUndefined, getPromise, getFetch, Register, developLogger, ApiType, ModuleSnapshotType, isString, ApiCenter, CallbackHandler, GlobalEventHandler, SyncCallHandlerHandler, EventManagerClass, ReportTimer, codeTemplatePrefix, Reporter, isNonEmptyArray, FrameworkType;
  return {
    setters: [function (module) {
      _export = module._;
      addToUnscopables = module.a;
      arrayIncludes = module.b;
      functionBindContext = module.f;
      global_1 = module.g;
      objectDefineProperty = module.o;
      objectGetPrototypeOf = module.c;
      wellKnownSymbol = module.w;
      uid = module.u;
      objectSetPrototypeOf = module.d;
      classof = module.e;
      createNonEnumerableProperty = module.h;
      descriptors = module.i;
      has = module.j;
      isObject = module.k;
      redefine = module.r;
      createCommonjsModule = module.l;
      unwrapExports = module.m;
      toIndexedObject = module.t;
      objectKeys = module.n;
      objectPropertyIsEnumerable = module.p;
      path = module.q;
      toPropertyKey = module.s;
      createPropertyDescriptor = module.v;
      ownKeys = module.x;
      objectGetOwnPropertyDescriptor = module.y;
      toString_1 = module.z;
      requireObjectCoercible = module.A;
      toInteger = module.B;
      toLength = module.C;
      engineUserAgent = module.D;
      classofRaw = module.E;
      toObject = module.F;
      aFunction = module.G;
      iterate = module.H;
      fails = module.I;
      copyConstructorProperties = module.J;
      anObject = module.K;
      shared = module.L;
      objectCreate = module.M;
      internalState = module.N;
      stringMultibyte = module.O;
      createIteratorConstructor = module.P;
      speciesConstructor = module.Q;
      getGlobalThis = module.R;
      indexedObject = module.S;
      objectGetOwnPropertySymbols = module.T;
      iteratorClose = module.U;
      getIteratorMethod = module.V;
      isArrayIteratorMethod = module.W;
      getBuiltIn = module.X;
      redefineAll = module.Y;
      setToStringTag = module.Z;
      anInstance = module.$;
      objectDefineProperties = module.a0;
      runtimeLogger = module.a1;
      getGlobal = module.a2;
      isNumber = module.a3;
      isArray$1 = module.a4;
      SyncCallManager = module.a5;
      baseLibModuleBuilder = module.a6;
      ReceiverType = module.a7;
      isUndefined = module.a8;
      getPromise = module.a9;
      getFetch = module.aa;
      Register = module.ab;
      developLogger = module.ac;
      ApiType = module.ad;
      ModuleSnapshotType = module.ae;
      isString = module.af;
      ApiCenter = module.ag;
      CallbackHandler = module.ah;
      GlobalEventHandler = module.ai;
      SyncCallHandlerHandler = module.aj;
      EventManagerClass = module.ak;
      ReportTimer = module.al;
      codeTemplatePrefix = module.am;
      Reporter = module.an;
      isNonEmptyArray = module.ao;
      FrameworkType = module.ap;
    }],
    execute: function () {

      var isPure = false;

      var $includes$1 = arrayIncludes.includes;


      // `Array.prototype.includes` method
      // https://tc39.es/ecma262/#sec-array.prototype.includes
      _export({ target: 'Array', proto: true }, {
        includes: function includes(el /* , fromIndex = 0 */) {
          return $includes$1(this, el, arguments.length > 1 ? arguments[1] : undefined);
        }
      });

      // https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
      addToUnscopables('includes');

      var call = Function.call;

      var entryUnbind = function (CONSTRUCTOR, METHOD, length) {
        return functionBindContext(call, global_1[CONSTRUCTOR].prototype[METHOD], length);
      };

      entryUnbind('Array', 'includes');

      // eslint-disable-next-line es/no-typed-arrays -- safe
      var arrayBufferNative = typeof ArrayBuffer !== 'undefined' && typeof DataView !== 'undefined';

      var defineProperty$3 = objectDefineProperty.f;





      var Int8Array = global_1.Int8Array;
      var Int8ArrayPrototype = Int8Array && Int8Array.prototype;
      var Uint8ClampedArray = global_1.Uint8ClampedArray;
      var Uint8ClampedArrayPrototype = Uint8ClampedArray && Uint8ClampedArray.prototype;
      var TypedArray = Int8Array && objectGetPrototypeOf(Int8Array);
      var TypedArrayPrototype = Int8ArrayPrototype && objectGetPrototypeOf(Int8ArrayPrototype);
      var ObjectPrototype = Object.prototype;
      var isPrototypeOf = ObjectPrototype.isPrototypeOf;

      var TO_STRING_TAG = wellKnownSymbol('toStringTag');
      var TYPED_ARRAY_TAG = uid('TYPED_ARRAY_TAG');
      var TYPED_ARRAY_CONSTRUCTOR = uid('TYPED_ARRAY_CONSTRUCTOR');
      // Fixing native typed arrays in Opera Presto crashes the browser, see #595
      var NATIVE_ARRAY_BUFFER_VIEWS = arrayBufferNative && !!objectSetPrototypeOf && classof(global_1.opera) !== 'Opera';
      var TYPED_ARRAY_TAG_REQIRED = false;
      var NAME, Constructor, Prototype;

      var TypedArrayConstructorsList = {
        Int8Array: 1,
        Uint8Array: 1,
        Uint8ClampedArray: 1,
        Int16Array: 2,
        Uint16Array: 2,
        Int32Array: 4,
        Uint32Array: 4,
        Float32Array: 4,
        Float64Array: 8
      };

      var BigIntArrayConstructorsList = {
        BigInt64Array: 8,
        BigUint64Array: 8
      };

      var isView = function isView(it) {
        if (!isObject(it)) return false;
        var klass = classof(it);
        return klass === 'DataView'
          || has(TypedArrayConstructorsList, klass)
          || has(BigIntArrayConstructorsList, klass);
      };

      var isTypedArray = function (it) {
        if (!isObject(it)) return false;
        var klass = classof(it);
        return has(TypedArrayConstructorsList, klass)
          || has(BigIntArrayConstructorsList, klass);
      };

      var aTypedArray$1 = function (it) {
        if (isTypedArray(it)) return it;
        throw TypeError('Target is not a typed array');
      };

      var aTypedArrayConstructor = function (C) {
        if (objectSetPrototypeOf && !isPrototypeOf.call(TypedArray, C)) {
          throw TypeError('Target is not a typed array constructor');
        } return C;
      };

      var exportTypedArrayMethod$1 = function (KEY, property, forced) {
        if (!descriptors) return;
        if (forced) for (var ARRAY in TypedArrayConstructorsList) {
          var TypedArrayConstructor = global_1[ARRAY];
          if (TypedArrayConstructor && has(TypedArrayConstructor.prototype, KEY)) try {
            delete TypedArrayConstructor.prototype[KEY];
          } catch (error) { /* empty */ }
        }
        if (!TypedArrayPrototype[KEY] || forced) {
          redefine(TypedArrayPrototype, KEY, forced ? property
            : NATIVE_ARRAY_BUFFER_VIEWS && Int8ArrayPrototype[KEY] || property);
        }
      };

      var exportTypedArrayStaticMethod = function (KEY, property, forced) {
        var ARRAY, TypedArrayConstructor;
        if (!descriptors) return;
        if (objectSetPrototypeOf) {
          if (forced) for (ARRAY in TypedArrayConstructorsList) {
            TypedArrayConstructor = global_1[ARRAY];
            if (TypedArrayConstructor && has(TypedArrayConstructor, KEY)) try {
              delete TypedArrayConstructor[KEY];
            } catch (error) { /* empty */ }
          }
          if (!TypedArray[KEY] || forced) {
            // V8 ~ Chrome 49-50 `%TypedArray%` methods are non-writable non-configurable
            try {
              return redefine(TypedArray, KEY, forced ? property : NATIVE_ARRAY_BUFFER_VIEWS && TypedArray[KEY] || property);
            } catch (error) { /* empty */ }
          } else return;
        }
        for (ARRAY in TypedArrayConstructorsList) {
          TypedArrayConstructor = global_1[ARRAY];
          if (TypedArrayConstructor && (!TypedArrayConstructor[KEY] || forced)) {
            redefine(TypedArrayConstructor, KEY, property);
          }
        }
      };

      for (NAME in TypedArrayConstructorsList) {
        Constructor = global_1[NAME];
        Prototype = Constructor && Constructor.prototype;
        if (Prototype) createNonEnumerableProperty(Prototype, TYPED_ARRAY_CONSTRUCTOR, Constructor);
        else NATIVE_ARRAY_BUFFER_VIEWS = false;
      }

      for (NAME in BigIntArrayConstructorsList) {
        Constructor = global_1[NAME];
        Prototype = Constructor && Constructor.prototype;
        if (Prototype) createNonEnumerableProperty(Prototype, TYPED_ARRAY_CONSTRUCTOR, Constructor);
      }

      // WebKit bug - typed arrays constructors prototype is Object.prototype
      if (!NATIVE_ARRAY_BUFFER_VIEWS || typeof TypedArray != 'function' || TypedArray === Function.prototype) {
        // eslint-disable-next-line no-shadow -- safe
        TypedArray = function TypedArray() {
          throw TypeError('Incorrect invocation');
        };
        if (NATIVE_ARRAY_BUFFER_VIEWS) for (NAME in TypedArrayConstructorsList) {
          if (global_1[NAME]) objectSetPrototypeOf(global_1[NAME], TypedArray);
        }
      }

      if (!NATIVE_ARRAY_BUFFER_VIEWS || !TypedArrayPrototype || TypedArrayPrototype === ObjectPrototype) {
        TypedArrayPrototype = TypedArray.prototype;
        if (NATIVE_ARRAY_BUFFER_VIEWS) for (NAME in TypedArrayConstructorsList) {
          if (global_1[NAME]) objectSetPrototypeOf(global_1[NAME].prototype, TypedArrayPrototype);
        }
      }

      // WebKit bug - one more object in Uint8ClampedArray prototype chain
      if (NATIVE_ARRAY_BUFFER_VIEWS && objectGetPrototypeOf(Uint8ClampedArrayPrototype) !== TypedArrayPrototype) {
        objectSetPrototypeOf(Uint8ClampedArrayPrototype, TypedArrayPrototype);
      }

      if (descriptors && !has(TypedArrayPrototype, TO_STRING_TAG)) {
        TYPED_ARRAY_TAG_REQIRED = true;
        defineProperty$3(TypedArrayPrototype, TO_STRING_TAG, { get: function () {
          return isObject(this) ? this[TYPED_ARRAY_TAG] : undefined;
        } });
        for (NAME in TypedArrayConstructorsList) if (global_1[NAME]) {
          createNonEnumerableProperty(global_1[NAME], TYPED_ARRAY_TAG, NAME);
        }
      }

      var arrayBufferViewCore = {
        NATIVE_ARRAY_BUFFER_VIEWS: NATIVE_ARRAY_BUFFER_VIEWS,
        TYPED_ARRAY_CONSTRUCTOR: TYPED_ARRAY_CONSTRUCTOR,
        TYPED_ARRAY_TAG: TYPED_ARRAY_TAG_REQIRED && TYPED_ARRAY_TAG,
        aTypedArray: aTypedArray$1,
        aTypedArrayConstructor: aTypedArrayConstructor,
        exportTypedArrayMethod: exportTypedArrayMethod$1,
        exportTypedArrayStaticMethod: exportTypedArrayStaticMethod,
        isView: isView,
        isTypedArray: isTypedArray,
        TypedArray: TypedArray,
        TypedArrayPrototype: TypedArrayPrototype
      };

      var $includes = arrayIncludes.includes;

      var aTypedArray = arrayBufferViewCore.aTypedArray;
      var exportTypedArrayMethod = arrayBufferViewCore.exportTypedArrayMethod;

      // `%TypedArray%.prototype.includes` method
      // https://tc39.es/ecma262/#sec-%typedarray%.prototype.includes
      exportTypedArrayMethod('includes', function includes(searchElement /* , fromIndex */) {
        return $includes(aTypedArray(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
      });

      var es2016ArrayInclude = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2016ArrayInclude);

      var propertyIsEnumerable = objectPropertyIsEnumerable.f;

      // `Object.{ entries, values }` methods implementation
      var createMethod$2 = function (TO_ENTRIES) {
        return function (it) {
          var O = toIndexedObject(it);
          var keys = objectKeys(O);
          var length = keys.length;
          var i = 0;
          var result = [];
          var key;
          while (length > i) {
            key = keys[i++];
            if (!descriptors || propertyIsEnumerable.call(O, key)) {
              result.push(TO_ENTRIES ? [key, O[key]] : O[key]);
            }
          }
          return result;
        };
      };

      var objectToArray = {
        // `Object.entries` method
        // https://tc39.es/ecma262/#sec-object.entries
        entries: createMethod$2(true),
        // `Object.values` method
        // https://tc39.es/ecma262/#sec-object.values
        values: createMethod$2(false)
      };

      var $values = objectToArray.values;

      // `Object.values` method
      // https://tc39.es/ecma262/#sec-object.values
      _export({ target: 'Object', stat: true }, {
        values: function values(O) {
          return $values(O);
        }
      });

      path.Object.values;

      var $entries = objectToArray.entries;

      // `Object.entries` method
      // https://tc39.es/ecma262/#sec-object.entries
      _export({ target: 'Object', stat: true }, {
        entries: function entries(O) {
          return $entries(O);
        }
      });

      path.Object.entries;

      var createProperty = function (object, key, value) {
        var propertyKey = toPropertyKey(key);
        if (propertyKey in object) objectDefineProperty.f(object, propertyKey, createPropertyDescriptor(0, value));
        else object[propertyKey] = value;
      };

      // `Object.getOwnPropertyDescriptors` method
      // https://tc39.es/ecma262/#sec-object.getownpropertydescriptors
      _export({ target: 'Object', stat: true, sham: !descriptors }, {
        getOwnPropertyDescriptors: function getOwnPropertyDescriptors(object) {
          var O = toIndexedObject(object);
          var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
          var keys = ownKeys(O);
          var result = {};
          var index = 0;
          var key, descriptor;
          while (keys.length > index) {
            descriptor = getOwnPropertyDescriptor(O, key = keys[index++]);
            if (descriptor !== undefined) createProperty(result, key, descriptor);
          }
          return result;
        }
      });

      path.Object.getOwnPropertyDescriptors;

      var es2017Object = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2017Object);

      // `String.prototype.repeat` method implementation
      // https://tc39.es/ecma262/#sec-string.prototype.repeat
      var stringRepeat = function repeat(count) {
        var str = toString_1(requireObjectCoercible(this));
        var result = '';
        var n = toInteger(count);
        if (n < 0 || n == Infinity) throw RangeError('Wrong number of repetitions');
        for (;n > 0; (n >>>= 1) && (str += str)) if (n & 1) result += str;
        return result;
      };

      // https://github.com/tc39/proposal-string-pad-start-end





      var ceil = Math.ceil;

      // `String.prototype.{ padStart, padEnd }` methods implementation
      var createMethod$1 = function (IS_END) {
        return function ($this, maxLength, fillString) {
          var S = toString_1(requireObjectCoercible($this));
          var stringLength = S.length;
          var fillStr = fillString === undefined ? ' ' : toString_1(fillString);
          var intMaxLength = toLength(maxLength);
          var fillLen, stringFiller;
          if (intMaxLength <= stringLength || fillStr == '') return S;
          fillLen = intMaxLength - stringLength;
          stringFiller = stringRepeat.call(fillStr, ceil(fillLen / fillStr.length));
          if (stringFiller.length > fillLen) stringFiller = stringFiller.slice(0, fillLen);
          return IS_END ? S + stringFiller : stringFiller + S;
        };
      };

      var stringPad = {
        // `String.prototype.padStart` method
        // https://tc39.es/ecma262/#sec-string.prototype.padstart
        start: createMethod$1(false),
        // `String.prototype.padEnd` method
        // https://tc39.es/ecma262/#sec-string.prototype.padend
        end: createMethod$1(true)
      };

      // https://github.com/zloirock/core-js/issues/280


      // eslint-disable-next-line unicorn/no-unsafe-regex -- safe
      var stringPadWebkitBug = /Version\/10(?:\.\d+){1,2}(?: [\w./]+)?(?: Mobile\/\w+)? Safari\//.test(engineUserAgent);

      var $padStart = stringPad.start;


      // `String.prototype.padStart` method
      // https://tc39.es/ecma262/#sec-string.prototype.padstart
      _export({ target: 'String', proto: true, forced: stringPadWebkitBug }, {
        padStart: function padStart(maxLength /* , fillString = ' ' */) {
          return $padStart(this, maxLength, arguments.length > 1 ? arguments[1] : undefined);
        }
      });

      entryUnbind('String', 'padStart');

      var $padEnd = stringPad.end;


      // `String.prototype.padEnd` method
      // https://tc39.es/ecma262/#sec-string.prototype.padend
      _export({ target: 'String', proto: true, forced: stringPadWebkitBug }, {
        padEnd: function padEnd(maxLength /* , fillString = ' ' */) {
          return $padEnd(this, maxLength, arguments.length > 1 ? arguments[1] : undefined);
        }
      });

      entryUnbind('String', 'padEnd');

      var es2017String = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2017String);

      var f = wellKnownSymbol;

      var wellKnownSymbolWrapped = {
      	f: f
      };

      var defineProperty$2 = objectDefineProperty.f;

      var defineWellKnownSymbol = function (NAME) {
        var Symbol = path.Symbol || (path.Symbol = {});
        if (!has(Symbol, NAME)) defineProperty$2(Symbol, NAME, {
          value: wellKnownSymbolWrapped.f(NAME)
        });
      };

      // `Symbol.asyncIterator` well-known symbol
      // https://tc39.es/ecma262/#sec-symbol.asynciterator
      defineWellKnownSymbol('asyncIterator');

      wellKnownSymbolWrapped.f('asyncIterator');

      var es2018AsyncIterable = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2018AsyncIterable);

      // `IsArray` abstract operation
      // https://tc39.es/ecma262/#sec-isarray
      // eslint-disable-next-line es/no-array-isarray -- safe
      var isArray = Array.isArray || function isArray(arg) {
        return classofRaw(arg) == 'Array';
      };

      // `FlattenIntoArray` abstract operation
      // https://tc39.github.io/proposal-flatMap/#sec-FlattenIntoArray
      var flattenIntoArray = function (target, original, source, sourceLen, start, depth, mapper, thisArg) {
        var targetIndex = start;
        var sourceIndex = 0;
        var mapFn = mapper ? functionBindContext(mapper, thisArg, 3) : false;
        var element;

        while (sourceIndex < sourceLen) {
          if (sourceIndex in source) {
            element = mapFn ? mapFn(source[sourceIndex], sourceIndex, original) : source[sourceIndex];

            if (depth > 0 && isArray(element)) {
              targetIndex = flattenIntoArray(target, original, element, toLength(element.length), targetIndex, depth - 1) - 1;
            } else {
              if (targetIndex >= 0x1FFFFFFFFFFFFF) throw TypeError('Exceed the acceptable array length');
              target[targetIndex] = element;
            }

            targetIndex++;
          }
          sourceIndex++;
        }
        return targetIndex;
      };

      var flattenIntoArray_1 = flattenIntoArray;

      var SPECIES = wellKnownSymbol('species');

      // a part of `ArraySpeciesCreate` abstract operation
      // https://tc39.es/ecma262/#sec-arrayspeciescreate
      var arraySpeciesConstructor = function (originalArray) {
        var C;
        if (isArray(originalArray)) {
          C = originalArray.constructor;
          // cross-realm fallback
          if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
          else if (isObject(C)) {
            C = C[SPECIES];
            if (C === null) C = undefined;
          }
        } return C === undefined ? Array : C;
      };

      // `ArraySpeciesCreate` abstract operation
      // https://tc39.es/ecma262/#sec-arrayspeciescreate
      var arraySpeciesCreate = function (originalArray, length) {
        return new (arraySpeciesConstructor(originalArray))(length === 0 ? 0 : length);
      };

      // `Array.prototype.flatMap` method
      // https://tc39.es/ecma262/#sec-array.prototype.flatmap
      _export({ target: 'Array', proto: true }, {
        flatMap: function flatMap(callbackfn /* , thisArg */) {
          var O = toObject(this);
          var sourceLen = toLength(O.length);
          var A;
          aFunction(callbackfn);
          A = arraySpeciesCreate(O, 0);
          A.length = flattenIntoArray_1(A, O, O, sourceLen, 0, 1, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
          return A;
        }
      });

      // this method was added to unscopables after implementation
      // in popular engines, so it's moved to a separate module


      // https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
      addToUnscopables('flatMap');

      entryUnbind('Array', 'flatMap');

      // `Array.prototype.flat` method
      // https://tc39.es/ecma262/#sec-array.prototype.flat
      _export({ target: 'Array', proto: true }, {
        flat: function flat(/* depthArg = 1 */) {
          var depthArg = arguments.length ? arguments[0] : undefined;
          var O = toObject(this);
          var sourceLen = toLength(O.length);
          var A = arraySpeciesCreate(O, 0);
          A.length = flattenIntoArray_1(A, O, O, sourceLen, 0, depthArg === undefined ? 1 : toInteger(depthArg));
          return A;
        }
      });

      // this method was added to unscopables after implementation
      // in popular engines, so it's moved to a separate module


      // https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
      addToUnscopables('flat');

      entryUnbind('Array', 'flat');

      var es2019Array = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2019Array);

      // `Object.fromEntries` method
      // https://github.com/tc39/proposal-object-from-entries
      _export({ target: 'Object', stat: true }, {
        fromEntries: function fromEntries(iterable) {
          var obj = {};
          iterate(iterable, function (k, v) {
            createProperty(obj, k, v);
          }, { AS_ENTRIES: true });
          return obj;
        }
      });

      path.Object.fromEntries;

      var es2019Object = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2019Object);

      // a string of all valid unicode whitespaces
      var whitespaces = '\u0009\u000A\u000B\u000C\u000D\u0020\u00A0\u1680\u2000\u2001\u2002' +
        '\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';

      var whitespace = '[' + whitespaces + ']';
      var ltrim = RegExp('^' + whitespace + whitespace + '*');
      var rtrim = RegExp(whitespace + whitespace + '*$');

      // `String.prototype.{ trim, trimStart, trimEnd, trimLeft, trimRight }` methods implementation
      var createMethod = function (TYPE) {
        return function ($this) {
          var string = toString_1(requireObjectCoercible($this));
          if (TYPE & 1) string = string.replace(ltrim, '');
          if (TYPE & 2) string = string.replace(rtrim, '');
          return string;
        };
      };

      var stringTrim = {
        // `String.prototype.{ trimLeft, trimStart }` methods
        // https://tc39.es/ecma262/#sec-string.prototype.trimstart
        start: createMethod(1),
        // `String.prototype.{ trimRight, trimEnd }` methods
        // https://tc39.es/ecma262/#sec-string.prototype.trimend
        end: createMethod(2),
        // `String.prototype.trim` method
        // https://tc39.es/ecma262/#sec-string.prototype.trim
        trim: createMethod(3)
      };

      var non = '\u200B\u0085\u180E';

      // check that a method works with the correct list
      // of whitespaces and has a correct name
      var stringTrimForced = function (METHOD_NAME) {
        return fails(function () {
          return !!whitespaces[METHOD_NAME]() || non[METHOD_NAME]() != non || whitespaces[METHOD_NAME].name !== METHOD_NAME;
        });
      };

      var $trimEnd = stringTrim.end;


      var FORCED$1 = stringTrimForced('trimEnd');

      var trimEnd = FORCED$1 ? function trimEnd() {
        return $trimEnd(this);
      // eslint-disable-next-line es/no-string-prototype-trimstart-trimend -- safe
      } : ''.trimEnd;

      // `String.prototype.{ trimEnd, trimRight }` methods
      // https://tc39.es/ecma262/#sec-string.prototype.trimend
      // https://tc39.es/ecma262/#String.prototype.trimright
      _export({ target: 'String', proto: true, forced: FORCED$1 }, {
        trimEnd: trimEnd,
        trimRight: trimEnd
      });

      entryUnbind('String', 'trimRight');

      var $trimStart = stringTrim.start;


      var FORCED = stringTrimForced('trimStart');

      var trimStart = FORCED ? function trimStart() {
        return $trimStart(this);
      // eslint-disable-next-line es/no-string-prototype-trimstart-trimend -- safe
      } : ''.trimStart;

      // `String.prototype.{ trimStart, trimLeft }` methods
      // https://tc39.es/ecma262/#sec-string.prototype.trimstart
      // https://tc39.es/ecma262/#String.prototype.trimleft
      _export({ target: 'String', proto: true, forced: FORCED }, {
        trimStart: trimStart,
        trimLeft: trimStart
      });

      entryUnbind('String', 'trimLeft');

      entryUnbind('String', 'trimLeft');

      entryUnbind('String', 'trimRight');

      var es2019String = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2019String);

      var defineProperty$1 = objectDefineProperty.f;


      var NativeSymbol = global_1.Symbol;

      if (descriptors && typeof NativeSymbol == 'function' && (!('description' in NativeSymbol.prototype) ||
        // Safari 12 bug
        NativeSymbol().description !== undefined
      )) {
        var EmptyStringDescriptionStore = {};
        // wrap Symbol constructor for correct work with undefined description
        var SymbolWrapper = function Symbol() {
          var description = arguments.length < 1 || arguments[0] === undefined ? undefined : String(arguments[0]);
          var result = this instanceof SymbolWrapper
            ? new NativeSymbol(description)
            // in Edge 13, String(Symbol(undefined)) === 'Symbol(undefined)'
            : description === undefined ? NativeSymbol() : NativeSymbol(description);
          if (description === '') EmptyStringDescriptionStore[result] = true;
          return result;
        };
        copyConstructorProperties(SymbolWrapper, NativeSymbol);
        var symbolPrototype = SymbolWrapper.prototype = NativeSymbol.prototype;
        symbolPrototype.constructor = SymbolWrapper;

        var symbolToString = symbolPrototype.toString;
        var native = String(NativeSymbol('test')) == 'Symbol(test)';
        var regexp = /^Symbol\((.*)\)[^)]+$/;
        defineProperty$1(symbolPrototype, 'description', {
          configurable: true,
          get: function description() {
            var symbol = isObject(this) ? this.valueOf() : this;
            var string = symbolToString.call(symbol);
            if (has(EmptyStringDescriptionStore, symbol)) return '';
            var desc = native ? string.slice(7, -1) : string.replace(regexp, '$1');
            return desc === '' ? undefined : desc;
          }
        });

        _export({ global: true, forced: true }, {
          Symbol: SymbolWrapper
        });
      }

      var es2019Symbol = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2019Symbol);

      // `RegExp.prototype.flags` getter implementation
      // https://tc39.es/ecma262/#sec-get-regexp.prototype.flags
      var regexpFlags = function () {
        var that = anObject(this);
        var result = '';
        if (that.global) result += 'g';
        if (that.ignoreCase) result += 'i';
        if (that.multiline) result += 'm';
        if (that.dotAll) result += 's';
        if (that.unicode) result += 'u';
        if (that.sticky) result += 'y';
        return result;
      };

      // babel-minify transpiles RegExp('a', 'y') -> /a/y and it causes SyntaxError,
      var RE = function (s, f) {
        return RegExp(s, f);
      };

      var UNSUPPORTED_Y$1 = fails(function () {
        var re = RE('a', 'y');
        re.lastIndex = 2;
        return re.exec('abcd') != null;
      });

      var BROKEN_CARET = fails(function () {
        // https://bugzilla.mozilla.org/show_bug.cgi?id=773687
        var re = RE('^r', 'gy');
        re.lastIndex = 2;
        return re.exec('str') != null;
      });

      var regexpStickyHelpers = {
      	UNSUPPORTED_Y: UNSUPPORTED_Y$1,
      	BROKEN_CARET: BROKEN_CARET
      };

      var regexpUnsupportedDotAll = fails(function () {
        // babel-minify transpiles RegExp('.', 's') -> /./s and it causes SyntaxError
        var re = RegExp('.', (typeof '').charAt(0));
        return !(re.dotAll && re.exec('\n') && re.flags === 's');
      });

      var regexpUnsupportedNcg = fails(function () {
        // babel-minify transpiles RegExp('.', 'g') -> /./g and it causes SyntaxError
        var re = RegExp('(?<a>b)', (typeof '').charAt(5));
        return re.exec('b').groups.a !== 'b' ||
          'b'.replace(re, '$<a>c') !== 'bc';
      });

      /* eslint-disable regexp/no-assertion-capturing-group, regexp/no-empty-group, regexp/no-lazy-ends -- testing */
      /* eslint-disable regexp/no-useless-quantifier -- testing */





      var getInternalState$1 = internalState.get;



      var nativeExec = RegExp.prototype.exec;
      var nativeReplace = shared('native-string-replace', String.prototype.replace);

      var patchedExec = nativeExec;

      var UPDATES_LAST_INDEX_WRONG = (function () {
        var re1 = /a/;
        var re2 = /b*/g;
        nativeExec.call(re1, 'a');
        nativeExec.call(re2, 'a');
        return re1.lastIndex !== 0 || re2.lastIndex !== 0;
      })();

      var UNSUPPORTED_Y = regexpStickyHelpers.UNSUPPORTED_Y || regexpStickyHelpers.BROKEN_CARET;

      // nonparticipating capturing group, copied from es5-shim's String#split patch.
      var NPCG_INCLUDED = /()??/.exec('')[1] !== undefined;

      var PATCH = UPDATES_LAST_INDEX_WRONG || NPCG_INCLUDED || UNSUPPORTED_Y || regexpUnsupportedDotAll || regexpUnsupportedNcg;

      if (PATCH) {
        // eslint-disable-next-line max-statements -- TODO
        patchedExec = function exec(string) {
          var re = this;
          var state = getInternalState$1(re);
          var str = toString_1(string);
          var raw = state.raw;
          var result, reCopy, lastIndex, match, i, object, group;

          if (raw) {
            raw.lastIndex = re.lastIndex;
            result = patchedExec.call(raw, str);
            re.lastIndex = raw.lastIndex;
            return result;
          }

          var groups = state.groups;
          var sticky = UNSUPPORTED_Y && re.sticky;
          var flags = regexpFlags.call(re);
          var source = re.source;
          var charsAdded = 0;
          var strCopy = str;

          if (sticky) {
            flags = flags.replace('y', '');
            if (flags.indexOf('g') === -1) {
              flags += 'g';
            }

            strCopy = str.slice(re.lastIndex);
            // Support anchored sticky behavior.
            if (re.lastIndex > 0 && (!re.multiline || re.multiline && str.charAt(re.lastIndex - 1) !== '\n')) {
              source = '(?: ' + source + ')';
              strCopy = ' ' + strCopy;
              charsAdded++;
            }
            // ^(? + rx + ) is needed, in combination with some str slicing, to
            // simulate the 'y' flag.
            reCopy = new RegExp('^(?:' + source + ')', flags);
          }

          if (NPCG_INCLUDED) {
            reCopy = new RegExp('^' + source + '$(?!\\s)', flags);
          }
          if (UPDATES_LAST_INDEX_WRONG) lastIndex = re.lastIndex;

          match = nativeExec.call(sticky ? reCopy : re, strCopy);

          if (sticky) {
            if (match) {
              match.input = match.input.slice(charsAdded);
              match[0] = match[0].slice(charsAdded);
              match.index = re.lastIndex;
              re.lastIndex += match[0].length;
            } else re.lastIndex = 0;
          } else if (UPDATES_LAST_INDEX_WRONG && match) {
            re.lastIndex = re.global ? match.index + match[0].length : lastIndex;
          }
          if (NPCG_INCLUDED && match && match.length > 1) {
            // Fix browsers whose `exec` methods don't consistently return `undefined`
            // for NPCG, like IE8. NOTE: This doesn' work for /(.?)?/
            nativeReplace.call(match[0], reCopy, function () {
              for (i = 1; i < arguments.length - 2; i++) {
                if (arguments[i] === undefined) match[i] = undefined;
              }
            });
          }

          if (match && groups) {
            match.groups = object = objectCreate(null);
            for (i = 0; i < groups.length; i++) {
              group = groups[i];
              object[group[0]] = match[group[1]];
            }
          }

          return match;
        };
      }

      var regexpExec = patchedExec;

      // `RegExp.prototype.exec` method
      // https://tc39.es/ecma262/#sec-regexp.prototype.exec
      _export({ target: 'RegExp', proto: true, forced: /./.exec !== regexpExec }, {
        exec: regexpExec
      });

      var MATCH = wellKnownSymbol('match');

      // `IsRegExp` abstract operation
      // https://tc39.es/ecma262/#sec-isregexp
      var isRegexp = function (it) {
        var isRegExp;
        return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : classofRaw(it) == 'RegExp');
      };

      var charAt = stringMultibyte.charAt;

      // `AdvanceStringIndex` abstract operation
      // https://tc39.es/ecma262/#sec-advancestringindex
      var advanceStringIndex = function (S, index, unicode) {
        return index + (unicode ? charAt(S, index).length : 1);
      };

      /* eslint-disable es/no-string-prototype-matchall -- safe */


















      var MATCH_ALL = wellKnownSymbol('matchAll');
      var REGEXP_STRING = 'RegExp String';
      var REGEXP_STRING_ITERATOR = REGEXP_STRING + ' Iterator';
      var setInternalState$2 = internalState.set;
      var getInternalState = internalState.getterFor(REGEXP_STRING_ITERATOR);
      var RegExpPrototype = RegExp.prototype;
      var regExpBuiltinExec = RegExpPrototype.exec;
      var nativeMatchAll = ''.matchAll;

      var WORKS_WITH_NON_GLOBAL_REGEX = !!nativeMatchAll && !fails(function () {
        'a'.matchAll(/./);
      });

      var regExpExec = function (R, S) {
        var exec = R.exec;
        var result;
        if (typeof exec == 'function') {
          result = exec.call(R, S);
          if (typeof result != 'object') throw TypeError('Incorrect exec result');
          return result;
        } return regExpBuiltinExec.call(R, S);
      };

      // eslint-disable-next-line max-len -- ignore
      var $RegExpStringIterator = createIteratorConstructor(function RegExpStringIterator(regexp, string, global, fullUnicode) {
        setInternalState$2(this, {
          type: REGEXP_STRING_ITERATOR,
          regexp: regexp,
          string: string,
          global: global,
          unicode: fullUnicode,
          done: false
        });
      }, REGEXP_STRING, function next() {
        var state = getInternalState(this);
        if (state.done) return { value: undefined, done: true };
        var R = state.regexp;
        var S = state.string;
        var match = regExpExec(R, S);
        if (match === null) return { value: undefined, done: state.done = true };
        if (state.global) {
          if (toString_1(match[0]) === '') R.lastIndex = advanceStringIndex(S, toLength(R.lastIndex), state.unicode);
          return { value: match, done: false };
        }
        state.done = true;
        return { value: match, done: false };
      });

      var $matchAll = function (string) {
        var R = anObject(this);
        var S = toString_1(string);
        var C, flagsValue, flags, matcher, global, fullUnicode;
        C = speciesConstructor(R, RegExp);
        flagsValue = R.flags;
        if (flagsValue === undefined && R instanceof RegExp && !('flags' in RegExpPrototype)) {
          flagsValue = regexpFlags.call(R);
        }
        flags = flagsValue === undefined ? '' : toString_1(flagsValue);
        matcher = new C(C === RegExp ? R.source : R, flags);
        global = !!~flags.indexOf('g');
        fullUnicode = !!~flags.indexOf('u');
        matcher.lastIndex = toLength(R.lastIndex);
        return new $RegExpStringIterator(matcher, S, global, fullUnicode);
      };

      // `String.prototype.matchAll` method
      // https://tc39.es/ecma262/#sec-string.prototype.matchall
      _export({ target: 'String', proto: true, forced: WORKS_WITH_NON_GLOBAL_REGEX }, {
        matchAll: function matchAll(regexp) {
          var O = requireObjectCoercible(this);
          var flags, S, matcher, rx;
          if (regexp != null) {
            if (isRegexp(regexp)) {
              flags = toString_1(requireObjectCoercible('flags' in RegExpPrototype
                ? regexp.flags
                : regexpFlags.call(regexp)
              ));
              if (!~flags.indexOf('g')) throw TypeError('`.matchAll` does not allow non-global regexes');
            }
            if (WORKS_WITH_NON_GLOBAL_REGEX) return nativeMatchAll.apply(O, arguments);
            matcher = regexp[MATCH_ALL];
            if (matcher === undefined && isPure && classofRaw(regexp) == 'RegExp') matcher = $matchAll;
            if (matcher != null) return aFunction(matcher).call(regexp, O);
          } else if (WORKS_WITH_NON_GLOBAL_REGEX) return nativeMatchAll.apply(O, arguments);
          S = toString_1(O);
          rx = new RegExp(regexp, 'g');
          return rx[MATCH_ALL](S);
        }
      });

      MATCH_ALL in RegExpPrototype || createNonEnumerableProperty(RegExpPrototype, MATCH_ALL, $matchAll);

      entryUnbind('String', 'matchAll');

      var es2020String = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2020String);

      var es2020SymbolWellknown = createCommonjsModule(function (module, exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      });

      unwrapExports(es2020SymbolWellknown);

      const request = getGlobalThis().Request || {};
      request.prototype = {
          constructor: () => { }
      };

      var ITERATOR$1 = wellKnownSymbol('iterator');

      var nativeUrl = !fails(function () {
        var url = new URL('b?a=1&b=2&c=3', 'http://a');
        var searchParams = url.searchParams;
        var result = '';
        url.pathname = 'c%20d';
        searchParams.forEach(function (value, key) {
          searchParams['delete']('b');
          result += key + value;
        });
        return (isPure && !url.toJSON)
          || !searchParams.sort
          || url.href !== 'http://a/c%20d?a=1&c=3'
          || searchParams.get('c') !== '3'
          || String(new URLSearchParams('?a=1')) !== 'a=1'
          || !searchParams[ITERATOR$1]
          // throws in Edge
          || new URL('https://a@b').username !== 'a'
          || new URLSearchParams(new URLSearchParams('a=b')).get('a') !== 'b'
          // not punycoded in Edge
          || new URL('http://тест').host !== 'xn--e1aybc'
          // not escaped in Chrome 62-
          || new URL('http://a#б').hash !== '#%D0%B1'
          // fails in Chrome 66-
          || result !== 'a1c3'
          // throws in Safari
          || new URL('http://x', undefined).host !== 'x';
      });

      // eslint-disable-next-line es/no-object-assign -- safe
      var $assign = Object.assign;
      // eslint-disable-next-line es/no-object-defineproperty -- required for testing
      var defineProperty = Object.defineProperty;

      // `Object.assign` method
      // https://tc39.es/ecma262/#sec-object.assign
      var objectAssign = !$assign || fails(function () {
        // should have correct order of operations (Edge bug)
        if (descriptors && $assign({ b: 1 }, $assign(defineProperty({}, 'a', {
          enumerable: true,
          get: function () {
            defineProperty(this, 'b', {
              value: 3,
              enumerable: false
            });
          }
        }), { b: 2 })).b !== 1) return true;
        // should work with symbols and should have deterministic property order (V8 bug)
        var A = {};
        var B = {};
        // eslint-disable-next-line es/no-symbol -- safe
        var symbol = Symbol();
        var alphabet = 'abcdefghijklmnopqrst';
        A[symbol] = 7;
        alphabet.split('').forEach(function (chr) { B[chr] = chr; });
        return $assign({}, A)[symbol] != 7 || objectKeys($assign({}, B)).join('') != alphabet;
      }) ? function assign(target, source) { // eslint-disable-line no-unused-vars -- required for `.length`
        var T = toObject(target);
        var argumentsLength = arguments.length;
        var index = 1;
        var getOwnPropertySymbols = objectGetOwnPropertySymbols.f;
        var propertyIsEnumerable = objectPropertyIsEnumerable.f;
        while (argumentsLength > index) {
          var S = indexedObject(arguments[index++]);
          var keys = getOwnPropertySymbols ? objectKeys(S).concat(getOwnPropertySymbols(S)) : objectKeys(S);
          var length = keys.length;
          var j = 0;
          var key;
          while (length > j) {
            key = keys[j++];
            if (!descriptors || propertyIsEnumerable.call(S, key)) T[key] = S[key];
          }
        } return T;
      } : $assign;

      // call something on iterator step with safe closing on error
      var callWithSafeIterationClosing = function (iterator, fn, value, ENTRIES) {
        try {
          return ENTRIES ? fn(anObject(value)[0], value[1]) : fn(value);
        } catch (error) {
          iteratorClose(iterator);
          throw error;
        }
      };

      // `Array.from` method implementation
      // https://tc39.es/ecma262/#sec-array.from
      var arrayFrom = function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
        var O = toObject(arrayLike);
        var C = typeof this == 'function' ? this : Array;
        var argumentsLength = arguments.length;
        var mapfn = argumentsLength > 1 ? arguments[1] : undefined;
        var mapping = mapfn !== undefined;
        var iteratorMethod = getIteratorMethod(O);
        var index = 0;
        var length, result, step, iterator, next, value;
        if (mapping) mapfn = functionBindContext(mapfn, argumentsLength > 2 ? arguments[2] : undefined, 2);
        // if the target is not iterable or it's an array with the default iterator - use a simple case
        if (iteratorMethod != undefined && !(C == Array && isArrayIteratorMethod(iteratorMethod))) {
          iterator = iteratorMethod.call(O);
          next = iterator.next;
          result = new C();
          for (;!(step = next.call(iterator)).done; index++) {
            value = mapping ? callWithSafeIterationClosing(iterator, mapfn, [step.value, index], true) : step.value;
            createProperty(result, index, value);
          }
        } else {
          length = toLength(O.length);
          result = new C(length);
          for (;length > index; index++) {
            value = mapping ? mapfn(O[index], index) : O[index];
            createProperty(result, index, value);
          }
        }
        result.length = index;
        return result;
      };

      // based on https://github.com/bestiejs/punycode.js/blob/master/punycode.js
      var maxInt = 2147483647; // aka. 0x7FFFFFFF or 2^31-1
      var base = 36;
      var tMin = 1;
      var tMax = 26;
      var skew = 38;
      var damp = 700;
      var initialBias = 72;
      var initialN = 128; // 0x80
      var delimiter = '-'; // '\x2D'
      var regexNonASCII = /[^\0-\u007E]/; // non-ASCII chars
      var regexSeparators = /[.\u3002\uFF0E\uFF61]/g; // RFC 3490 separators
      var OVERFLOW_ERROR = 'Overflow: input needs wider integers to process';
      var baseMinusTMin = base - tMin;
      var floor$1 = Math.floor;
      var stringFromCharCode = String.fromCharCode;

      /**
       * Creates an array containing the numeric code points of each Unicode
       * character in the string. While JavaScript uses UCS-2 internally,
       * this function will convert a pair of surrogate halves (each of which
       * UCS-2 exposes as separate characters) into a single code point,
       * matching UTF-16.
       */
      var ucs2decode = function (string) {
        var output = [];
        var counter = 0;
        var length = string.length;
        while (counter < length) {
          var value = string.charCodeAt(counter++);
          if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
            // It's a high surrogate, and there is a next character.
            var extra = string.charCodeAt(counter++);
            if ((extra & 0xFC00) == 0xDC00) { // Low surrogate.
              output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
            } else {
              // It's an unmatched surrogate; only append this code unit, in case the
              // next code unit is the high surrogate of a surrogate pair.
              output.push(value);
              counter--;
            }
          } else {
            output.push(value);
          }
        }
        return output;
      };

      /**
       * Converts a digit/integer into a basic code point.
       */
      var digitToBasic = function (digit) {
        //  0..25 map to ASCII a..z or A..Z
        // 26..35 map to ASCII 0..9
        return digit + 22 + 75 * (digit < 26);
      };

      /**
       * Bias adaptation function as per section 3.4 of RFC 3492.
       * https://tools.ietf.org/html/rfc3492#section-3.4
       */
      var adapt = function (delta, numPoints, firstTime) {
        var k = 0;
        delta = firstTime ? floor$1(delta / damp) : delta >> 1;
        delta += floor$1(delta / numPoints);
        for (; delta > baseMinusTMin * tMax >> 1; k += base) {
          delta = floor$1(delta / baseMinusTMin);
        }
        return floor$1(k + (baseMinusTMin + 1) * delta / (delta + skew));
      };

      /**
       * Converts a string of Unicode symbols (e.g. a domain name label) to a
       * Punycode string of ASCII-only symbols.
       */
      // eslint-disable-next-line max-statements -- TODO
      var encode = function (input) {
        var output = [];

        // Convert the input in UCS-2 to an array of Unicode code points.
        input = ucs2decode(input);

        // Cache the length.
        var inputLength = input.length;

        // Initialize the state.
        var n = initialN;
        var delta = 0;
        var bias = initialBias;
        var i, currentValue;

        // Handle the basic code points.
        for (i = 0; i < input.length; i++) {
          currentValue = input[i];
          if (currentValue < 0x80) {
            output.push(stringFromCharCode(currentValue));
          }
        }

        var basicLength = output.length; // number of basic code points.
        var handledCPCount = basicLength; // number of code points that have been handled;

        // Finish the basic string with a delimiter unless it's empty.
        if (basicLength) {
          output.push(delimiter);
        }

        // Main encoding loop:
        while (handledCPCount < inputLength) {
          // All non-basic code points < n have been handled already. Find the next larger one:
          var m = maxInt;
          for (i = 0; i < input.length; i++) {
            currentValue = input[i];
            if (currentValue >= n && currentValue < m) {
              m = currentValue;
            }
          }

          // Increase `delta` enough to advance the decoder's <n,i> state to <m,0>, but guard against overflow.
          var handledCPCountPlusOne = handledCPCount + 1;
          if (m - n > floor$1((maxInt - delta) / handledCPCountPlusOne)) {
            throw RangeError(OVERFLOW_ERROR);
          }

          delta += (m - n) * handledCPCountPlusOne;
          n = m;

          for (i = 0; i < input.length; i++) {
            currentValue = input[i];
            if (currentValue < n && ++delta > maxInt) {
              throw RangeError(OVERFLOW_ERROR);
            }
            if (currentValue == n) {
              // Represent delta as a generalized variable-length integer.
              var q = delta;
              for (var k = base; /* no condition */; k += base) {
                var t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);
                if (q < t) break;
                var qMinusT = q - t;
                var baseMinusT = base - t;
                output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT)));
                q = floor$1(qMinusT / baseMinusT);
              }

              output.push(stringFromCharCode(digitToBasic(q)));
              bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
              delta = 0;
              ++handledCPCount;
            }
          }

          ++delta;
          ++n;
        }
        return output.join('');
      };

      var stringPunycodeToAscii = function (input) {
        var encoded = [];
        var labels = input.toLowerCase().replace(regexSeparators, '\u002E').split('.');
        var i, label;
        for (i = 0; i < labels.length; i++) {
          label = labels[i];
          encoded.push(regexNonASCII.test(label) ? 'xn--' + encode(label) : label);
        }
        return encoded.join('.');
      };

      var getIterator = function (it) {
        var iteratorMethod = getIteratorMethod(it);
        if (typeof iteratorMethod != 'function') {
          throw TypeError(String(it) + ' is not iterable');
        } return anObject(iteratorMethod.call(it));
      };

      // TODO: in core-js@4, move /modules/ dependencies to public entries for better optimization by tools like `preset-env`






















      var nativeFetch = getBuiltIn('fetch');
      var NativeRequest = getBuiltIn('Request');
      var RequestPrototype = NativeRequest && NativeRequest.prototype;
      var Headers = getBuiltIn('Headers');
      var ITERATOR = wellKnownSymbol('iterator');
      var URL_SEARCH_PARAMS = 'URLSearchParams';
      var URL_SEARCH_PARAMS_ITERATOR = URL_SEARCH_PARAMS + 'Iterator';
      var setInternalState$1 = internalState.set;
      var getInternalParamsState = internalState.getterFor(URL_SEARCH_PARAMS);
      var getInternalIteratorState = internalState.getterFor(URL_SEARCH_PARAMS_ITERATOR);

      var plus = /\+/g;
      var sequences = Array(4);

      var percentSequence = function (bytes) {
        return sequences[bytes - 1] || (sequences[bytes - 1] = RegExp('((?:%[\\da-f]{2}){' + bytes + '})', 'gi'));
      };

      var percentDecode = function (sequence) {
        try {
          return decodeURIComponent(sequence);
        } catch (error) {
          return sequence;
        }
      };

      var deserialize = function (it) {
        var result = it.replace(plus, ' ');
        var bytes = 4;
        try {
          return decodeURIComponent(result);
        } catch (error) {
          while (bytes) {
            result = result.replace(percentSequence(bytes--), percentDecode);
          }
          return result;
        }
      };

      var find = /[!'()~]|%20/g;

      var replace = {
        '!': '%21',
        "'": '%27',
        '(': '%28',
        ')': '%29',
        '~': '%7E',
        '%20': '+'
      };

      var replacer = function (match) {
        return replace[match];
      };

      var serialize = function (it) {
        return encodeURIComponent(it).replace(find, replacer);
      };

      var parseSearchParams = function (result, query) {
        if (query) {
          var attributes = query.split('&');
          var index = 0;
          var attribute, entry;
          while (index < attributes.length) {
            attribute = attributes[index++];
            if (attribute.length) {
              entry = attribute.split('=');
              result.push({
                key: deserialize(entry.shift()),
                value: deserialize(entry.join('='))
              });
            }
          }
        }
      };

      var updateSearchParams = function (query) {
        this.entries.length = 0;
        parseSearchParams(this.entries, query);
      };

      var validateArgumentsLength = function (passed, required) {
        if (passed < required) throw TypeError('Not enough arguments');
      };

      var URLSearchParamsIterator = createIteratorConstructor(function Iterator(params, kind) {
        setInternalState$1(this, {
          type: URL_SEARCH_PARAMS_ITERATOR,
          iterator: getIterator(getInternalParamsState(params).entries),
          kind: kind
        });
      }, 'Iterator', function next() {
        var state = getInternalIteratorState(this);
        var kind = state.kind;
        var step = state.iterator.next();
        var entry = step.value;
        if (!step.done) {
          step.value = kind === 'keys' ? entry.key : kind === 'values' ? entry.value : [entry.key, entry.value];
        } return step;
      });

      // `URLSearchParams` constructor
      // https://url.spec.whatwg.org/#interface-urlsearchparams
      var URLSearchParamsConstructor = function URLSearchParams(/* init */) {
        anInstance(this, URLSearchParamsConstructor, URL_SEARCH_PARAMS);
        var init = arguments.length > 0 ? arguments[0] : undefined;
        var that = this;
        var entries = [];
        var iteratorMethod, iterator, next, step, entryIterator, entryNext, first, second, key;

        setInternalState$1(that, {
          type: URL_SEARCH_PARAMS,
          entries: entries,
          updateURL: function () { /* empty */ },
          updateSearchParams: updateSearchParams
        });

        if (init !== undefined) {
          if (isObject(init)) {
            iteratorMethod = getIteratorMethod(init);
            if (typeof iteratorMethod === 'function') {
              iterator = iteratorMethod.call(init);
              next = iterator.next;
              while (!(step = next.call(iterator)).done) {
                entryIterator = getIterator(anObject(step.value));
                entryNext = entryIterator.next;
                if (
                  (first = entryNext.call(entryIterator)).done ||
                  (second = entryNext.call(entryIterator)).done ||
                  !entryNext.call(entryIterator).done
                ) throw TypeError('Expected sequence with length 2');
                entries.push({ key: toString_1(first.value), value: toString_1(second.value) });
              }
            } else for (key in init) if (has(init, key)) entries.push({ key: key, value: toString_1(init[key]) });
          } else {
            parseSearchParams(
              entries,
              typeof init === 'string' ? init.charAt(0) === '?' ? init.slice(1) : init : toString_1(init)
            );
          }
        }
      };

      var URLSearchParamsPrototype = URLSearchParamsConstructor.prototype;

      redefineAll(URLSearchParamsPrototype, {
        // `URLSearchParams.prototype.append` method
        // https://url.spec.whatwg.org/#dom-urlsearchparams-append
        append: function append(name, value) {
          validateArgumentsLength(arguments.length, 2);
          var state = getInternalParamsState(this);
          state.entries.push({ key: toString_1(name), value: toString_1(value) });
          state.updateURL();
        },
        // `URLSearchParams.prototype.delete` method
        // https://url.spec.whatwg.org/#dom-urlsearchparams-delete
        'delete': function (name) {
          validateArgumentsLength(arguments.length, 1);
          var state = getInternalParamsState(this);
          var entries = state.entries;
          var key = toString_1(name);
          var index = 0;
          while (index < entries.length) {
            if (entries[index].key === key) entries.splice(index, 1);
            else index++;
          }
          state.updateURL();
        },
        // `URLSearchParams.prototype.get` method
        // https://url.spec.whatwg.org/#dom-urlsearchparams-get
        get: function get(name) {
          validateArgumentsLength(arguments.length, 1);
          var entries = getInternalParamsState(this).entries;
          var key = toString_1(name);
          var index = 0;
          for (; index < entries.length; index++) {
            if (entries[index].key === key) return entries[index].value;
          }
          return null;
        },
        // `URLSearchParams.prototype.getAll` method
        // https://url.spec.whatwg.org/#dom-urlsearchparams-getall
        getAll: function getAll(name) {
          validateArgumentsLength(arguments.length, 1);
          var entries = getInternalParamsState(this).entries;
          var key = toString_1(name);
          var result = [];
          var index = 0;
          for (; index < entries.length; index++) {
            if (entries[index].key === key) result.push(entries[index].value);
          }
          return result;
        },
        // `URLSearchParams.prototype.has` method
        // https://url.spec.whatwg.org/#dom-urlsearchparams-has
        has: function has(name) {
          validateArgumentsLength(arguments.length, 1);
          var entries = getInternalParamsState(this).entries;
          var key = toString_1(name);
          var index = 0;
          while (index < entries.length) {
            if (entries[index++].key === key) return true;
          }
          return false;
        },
        // `URLSearchParams.prototype.set` method
        // https://url.spec.whatwg.org/#dom-urlsearchparams-set
        set: function set(name, value) {
          validateArgumentsLength(arguments.length, 1);
          var state = getInternalParamsState(this);
          var entries = state.entries;
          var found = false;
          var key = toString_1(name);
          var val = toString_1(value);
          var index = 0;
          var entry;
          for (; index < entries.length; index++) {
            entry = entries[index];
            if (entry.key === key) {
              if (found) entries.splice(index--, 1);
              else {
                found = true;
                entry.value = val;
              }
            }
          }
          if (!found) entries.push({ key: key, value: val });
          state.updateURL();
        },
        // `URLSearchParams.prototype.sort` method
        // https://url.spec.whatwg.org/#dom-urlsearchparams-sort
        sort: function sort() {
          var state = getInternalParamsState(this);
          var entries = state.entries;
          // Array#sort is not stable in some engines
          var slice = entries.slice();
          var entry, entriesIndex, sliceIndex;
          entries.length = 0;
          for (sliceIndex = 0; sliceIndex < slice.length; sliceIndex++) {
            entry = slice[sliceIndex];
            for (entriesIndex = 0; entriesIndex < sliceIndex; entriesIndex++) {
              if (entries[entriesIndex].key > entry.key) {
                entries.splice(entriesIndex, 0, entry);
                break;
              }
            }
            if (entriesIndex === sliceIndex) entries.push(entry);
          }
          state.updateURL();
        },
        // `URLSearchParams.prototype.forEach` method
        forEach: function forEach(callback /* , thisArg */) {
          var entries = getInternalParamsState(this).entries;
          var boundFunction = functionBindContext(callback, arguments.length > 1 ? arguments[1] : undefined, 3);
          var index = 0;
          var entry;
          while (index < entries.length) {
            entry = entries[index++];
            boundFunction(entry.value, entry.key, this);
          }
        },
        // `URLSearchParams.prototype.keys` method
        keys: function keys() {
          return new URLSearchParamsIterator(this, 'keys');
        },
        // `URLSearchParams.prototype.values` method
        values: function values() {
          return new URLSearchParamsIterator(this, 'values');
        },
        // `URLSearchParams.prototype.entries` method
        entries: function entries() {
          return new URLSearchParamsIterator(this, 'entries');
        }
      }, { enumerable: true });

      // `URLSearchParams.prototype[@@iterator]` method
      redefine(URLSearchParamsPrototype, ITERATOR, URLSearchParamsPrototype.entries);

      // `URLSearchParams.prototype.toString` method
      // https://url.spec.whatwg.org/#urlsearchparams-stringification-behavior
      redefine(URLSearchParamsPrototype, 'toString', function toString() {
        var entries = getInternalParamsState(this).entries;
        var result = [];
        var index = 0;
        var entry;
        while (index < entries.length) {
          entry = entries[index++];
          result.push(serialize(entry.key) + '=' + serialize(entry.value));
        } return result.join('&');
      }, { enumerable: true });

      setToStringTag(URLSearchParamsConstructor, URL_SEARCH_PARAMS);

      _export({ global: true, forced: !nativeUrl }, {
        URLSearchParams: URLSearchParamsConstructor
      });

      // Wrap `fetch` and `Request` for correct work with polyfilled `URLSearchParams`
      if (!nativeUrl && typeof Headers == 'function') {
        var wrapRequestOptions = function (init) {
          if (isObject(init)) {
            var body = init.body;
            var headers;
            if (classof(body) === URL_SEARCH_PARAMS) {
              headers = init.headers ? new Headers(init.headers) : new Headers();
              if (!headers.has('content-type')) {
                headers.set('content-type', 'application/x-www-form-urlencoded;charset=UTF-8');
              }
              return objectCreate(init, {
                body: createPropertyDescriptor(0, String(body)),
                headers: createPropertyDescriptor(0, headers)
              });
            }
          } return init;
        };

        if (typeof nativeFetch == 'function') {
          _export({ global: true, enumerable: true, forced: true }, {
            fetch: function fetch(input /* , init */) {
              return nativeFetch(input, arguments.length > 1 ? wrapRequestOptions(arguments[1]) : {});
            }
          });
        }

        if (typeof NativeRequest == 'function') {
          var RequestConstructor = function Request(input /* , init */) {
            anInstance(this, RequestConstructor, 'Request');
            return new NativeRequest(input, arguments.length > 1 ? wrapRequestOptions(arguments[1]) : {});
          };

          RequestPrototype.constructor = RequestConstructor;
          RequestConstructor.prototype = RequestPrototype;

          _export({ global: true, forced: true }, {
            Request: RequestConstructor
          });
        }
      }

      var web_urlSearchParams = {
        URLSearchParams: URLSearchParamsConstructor,
        getState: getInternalParamsState
      };

      // TODO: in core-js@4, move /modules/ dependencies to public entries for better optimization by tools like `preset-env`











      var codeAt = stringMultibyte.codeAt;






      var NativeURL = global_1.URL;
      var URLSearchParams$1 = web_urlSearchParams.URLSearchParams;
      var getInternalSearchParamsState = web_urlSearchParams.getState;
      var setInternalState = internalState.set;
      var getInternalURLState = internalState.getterFor('URL');
      var floor = Math.floor;
      var pow = Math.pow;

      var INVALID_AUTHORITY = 'Invalid authority';
      var INVALID_SCHEME = 'Invalid scheme';
      var INVALID_HOST = 'Invalid host';
      var INVALID_PORT = 'Invalid port';

      var ALPHA = /[A-Za-z]/;
      // eslint-disable-next-line regexp/no-obscure-range -- safe
      var ALPHANUMERIC = /[\d+-.A-Za-z]/;
      var DIGIT = /\d/;
      var HEX_START = /^0x/i;
      var OCT = /^[0-7]+$/;
      var DEC = /^\d+$/;
      var HEX = /^[\dA-Fa-f]+$/;
      /* eslint-disable no-control-regex -- safe */
      var FORBIDDEN_HOST_CODE_POINT = /[\0\t\n\r #%/:<>?@[\\\]^|]/;
      var FORBIDDEN_HOST_CODE_POINT_EXCLUDING_PERCENT = /[\0\t\n\r #/:<>?@[\\\]^|]/;
      var LEADING_AND_TRAILING_C0_CONTROL_OR_SPACE = /^[\u0000-\u0020]+|[\u0000-\u0020]+$/g;
      var TAB_AND_NEW_LINE = /[\t\n\r]/g;
      /* eslint-enable no-control-regex -- safe */
      var EOF;

      var parseHost = function (url, input) {
        var result, codePoints, index;
        if (input.charAt(0) == '[') {
          if (input.charAt(input.length - 1) != ']') return INVALID_HOST;
          result = parseIPv6(input.slice(1, -1));
          if (!result) return INVALID_HOST;
          url.host = result;
        // opaque host
        } else if (!isSpecial(url)) {
          if (FORBIDDEN_HOST_CODE_POINT_EXCLUDING_PERCENT.test(input)) return INVALID_HOST;
          result = '';
          codePoints = arrayFrom(input);
          for (index = 0; index < codePoints.length; index++) {
            result += percentEncode(codePoints[index], C0ControlPercentEncodeSet);
          }
          url.host = result;
        } else {
          input = stringPunycodeToAscii(input);
          if (FORBIDDEN_HOST_CODE_POINT.test(input)) return INVALID_HOST;
          result = parseIPv4(input);
          if (result === null) return INVALID_HOST;
          url.host = result;
        }
      };

      var parseIPv4 = function (input) {
        var parts = input.split('.');
        var partsLength, numbers, index, part, radix, number, ipv4;
        if (parts.length && parts[parts.length - 1] == '') {
          parts.pop();
        }
        partsLength = parts.length;
        if (partsLength > 4) return input;
        numbers = [];
        for (index = 0; index < partsLength; index++) {
          part = parts[index];
          if (part == '') return input;
          radix = 10;
          if (part.length > 1 && part.charAt(0) == '0') {
            radix = HEX_START.test(part) ? 16 : 8;
            part = part.slice(radix == 8 ? 1 : 2);
          }
          if (part === '') {
            number = 0;
          } else {
            if (!(radix == 10 ? DEC : radix == 8 ? OCT : HEX).test(part)) return input;
            number = parseInt(part, radix);
          }
          numbers.push(number);
        }
        for (index = 0; index < partsLength; index++) {
          number = numbers[index];
          if (index == partsLength - 1) {
            if (number >= pow(256, 5 - partsLength)) return null;
          } else if (number > 255) return null;
        }
        ipv4 = numbers.pop();
        for (index = 0; index < numbers.length; index++) {
          ipv4 += numbers[index] * pow(256, 3 - index);
        }
        return ipv4;
      };

      // eslint-disable-next-line max-statements -- TODO
      var parseIPv6 = function (input) {
        var address = [0, 0, 0, 0, 0, 0, 0, 0];
        var pieceIndex = 0;
        var compress = null;
        var pointer = 0;
        var value, length, numbersSeen, ipv4Piece, number, swaps, swap;

        var char = function () {
          return input.charAt(pointer);
        };

        if (char() == ':') {
          if (input.charAt(1) != ':') return;
          pointer += 2;
          pieceIndex++;
          compress = pieceIndex;
        }
        while (char()) {
          if (pieceIndex == 8) return;
          if (char() == ':') {
            if (compress !== null) return;
            pointer++;
            pieceIndex++;
            compress = pieceIndex;
            continue;
          }
          value = length = 0;
          while (length < 4 && HEX.test(char())) {
            value = value * 16 + parseInt(char(), 16);
            pointer++;
            length++;
          }
          if (char() == '.') {
            if (length == 0) return;
            pointer -= length;
            if (pieceIndex > 6) return;
            numbersSeen = 0;
            while (char()) {
              ipv4Piece = null;
              if (numbersSeen > 0) {
                if (char() == '.' && numbersSeen < 4) pointer++;
                else return;
              }
              if (!DIGIT.test(char())) return;
              while (DIGIT.test(char())) {
                number = parseInt(char(), 10);
                if (ipv4Piece === null) ipv4Piece = number;
                else if (ipv4Piece == 0) return;
                else ipv4Piece = ipv4Piece * 10 + number;
                if (ipv4Piece > 255) return;
                pointer++;
              }
              address[pieceIndex] = address[pieceIndex] * 256 + ipv4Piece;
              numbersSeen++;
              if (numbersSeen == 2 || numbersSeen == 4) pieceIndex++;
            }
            if (numbersSeen != 4) return;
            break;
          } else if (char() == ':') {
            pointer++;
            if (!char()) return;
          } else if (char()) return;
          address[pieceIndex++] = value;
        }
        if (compress !== null) {
          swaps = pieceIndex - compress;
          pieceIndex = 7;
          while (pieceIndex != 0 && swaps > 0) {
            swap = address[pieceIndex];
            address[pieceIndex--] = address[compress + swaps - 1];
            address[compress + --swaps] = swap;
          }
        } else if (pieceIndex != 8) return;
        return address;
      };

      var findLongestZeroSequence = function (ipv6) {
        var maxIndex = null;
        var maxLength = 1;
        var currStart = null;
        var currLength = 0;
        var index = 0;
        for (; index < 8; index++) {
          if (ipv6[index] !== 0) {
            if (currLength > maxLength) {
              maxIndex = currStart;
              maxLength = currLength;
            }
            currStart = null;
            currLength = 0;
          } else {
            if (currStart === null) currStart = index;
            ++currLength;
          }
        }
        if (currLength > maxLength) {
          maxIndex = currStart;
          maxLength = currLength;
        }
        return maxIndex;
      };

      var serializeHost = function (host) {
        var result, index, compress, ignore0;
        // ipv4
        if (typeof host == 'number') {
          result = [];
          for (index = 0; index < 4; index++) {
            result.unshift(host % 256);
            host = floor(host / 256);
          } return result.join('.');
        // ipv6
        } else if (typeof host == 'object') {
          result = '';
          compress = findLongestZeroSequence(host);
          for (index = 0; index < 8; index++) {
            if (ignore0 && host[index] === 0) continue;
            if (ignore0) ignore0 = false;
            if (compress === index) {
              result += index ? ':' : '::';
              ignore0 = true;
            } else {
              result += host[index].toString(16);
              if (index < 7) result += ':';
            }
          }
          return '[' + result + ']';
        } return host;
      };

      var C0ControlPercentEncodeSet = {};
      var fragmentPercentEncodeSet = objectAssign({}, C0ControlPercentEncodeSet, {
        ' ': 1, '"': 1, '<': 1, '>': 1, '`': 1
      });
      var pathPercentEncodeSet = objectAssign({}, fragmentPercentEncodeSet, {
        '#': 1, '?': 1, '{': 1, '}': 1
      });
      var userinfoPercentEncodeSet = objectAssign({}, pathPercentEncodeSet, {
        '/': 1, ':': 1, ';': 1, '=': 1, '@': 1, '[': 1, '\\': 1, ']': 1, '^': 1, '|': 1
      });

      var percentEncode = function (char, set) {
        var code = codeAt(char, 0);
        return code > 0x20 && code < 0x7F && !has(set, char) ? char : encodeURIComponent(char);
      };

      var specialSchemes = {
        ftp: 21,
        file: null,
        http: 80,
        https: 443,
        ws: 80,
        wss: 443
      };

      var isSpecial = function (url) {
        return has(specialSchemes, url.scheme);
      };

      var includesCredentials = function (url) {
        return url.username != '' || url.password != '';
      };

      var cannotHaveUsernamePasswordPort = function (url) {
        return !url.host || url.cannotBeABaseURL || url.scheme == 'file';
      };

      var isWindowsDriveLetter = function (string, normalized) {
        var second;
        return string.length == 2 && ALPHA.test(string.charAt(0))
          && ((second = string.charAt(1)) == ':' || (!normalized && second == '|'));
      };

      var startsWithWindowsDriveLetter = function (string) {
        var third;
        return string.length > 1 && isWindowsDriveLetter(string.slice(0, 2)) && (
          string.length == 2 ||
          ((third = string.charAt(2)) === '/' || third === '\\' || third === '?' || third === '#')
        );
      };

      var shortenURLsPath = function (url) {
        var path = url.path;
        var pathSize = path.length;
        if (pathSize && (url.scheme != 'file' || pathSize != 1 || !isWindowsDriveLetter(path[0], true))) {
          path.pop();
        }
      };

      var isSingleDot = function (segment) {
        return segment === '.' || segment.toLowerCase() === '%2e';
      };

      var isDoubleDot = function (segment) {
        segment = segment.toLowerCase();
        return segment === '..' || segment === '%2e.' || segment === '.%2e' || segment === '%2e%2e';
      };

      // States:
      var SCHEME_START = {};
      var SCHEME = {};
      var NO_SCHEME = {};
      var SPECIAL_RELATIVE_OR_AUTHORITY = {};
      var PATH_OR_AUTHORITY = {};
      var RELATIVE = {};
      var RELATIVE_SLASH = {};
      var SPECIAL_AUTHORITY_SLASHES = {};
      var SPECIAL_AUTHORITY_IGNORE_SLASHES = {};
      var AUTHORITY = {};
      var HOST = {};
      var HOSTNAME = {};
      var PORT = {};
      var FILE = {};
      var FILE_SLASH = {};
      var FILE_HOST = {};
      var PATH_START = {};
      var PATH = {};
      var CANNOT_BE_A_BASE_URL_PATH = {};
      var QUERY = {};
      var FRAGMENT = {};

      // eslint-disable-next-line max-statements -- TODO
      var parseURL = function (url, input, stateOverride, base) {
        var state = stateOverride || SCHEME_START;
        var pointer = 0;
        var buffer = '';
        var seenAt = false;
        var seenBracket = false;
        var seenPasswordToken = false;
        var codePoints, char, bufferCodePoints, failure;

        if (!stateOverride) {
          url.scheme = '';
          url.username = '';
          url.password = '';
          url.host = null;
          url.port = null;
          url.path = [];
          url.query = null;
          url.fragment = null;
          url.cannotBeABaseURL = false;
          input = input.replace(LEADING_AND_TRAILING_C0_CONTROL_OR_SPACE, '');
        }

        input = input.replace(TAB_AND_NEW_LINE, '');

        codePoints = arrayFrom(input);

        while (pointer <= codePoints.length) {
          char = codePoints[pointer];
          switch (state) {
            case SCHEME_START:
              if (char && ALPHA.test(char)) {
                buffer += char.toLowerCase();
                state = SCHEME;
              } else if (!stateOverride) {
                state = NO_SCHEME;
                continue;
              } else return INVALID_SCHEME;
              break;

            case SCHEME:
              if (char && (ALPHANUMERIC.test(char) || char == '+' || char == '-' || char == '.')) {
                buffer += char.toLowerCase();
              } else if (char == ':') {
                if (stateOverride && (
                  (isSpecial(url) != has(specialSchemes, buffer)) ||
                  (buffer == 'file' && (includesCredentials(url) || url.port !== null)) ||
                  (url.scheme == 'file' && !url.host)
                )) return;
                url.scheme = buffer;
                if (stateOverride) {
                  if (isSpecial(url) && specialSchemes[url.scheme] == url.port) url.port = null;
                  return;
                }
                buffer = '';
                if (url.scheme == 'file') {
                  state = FILE;
                } else if (isSpecial(url) && base && base.scheme == url.scheme) {
                  state = SPECIAL_RELATIVE_OR_AUTHORITY;
                } else if (isSpecial(url)) {
                  state = SPECIAL_AUTHORITY_SLASHES;
                } else if (codePoints[pointer + 1] == '/') {
                  state = PATH_OR_AUTHORITY;
                  pointer++;
                } else {
                  url.cannotBeABaseURL = true;
                  url.path.push('');
                  state = CANNOT_BE_A_BASE_URL_PATH;
                }
              } else if (!stateOverride) {
                buffer = '';
                state = NO_SCHEME;
                pointer = 0;
                continue;
              } else return INVALID_SCHEME;
              break;

            case NO_SCHEME:
              if (!base || (base.cannotBeABaseURL && char != '#')) return INVALID_SCHEME;
              if (base.cannotBeABaseURL && char == '#') {
                url.scheme = base.scheme;
                url.path = base.path.slice();
                url.query = base.query;
                url.fragment = '';
                url.cannotBeABaseURL = true;
                state = FRAGMENT;
                break;
              }
              state = base.scheme == 'file' ? FILE : RELATIVE;
              continue;

            case SPECIAL_RELATIVE_OR_AUTHORITY:
              if (char == '/' && codePoints[pointer + 1] == '/') {
                state = SPECIAL_AUTHORITY_IGNORE_SLASHES;
                pointer++;
              } else {
                state = RELATIVE;
                continue;
              } break;

            case PATH_OR_AUTHORITY:
              if (char == '/') {
                state = AUTHORITY;
                break;
              } else {
                state = PATH;
                continue;
              }

            case RELATIVE:
              url.scheme = base.scheme;
              if (char == EOF) {
                url.username = base.username;
                url.password = base.password;
                url.host = base.host;
                url.port = base.port;
                url.path = base.path.slice();
                url.query = base.query;
              } else if (char == '/' || (char == '\\' && isSpecial(url))) {
                state = RELATIVE_SLASH;
              } else if (char == '?') {
                url.username = base.username;
                url.password = base.password;
                url.host = base.host;
                url.port = base.port;
                url.path = base.path.slice();
                url.query = '';
                state = QUERY;
              } else if (char == '#') {
                url.username = base.username;
                url.password = base.password;
                url.host = base.host;
                url.port = base.port;
                url.path = base.path.slice();
                url.query = base.query;
                url.fragment = '';
                state = FRAGMENT;
              } else {
                url.username = base.username;
                url.password = base.password;
                url.host = base.host;
                url.port = base.port;
                url.path = base.path.slice();
                url.path.pop();
                state = PATH;
                continue;
              } break;

            case RELATIVE_SLASH:
              if (isSpecial(url) && (char == '/' || char == '\\')) {
                state = SPECIAL_AUTHORITY_IGNORE_SLASHES;
              } else if (char == '/') {
                state = AUTHORITY;
              } else {
                url.username = base.username;
                url.password = base.password;
                url.host = base.host;
                url.port = base.port;
                state = PATH;
                continue;
              } break;

            case SPECIAL_AUTHORITY_SLASHES:
              state = SPECIAL_AUTHORITY_IGNORE_SLASHES;
              if (char != '/' || buffer.charAt(pointer + 1) != '/') continue;
              pointer++;
              break;

            case SPECIAL_AUTHORITY_IGNORE_SLASHES:
              if (char != '/' && char != '\\') {
                state = AUTHORITY;
                continue;
              } break;

            case AUTHORITY:
              if (char == '@') {
                if (seenAt) buffer = '%40' + buffer;
                seenAt = true;
                bufferCodePoints = arrayFrom(buffer);
                for (var i = 0; i < bufferCodePoints.length; i++) {
                  var codePoint = bufferCodePoints[i];
                  if (codePoint == ':' && !seenPasswordToken) {
                    seenPasswordToken = true;
                    continue;
                  }
                  var encodedCodePoints = percentEncode(codePoint, userinfoPercentEncodeSet);
                  if (seenPasswordToken) url.password += encodedCodePoints;
                  else url.username += encodedCodePoints;
                }
                buffer = '';
              } else if (
                char == EOF || char == '/' || char == '?' || char == '#' ||
                (char == '\\' && isSpecial(url))
              ) {
                if (seenAt && buffer == '') return INVALID_AUTHORITY;
                pointer -= arrayFrom(buffer).length + 1;
                buffer = '';
                state = HOST;
              } else buffer += char;
              break;

            case HOST:
            case HOSTNAME:
              if (stateOverride && url.scheme == 'file') {
                state = FILE_HOST;
                continue;
              } else if (char == ':' && !seenBracket) {
                if (buffer == '') return INVALID_HOST;
                failure = parseHost(url, buffer);
                if (failure) return failure;
                buffer = '';
                state = PORT;
                if (stateOverride == HOSTNAME) return;
              } else if (
                char == EOF || char == '/' || char == '?' || char == '#' ||
                (char == '\\' && isSpecial(url))
              ) {
                if (isSpecial(url) && buffer == '') return INVALID_HOST;
                if (stateOverride && buffer == '' && (includesCredentials(url) || url.port !== null)) return;
                failure = parseHost(url, buffer);
                if (failure) return failure;
                buffer = '';
                state = PATH_START;
                if (stateOverride) return;
                continue;
              } else {
                if (char == '[') seenBracket = true;
                else if (char == ']') seenBracket = false;
                buffer += char;
              } break;

            case PORT:
              if (DIGIT.test(char)) {
                buffer += char;
              } else if (
                char == EOF || char == '/' || char == '?' || char == '#' ||
                (char == '\\' && isSpecial(url)) ||
                stateOverride
              ) {
                if (buffer != '') {
                  var port = parseInt(buffer, 10);
                  if (port > 0xFFFF) return INVALID_PORT;
                  url.port = (isSpecial(url) && port === specialSchemes[url.scheme]) ? null : port;
                  buffer = '';
                }
                if (stateOverride) return;
                state = PATH_START;
                continue;
              } else return INVALID_PORT;
              break;

            case FILE:
              url.scheme = 'file';
              if (char == '/' || char == '\\') state = FILE_SLASH;
              else if (base && base.scheme == 'file') {
                if (char == EOF) {
                  url.host = base.host;
                  url.path = base.path.slice();
                  url.query = base.query;
                } else if (char == '?') {
                  url.host = base.host;
                  url.path = base.path.slice();
                  url.query = '';
                  state = QUERY;
                } else if (char == '#') {
                  url.host = base.host;
                  url.path = base.path.slice();
                  url.query = base.query;
                  url.fragment = '';
                  state = FRAGMENT;
                } else {
                  if (!startsWithWindowsDriveLetter(codePoints.slice(pointer).join(''))) {
                    url.host = base.host;
                    url.path = base.path.slice();
                    shortenURLsPath(url);
                  }
                  state = PATH;
                  continue;
                }
              } else {
                state = PATH;
                continue;
              } break;

            case FILE_SLASH:
              if (char == '/' || char == '\\') {
                state = FILE_HOST;
                break;
              }
              if (base && base.scheme == 'file' && !startsWithWindowsDriveLetter(codePoints.slice(pointer).join(''))) {
                if (isWindowsDriveLetter(base.path[0], true)) url.path.push(base.path[0]);
                else url.host = base.host;
              }
              state = PATH;
              continue;

            case FILE_HOST:
              if (char == EOF || char == '/' || char == '\\' || char == '?' || char == '#') {
                if (!stateOverride && isWindowsDriveLetter(buffer)) {
                  state = PATH;
                } else if (buffer == '') {
                  url.host = '';
                  if (stateOverride) return;
                  state = PATH_START;
                } else {
                  failure = parseHost(url, buffer);
                  if (failure) return failure;
                  if (url.host == 'localhost') url.host = '';
                  if (stateOverride) return;
                  buffer = '';
                  state = PATH_START;
                } continue;
              } else buffer += char;
              break;

            case PATH_START:
              if (isSpecial(url)) {
                state = PATH;
                if (char != '/' && char != '\\') continue;
              } else if (!stateOverride && char == '?') {
                url.query = '';
                state = QUERY;
              } else if (!stateOverride && char == '#') {
                url.fragment = '';
                state = FRAGMENT;
              } else if (char != EOF) {
                state = PATH;
                if (char != '/') continue;
              } break;

            case PATH:
              if (
                char == EOF || char == '/' ||
                (char == '\\' && isSpecial(url)) ||
                (!stateOverride && (char == '?' || char == '#'))
              ) {
                if (isDoubleDot(buffer)) {
                  shortenURLsPath(url);
                  if (char != '/' && !(char == '\\' && isSpecial(url))) {
                    url.path.push('');
                  }
                } else if (isSingleDot(buffer)) {
                  if (char != '/' && !(char == '\\' && isSpecial(url))) {
                    url.path.push('');
                  }
                } else {
                  if (url.scheme == 'file' && !url.path.length && isWindowsDriveLetter(buffer)) {
                    if (url.host) url.host = '';
                    buffer = buffer.charAt(0) + ':'; // normalize windows drive letter
                  }
                  url.path.push(buffer);
                }
                buffer = '';
                if (url.scheme == 'file' && (char == EOF || char == '?' || char == '#')) {
                  while (url.path.length > 1 && url.path[0] === '') {
                    url.path.shift();
                  }
                }
                if (char == '?') {
                  url.query = '';
                  state = QUERY;
                } else if (char == '#') {
                  url.fragment = '';
                  state = FRAGMENT;
                }
              } else {
                buffer += percentEncode(char, pathPercentEncodeSet);
              } break;

            case CANNOT_BE_A_BASE_URL_PATH:
              if (char == '?') {
                url.query = '';
                state = QUERY;
              } else if (char == '#') {
                url.fragment = '';
                state = FRAGMENT;
              } else if (char != EOF) {
                url.path[0] += percentEncode(char, C0ControlPercentEncodeSet);
              } break;

            case QUERY:
              if (!stateOverride && char == '#') {
                url.fragment = '';
                state = FRAGMENT;
              } else if (char != EOF) {
                if (char == "'" && isSpecial(url)) url.query += '%27';
                else if (char == '#') url.query += '%23';
                else url.query += percentEncode(char, C0ControlPercentEncodeSet);
              } break;

            case FRAGMENT:
              if (char != EOF) url.fragment += percentEncode(char, fragmentPercentEncodeSet);
              break;
          }

          pointer++;
        }
      };

      // `URL` constructor
      // https://url.spec.whatwg.org/#url-class
      var URLConstructor = function URL(url /* , base */) {
        var that = anInstance(this, URLConstructor, 'URL');
        var base = arguments.length > 1 ? arguments[1] : undefined;
        var urlString = toString_1(url);
        var state = setInternalState(that, { type: 'URL' });
        var baseState, failure;
        if (base !== undefined) {
          if (base instanceof URLConstructor) baseState = getInternalURLState(base);
          else {
            failure = parseURL(baseState = {}, toString_1(base));
            if (failure) throw TypeError(failure);
          }
        }
        failure = parseURL(state, urlString, null, baseState);
        if (failure) throw TypeError(failure);
        var searchParams = state.searchParams = new URLSearchParams$1();
        var searchParamsState = getInternalSearchParamsState(searchParams);
        searchParamsState.updateSearchParams(state.query);
        searchParamsState.updateURL = function () {
          state.query = String(searchParams) || null;
        };
        if (!descriptors) {
          that.href = serializeURL.call(that);
          that.origin = getOrigin.call(that);
          that.protocol = getProtocol.call(that);
          that.username = getUsername.call(that);
          that.password = getPassword.call(that);
          that.host = getHost.call(that);
          that.hostname = getHostname.call(that);
          that.port = getPort.call(that);
          that.pathname = getPathname.call(that);
          that.search = getSearch.call(that);
          that.searchParams = getSearchParams.call(that);
          that.hash = getHash.call(that);
        }
      };

      var URLPrototype = URLConstructor.prototype;

      var serializeURL = function () {
        var url = getInternalURLState(this);
        var scheme = url.scheme;
        var username = url.username;
        var password = url.password;
        var host = url.host;
        var port = url.port;
        var path = url.path;
        var query = url.query;
        var fragment = url.fragment;
        var output = scheme + ':';
        if (host !== null) {
          output += '//';
          if (includesCredentials(url)) {
            output += username + (password ? ':' + password : '') + '@';
          }
          output += serializeHost(host);
          if (port !== null) output += ':' + port;
        } else if (scheme == 'file') output += '//';
        output += url.cannotBeABaseURL ? path[0] : path.length ? '/' + path.join('/') : '';
        if (query !== null) output += '?' + query;
        if (fragment !== null) output += '#' + fragment;
        return output;
      };

      var getOrigin = function () {
        var url = getInternalURLState(this);
        var scheme = url.scheme;
        var port = url.port;
        if (scheme == 'blob') try {
          return new URLConstructor(scheme.path[0]).origin;
        } catch (error) {
          return 'null';
        }
        if (scheme == 'file' || !isSpecial(url)) return 'null';
        return scheme + '://' + serializeHost(url.host) + (port !== null ? ':' + port : '');
      };

      var getProtocol = function () {
        return getInternalURLState(this).scheme + ':';
      };

      var getUsername = function () {
        return getInternalURLState(this).username;
      };

      var getPassword = function () {
        return getInternalURLState(this).password;
      };

      var getHost = function () {
        var url = getInternalURLState(this);
        var host = url.host;
        var port = url.port;
        return host === null ? ''
          : port === null ? serializeHost(host)
          : serializeHost(host) + ':' + port;
      };

      var getHostname = function () {
        var host = getInternalURLState(this).host;
        return host === null ? '' : serializeHost(host);
      };

      var getPort = function () {
        var port = getInternalURLState(this).port;
        return port === null ? '' : String(port);
      };

      var getPathname = function () {
        var url = getInternalURLState(this);
        var path = url.path;
        return url.cannotBeABaseURL ? path[0] : path.length ? '/' + path.join('/') : '';
      };

      var getSearch = function () {
        var query = getInternalURLState(this).query;
        return query ? '?' + query : '';
      };

      var getSearchParams = function () {
        return getInternalURLState(this).searchParams;
      };

      var getHash = function () {
        var fragment = getInternalURLState(this).fragment;
        return fragment ? '#' + fragment : '';
      };

      var accessorDescriptor = function (getter, setter) {
        return { get: getter, set: setter, configurable: true, enumerable: true };
      };

      if (descriptors) {
        objectDefineProperties(URLPrototype, {
          // `URL.prototype.href` accessors pair
          // https://url.spec.whatwg.org/#dom-url-href
          href: accessorDescriptor(serializeURL, function (href) {
            var url = getInternalURLState(this);
            var urlString = toString_1(href);
            var failure = parseURL(url, urlString);
            if (failure) throw TypeError(failure);
            getInternalSearchParamsState(url.searchParams).updateSearchParams(url.query);
          }),
          // `URL.prototype.origin` getter
          // https://url.spec.whatwg.org/#dom-url-origin
          origin: accessorDescriptor(getOrigin),
          // `URL.prototype.protocol` accessors pair
          // https://url.spec.whatwg.org/#dom-url-protocol
          protocol: accessorDescriptor(getProtocol, function (protocol) {
            var url = getInternalURLState(this);
            parseURL(url, toString_1(protocol) + ':', SCHEME_START);
          }),
          // `URL.prototype.username` accessors pair
          // https://url.spec.whatwg.org/#dom-url-username
          username: accessorDescriptor(getUsername, function (username) {
            var url = getInternalURLState(this);
            var codePoints = arrayFrom(toString_1(username));
            if (cannotHaveUsernamePasswordPort(url)) return;
            url.username = '';
            for (var i = 0; i < codePoints.length; i++) {
              url.username += percentEncode(codePoints[i], userinfoPercentEncodeSet);
            }
          }),
          // `URL.prototype.password` accessors pair
          // https://url.spec.whatwg.org/#dom-url-password
          password: accessorDescriptor(getPassword, function (password) {
            var url = getInternalURLState(this);
            var codePoints = arrayFrom(toString_1(password));
            if (cannotHaveUsernamePasswordPort(url)) return;
            url.password = '';
            for (var i = 0; i < codePoints.length; i++) {
              url.password += percentEncode(codePoints[i], userinfoPercentEncodeSet);
            }
          }),
          // `URL.prototype.host` accessors pair
          // https://url.spec.whatwg.org/#dom-url-host
          host: accessorDescriptor(getHost, function (host) {
            var url = getInternalURLState(this);
            if (url.cannotBeABaseURL) return;
            parseURL(url, toString_1(host), HOST);
          }),
          // `URL.prototype.hostname` accessors pair
          // https://url.spec.whatwg.org/#dom-url-hostname
          hostname: accessorDescriptor(getHostname, function (hostname) {
            var url = getInternalURLState(this);
            if (url.cannotBeABaseURL) return;
            parseURL(url, toString_1(hostname), HOSTNAME);
          }),
          // `URL.prototype.port` accessors pair
          // https://url.spec.whatwg.org/#dom-url-port
          port: accessorDescriptor(getPort, function (port) {
            var url = getInternalURLState(this);
            if (cannotHaveUsernamePasswordPort(url)) return;
            port = toString_1(port);
            if (port == '') url.port = null;
            else parseURL(url, port, PORT);
          }),
          // `URL.prototype.pathname` accessors pair
          // https://url.spec.whatwg.org/#dom-url-pathname
          pathname: accessorDescriptor(getPathname, function (pathname) {
            var url = getInternalURLState(this);
            if (url.cannotBeABaseURL) return;
            url.path = [];
            parseURL(url, toString_1(pathname), PATH_START);
          }),
          // `URL.prototype.search` accessors pair
          // https://url.spec.whatwg.org/#dom-url-search
          search: accessorDescriptor(getSearch, function (search) {
            var url = getInternalURLState(this);
            search = toString_1(search);
            if (search == '') {
              url.query = null;
            } else {
              if ('?' == search.charAt(0)) search = search.slice(1);
              url.query = '';
              parseURL(url, search, QUERY);
            }
            getInternalSearchParamsState(url.searchParams).updateSearchParams(url.query);
          }),
          // `URL.prototype.searchParams` getter
          // https://url.spec.whatwg.org/#dom-url-searchparams
          searchParams: accessorDescriptor(getSearchParams),
          // `URL.prototype.hash` accessors pair
          // https://url.spec.whatwg.org/#dom-url-hash
          hash: accessorDescriptor(getHash, function (hash) {
            var url = getInternalURLState(this);
            hash = toString_1(hash);
            if (hash == '') {
              url.fragment = null;
              return;
            }
            if ('#' == hash.charAt(0)) hash = hash.slice(1);
            url.fragment = '';
            parseURL(url, hash, FRAGMENT);
          })
        });
      }

      // `URL.prototype.toJSON` method
      // https://url.spec.whatwg.org/#dom-url-tojson
      redefine(URLPrototype, 'toJSON', function toJSON() {
        return serializeURL.call(this);
      }, { enumerable: true });

      // `URL.prototype.toString` method
      // https://url.spec.whatwg.org/#URL-stringification-behavior
      redefine(URLPrototype, 'toString', function toString() {
        return serializeURL.call(this);
      }, { enumerable: true });

      if (NativeURL) {
        var nativeCreateObjectURL = NativeURL.createObjectURL;
        var nativeRevokeObjectURL = NativeURL.revokeObjectURL;
        // `URL.createObjectURL` method
        // https://developer.mozilla.org/en-US/docs/Web/API/URL/createObjectURL
        // eslint-disable-next-line no-unused-vars -- required for `.length`
        if (nativeCreateObjectURL) redefine(URLConstructor, 'createObjectURL', function createObjectURL(blob) {
          return nativeCreateObjectURL.apply(NativeURL, arguments);
        });
        // `URL.revokeObjectURL` method
        // https://developer.mozilla.org/en-US/docs/Web/API/URL/revokeObjectURL
        // eslint-disable-next-line no-unused-vars -- required for `.length`
        if (nativeRevokeObjectURL) redefine(URLConstructor, 'revokeObjectURL', function revokeObjectURL(url) {
          return nativeRevokeObjectURL.apply(NativeURL, arguments);
        });
      }

      setToStringTag(URLConstructor, 'URL');

      _export({ global: true, forced: !nativeUrl, sham: !descriptors }, {
        URL: URLConstructor
      });

      // `URL.prototype.toJSON` method
      // https://url.spec.whatwg.org/#dom-url-tojson
      _export({ target: 'URL', proto: true, enumerable: true }, {
        toJSON: function toJSON() {
          return URL.prototype.toString.call(this);
        }
      });

      path.URL;

      class Receiver {
          constructor(instance, configList, options = {}) {
              this.handleMap = {};
              this.isDestroy = false;
              this.instance = instance;
              this.afterReceiveHook = options.afterReceiveHook;
              configList.forEach((handlerConfig) => {
                  this.handleMap[handlerConfig.name] = handlerConfig.handler;
              });
          }
          destroy() {
              this.isDestroy = true;
          }
          receive(tasks) {
              if (this.isDestroy) {
                  runtimeLogger.error('实例已经销毁，无法接收调用');
                  return;
              }
              if (!this.instance.isReady) {
                  throw new Error('实例未加载');
              }
              let resultList = [];
              for (let task of tasks) {
                  let handler = this.handleMap[task.name];
                  let result;
                  if (handler) {
                      try {
                          result = handler(this.instance, ...(task.args || []));
                      }
                      catch (e) {
                          getGlobal().baseLibApi.reportError(this.instance.id, e.name, e.message, e.stack);
                      }
                  }
                  resultList.push(result);
              }
              if (this.afterReceiveHook) {
                  this.afterReceiveHook();
              }
              return JSON.stringify(resultList);
          }
      }

      const CALLBACK_ID_MAX = 1000000000;
      class CallbackManager {
          constructor() {
              this.lastCallbackId = 0;
              this.callbacks = [];
          }
          add(callback) {
              if (this.lastCallbackId < CALLBACK_ID_MAX) {
                  this.lastCallbackId++;
              }
              else {
                  this.lastCallbackId = 1;
              }
              let currentId = this.lastCallbackId;
              this.callbacks[currentId] = callback;
              callback.__dispose = () => {
                  this.remove(currentId);
              };
              return currentId;
          }
          remove(callbackId) {
              let callback;
              if (isNumber(callbackId)) {
                  callback = this.callbacks[callbackId];
                  delete this.callbacks[callbackId];
              }
              else {
                  const index = this.callbacks.findIndex(callbackId);
                  callback = this.callbacks[index];
                  delete this.callbacks[index];
              }
              return callback;
          }
          trigger(callbackId, data, keepAlive = false) {
              const callback = this.callbacks[callbackId];
              if (!keepAlive) {
                  delete this.callbacks[callbackId];
              }
              if (typeof callback === 'function') {
                  if (isArray$1(data)) {
                      return callback.apply(null, data);
                  }
                  else {
                      return callback.call(null, data);
                  }
              }
              else {
                  throw new Error('callback not found: ' + callbackId);
              }
          }
          destroy() {
              this.callbacks = [];
          }
      }

      function isLocal(prop) {
          return 'localId' in prop;
      }
      class InstanceContext {
          constructor(instance) {
              const theGlobal = getGlobal();
              this.Promise = getPromise(instance.runtimeProps);
              this.URL = theGlobal.URL;
              this.debugData = instance.debugData;
              this.fetch = getFetch(instance.runtimeProps);
          }
      }
      class BaseInstance {
          constructor(props) {
              this.reportInfo = {};
              this.id = -9999;
              this.runtimeProps = {};
              this.runtimeContext = {};
              this.callbackManager = new CallbackManager();
              this.syncCallManager = new SyncCallManager();
              this.isReady = false;
              this.libsMap = {};
              this.debugData = {};
              this.name = 'unnamed';
              this.moduleCache = {};
              this.currentUniqueId = 1;
              this.timerDisposers = {
                  setTimeout: [],
                  setInterval: []
              };
              if (isLocal(props)) {
                  this.localId = props.localId;
              }
              else {
                  this.id = props.id;
                  this.localId = props.id;
                  this.isReady = true;
              }
              this.execLib = props.execLib;
              this.baseLibModule = baseLibModuleBuilder(this);
              this.config = props.config;
              this.runtimeConfig = props.runtimeConfig;
          }
          setRuntimeContext(context) {
              this.runtimeContext = context;
          }
          wrapTimer(timerName, customerPostFn) {
              let timer = this.timerDisposers[timerName];
              return (func, delay, ...args) => {
                  let id = getGlobal()[timerName].call(null, () => {
                      try {
                          func();
                          if (customerPostFn)
                              customerPostFn();
                      }
                      catch (e) {
                          this.receiver.receive([
                              {
                                  name: ReceiverType.globalEvent,
                                  args: ['error', [e, 'uncaughtException']]
                              }
                          ]);
                          getGlobal().baseLibApi.reportError(this.id, 'timer', e.message, e.stack);
                      }
                      timer.splice(timer.indexOf(id), 1);
                  }, delay, ...args);
                  timer.push(id);
                  return id;
              };
          }
          startUp(instanceId, { name }) {
              this.id = instanceId;
              this.runtimeProps.id = instanceId;
              this.isReady = true;
              if (name) {
                  this.name = name;
              }
              this.apiCenter.startUp();
          }
          uniqueId() {
              return this.currentUniqueId++;
          }
          destroy() {
              this.reportInfo.callbackNumAtDestroy = this.callbackManager.callbacks.length;
              this.reportInfo.moduleRequireNumber = this.moduleManager.requireNumber;
              this.timerDisposers.setTimeout.forEach(id => {
                  getGlobal().clearTimeout(id);
              });
              this.timerDisposers.setInterval.forEach(id => {
                  getGlobal().clearInterval(id);
              });
              this.receiver.destroy();
              this.apiCenter.destroy();
              this.injectContext.Promise.destroy();
          }
          debugMode() { }
          afterRunCode() {
              this.reportInfo.callbackNumAtFirstRun = this.callbackManager.callbacks.length;
          }
          requirePrivateModule(moduleName) {
              let targetModule = this.moduleCache[moduleName];
              if (isUndefined(targetModule)) {
                  targetModule = this.moduleManager.requirePrivateModule(this, moduleName);
                  if (targetModule) {
                      this.moduleCache[moduleName] = targetModule;
                  }
              }
              return targetModule;
          }
          requireModule(moduleName) {
              let targetModule = this.moduleCache[moduleName];
              if (isUndefined(targetModule)) {
                  targetModule = Object.seal(this.moduleManager.requireModule(this, moduleName));
                  if (targetModule) {
                      this.moduleCache[moduleName] = targetModule;
                  }
              }
              return targetModule;
          }
          dynamicImport(moduleName) {
              return new Promise((resolve, reject) => {
                  if (isUndefined(this.libsMap[moduleName])) {
                      this.baseLibModule.loadLib(moduleName, (error, info) => {
                          if (error || !info) {
                              reject(error);
                          }
                          else {
                              resolve(this.libsMap[moduleName]);
                          }
                      });
                  }
                  else {
                      resolve(this.libsMap[moduleName]);
                  }
              });
          }
      }

      class ModuleManager {
          constructor(moduleSnapshotConfig = {}) {
              this.moduleSnapshotConfig = moduleSnapshotConfig;
              this.requireNumber = 0;
              this.register = Register.getInstance();
              this.localModuleBuilders = {};
          }
          get moduleNames() {
              return Object.keys(this.localModuleBuilders).concat(this.register.publicModuleNames);
          }
          add(name, moduleBuilder) {
              this.localModuleBuilders[name] = moduleBuilder;
          }
          requireModule(instance, name) {
              if (this.localModuleBuilders[name]) {
                  this.requireNumber++;
                  return this.bindLocalModules(instance, this.localModuleBuilders[name]);
              }
              const moduleInfo = this.register.modulesInfo[name];
              if (moduleInfo && !moduleInfo.private) {
                  this.requireNumber++;
                  return this.bindRegisterModules(instance, name, this.register.modulesInfo[name]);
              }
              developLogger.error(`加载了不存在的 Module "${name}"`);
          }
          bingRegisterModuleMethods(instance, boundModule, moduleName, moduleInfo) {
              const methods = moduleInfo.methods;
              for (const method of methods) {
                  this.bingRegisterModuleMethod(instance, boundModule, moduleName, method, moduleInfo);
              }
          }
          bingRegisterModuleAccessorProps(instance, boundModule, moduleInfo) {
              const accessorProps = moduleInfo.accessorProps;
              if (accessorProps) {
                  for (const accessorInfo of accessorProps) {
                      let camelCaseAccessorName = accessorInfo.name[0].toUpperCase() + accessorInfo.name.slice(1);
                      let getKey = `get${camelCaseAccessorName}`;
                      let setKey = accessorInfo.setter ? `set${camelCaseAccessorName}` : '';
                      Object.defineProperty(boundModule, accessorInfo.name, {
                          enumerable: true,
                          configurable: true,
                          get: () => {
                              return instance.apiCenter.callApi(ApiType.global, {
                                  globalKey: moduleInfo.bridge.name,
                                  methodInfo: {
                                      name: getKey,
                                      result: accessorInfo.getter.result,
                                      params: []
                                  },
                                  method: getKey,
                                  args: []
                              });
                          },
                          set: setKey
                              ? (value) => {
                                  return instance.apiCenter.callApi(ApiType.global, {
                                      globalKey: moduleInfo.bridge.name,
                                      methodInfo: {
                                          name: setKey,
                                          params: accessorInfo.setter && [accessorInfo.setter.param]
                                      },
                                      method: setKey,
                                      args: [value]
                                  });
                              }
                              : undefined
                      });
                  }
              }
          }
          bindRegisterModules(instance, moduleName, moduleInfo) {
              const boundModule = {};
              const bridge = moduleInfo.bridge;
              const snapshotConfig = this.moduleSnapshotConfig[moduleName];
              const apiType = bridge.type === 'global' ? ApiType.global : ApiType.dynamic;
              if (snapshotConfig) {
                  boundModule.__lite__ = {
                      snapshotConfig,
                      snapshotCallLastCallMap: {},
                      replay: records => {
                          for (let record of records) {
                              let methodInfo = moduleInfo.methods.find(methodInfo => {
                                  return methodInfo.name === record.method;
                              });
                              if (methodInfo) {
                                  instance.apiCenter.callApi(apiType, {
                                      globalKey: bridge.name,
                                      methodInfo,
                                      method: methodInfo.name,
                                      args: record.args
                                  });
                              }
                              else {
                                  runtimeLogger.error('[view] replay module record with method not exist');
                              }
                          }
                      }
                  };
              }
              this.bingRegisterModuleMethods(instance, boundModule, moduleName, moduleInfo);
              this.bingRegisterModuleAccessorProps(instance, boundModule, moduleInfo);
              const props = moduleInfo.props;
              Object.assign(boundModule, props);
              return boundModule;
          }
          bindLocalModules(instance, builder) {
              const localModule = builder(instance);
              return localModule;
          }
          requirePrivateModule(instance, name) {
              const moduleInfo = this.register.modulesInfo[name];
              if (moduleInfo) {
                  return this.bindRegisterModules(instance, name, this.register.modulesInfo[name]);
              }
          }
          bingRegisterModuleMethod(instance, boundModule, moduleName, methodInfo, moduleInfo) {
              const bridge = moduleInfo.bridge;
              let methodCaller;
              if (bridge.type === 'global') {
                  if (boundModule.__lite__ &&
                      boundModule.__lite__.snapshotConfig[methodInfo.name] &&
                      boundModule.__lite__.snapshotConfig[methodInfo.name].type === ModuleSnapshotType.lastCall) {
                      const callMap = boundModule.__lite__.snapshotCallLastCallMap;
                      methodCaller = (...args) => {
                          callMap[methodInfo.name] = {
                              method: methodInfo.name,
                              args
                          };
                          return instance.apiCenter.callApi(ApiType.global, {
                              globalKey: moduleInfo.bridge.name,
                              methodInfo,
                              method: methodInfo.name,
                              args
                          });
                      };
                  }
                  else {
                      methodCaller = (...args) => {
                          return instance.apiCenter.callApi(ApiType.global, {
                              globalKey: moduleInfo.bridge.name,
                              methodInfo,
                              method: methodInfo.name,
                              args
                          });
                      };
                  }
              }
              else {
                  methodCaller = (...args) => {
                      return instance.apiCenter.callApi(ApiType.dynamic, {
                          moduleName,
                          methodInfo,
                          method: methodInfo.name,
                          args
                      });
                  };
              }
              Object.defineProperty(boundModule, methodInfo.name, {
                  enumerable: false,
                  configurable: false,
                  get: () => {
                      return methodCaller;
                  }
              });
          }
      }

      class StoreModuleManager extends ModuleManager {
          static getInstance() {
              if (!StoreModuleManager.instance) {
                  StoreModuleManager.instance = new StoreModuleManager();
              }
              return StoreModuleManager.instance;
          }
      }

      class LiteProxy {
          constructor(instance, extendMethods = []) {
              this.methodNames = ['requireLib', 'requireModule', 'addEventListener', 'removeEventListener'];
              const ownKeys = this.methodNames.concat(instance.moduleManager.moduleNames, extendMethods);
              this.instance = instance;
              return new Proxy(this, {
                  ownKeys() {
                      return ownKeys;
                  },
                  getOwnPropertyDescriptor(target, prop) {
                      if (isString(prop)) {
                          if (target.methodNames.indexOf(prop) > -1) {
                              return {
                                  enumerable: false,
                                  configurable: true,
                              };
                          }
                          else {
                              return {
                                  enumerable: true,
                                  configurable: true,
                              };
                          }
                      }
                      return undefined;
                  },
                  get(target, prop) {
                      let targetValue = Reflect.get(target, prop);
                      if (isUndefined(targetValue) && isString(prop)) {
                          targetValue = target.requireModule(prop);
                      }
                      return targetValue;
                  },
                  set() {
                      return false;
                  },
              });
          }
          requireLib(moduleName) {
              return this.instance.dynamicImport.call(this.instance, moduleName);
          }
          requireModule(moduleName) {
              return this.instance.requireModule(moduleName);
          }
          addEventListener(eventType, listener) {
              this.instance.globalEventManager.addEventListener(eventType, listener);
          }
          removeEventListener(eventType, listener) {
              this.instance.globalEventManager.removeEventListener(eventType, listener);
          }
      }

      class LiteProxyForStore extends LiteProxy {
          constructor(instance) {
              super(instance, []);
          }
      }

      class StoreInstanceContext extends InstanceContext {
          constructor(instance) {
              super(instance);
              this.setTimeout = instance.wrapTimer('setTimeout');
              this.setInterval = instance.wrapTimer('setInterval');
              this.lite = new LiteProxyForStore(instance);
          }
      }
      class StoreInstance extends BaseInstance {
          constructor(props) {
              super(props);
              this.reportInfo.type = 'store';
              this.apiCenter = new ApiCenter({
                  callbackManager: this.callbackManager,
                  instance: this,
              });
              this.receiver = new Receiver(this, [CallbackHandler, GlobalEventHandler, SyncCallHandlerHandler]);
              this.moduleManager = StoreModuleManager.getInstance();
              this.globalEventManager = new EventManagerClass(this);
              this.injectContext = new StoreInstanceContext(this);
          }
          startUp(instanceId, config) {
              super.startUp(instanceId, config);
              ReportTimer.start(`Store startUp${this.id}`);
          }
          destroy() {
              super.destroy();
          }
          getContext() {
              return this.injectContext;
          }
      }

      class AsyncErrorDetector {
          constructor(instanceManager) {
              this.instanceManager = instanceManager;
              this.listen();
          }
          setUp(runnerConfig) {
              this.matcher = new RegExp(`${codeTemplatePrefix}(\\w+)_${runnerConfig.uuid}__`);
          }
          dispatchError(tasks, parseResult) {
              if (parseResult) {
                  this.instanceManager.receive(parseResult.instanceId, tasks);
              }
          }
          reportError(type, error, parseResult) {
              if (parseResult) {
                  getGlobal().baseLibApi.reportError(parseResult.instanceId, type, error.message, error.stack);
              }
              else {
                  getGlobal().baseLibApi.reportError(0, type, error.message, error.stack);
              }
          }
          stackParse(error) {
              if (!this.matcher)
                  throw new Error('need setUp');
              if (!error || !error.stack)
                  return undefined;
              let matchResult = error.stack.match(this.matcher);
              if (!matchResult)
                  return undefined;
              let instanceId = matchResult[1];
              return {
                  instanceId: parseInt(instanceId, 10)
              };
          }
          errorHandle(type, promise, reason) {
              let tasks = [
                  {
                      name: ReceiverType.globalEvent,
                      args: ['error', [reason, 'unhandledRejection', promise]]
                  }
              ];
              if (promise && !isUndefined(promise.id)) {
                  try {
                      this.instanceManager.receive(promise.id, tasks);
                  }
                  finally {
                      if (reason) {
                          getGlobal().baseLibApi.reportError(promise.id, type, reason.message || reason.toString(), reason.stack);
                      }
                      else {
                          getGlobal().baseLibApi.reportError(promise.id, type, 'no reason', '');
                      }
                  }
              }
              else {
                  let parseResult = this.stackParse(reason);
                  this.dispatchError(tasks, parseResult);
                  this.reportError(type, reason, parseResult);
              }
          }
          listen() {
              getGlobal().onunhandledrejection = ({ promise, reason }) => {
                  this.errorHandle('promise', promise, reason);
              };
              getGlobal().wxajs.setPromiseRejectCallback((type, promise, reason) => {
                  try {
                      this.errorHandle(type || 'promise', promise, reason);
                  }
                  catch (e) {
                      getGlobal().baseLibApi.reportError(0, 'system', e.message, e.stack);
                  }
              });
          }
      }

      const PREPARE_DELAY = 50;
      class InstanceManager {
          constructor(option) {
              this.runtimeConfig = {
                  baseLibInfo: {
                      version: '1.5.1',
                      buildTarget: 'undefined',
                      buildType: 'development',
                  },
              };
              this.preCreateInstanceNum = 0;
              this.instanceMap = {};
              this.preCreateInstanceCache = {};
              this.currentLocalInstanceId = 10000;
              this.InstanceType = option.InstanceType;
              this.contextTransform = option.contextTransform;
              if (option.AsyncErrorDetector) {
                  this.asyncErrorDetector = new option.AsyncErrorDetector(this);
              }
              else {
                  this.asyncErrorDetector = new AsyncErrorDetector(this);
              }
          }
          get uniqLocalId() {
              return this.currentLocalInstanceId++;
          }
          setUp(setUpConfig) {
              if (!setUpConfig.runnerConfig)
                  throw new Error('初始化缺少参数： runnerConfig');
              this.asyncErrorDetector.setUp(setUpConfig.runnerConfig);
              this.runtimeConfig.hostInfo = setUpConfig.hostInfo;
              this.runtimeConfig.runnerConfig = setUpConfig.runnerConfig;
          }
          receive(id, tasks) {
              let runtimeInstance = this.findRuntimeInstance(id);
              if (runtimeInstance) {
                  return runtimeInstance.instance.receiver.receive(tasks);
              }
          }
          findRuntimeInstance(id) {
              return this.instanceMap[id];
          }
          destroyInstance(id) {
              const runtimeInstance = this.instanceMap[id];
              if (runtimeInstance) {
                  runtimeInstance.framework.destroyInstance(id);
                  runtimeInstance.instance.destroy();
                  Reporter.reportRuntimeInfo(runtimeInstance.instance.reportInfo);
                  delete this.instanceMap[id];
              }
          }
          createInstance(info) {
              if (this.instanceMap[info.id]) {
                  throw new Error(`The instance id "${info.id}" has already been used!`);
              }
              let runtimeInstance = this.getPreCreateInstance(info);
              runtimeInstance.instance.startUp(info.id, {
                  name: info.resource.name,
                  config: info.config,
              });
              this.instanceMap[info.id] = runtimeInstance;
              this.runInContext(info.resource, runtimeInstance);
              runtimeInstance.instance.afterRunCode();
              setTimeout(() => {
                  this.preparePreCreateInstance(info);
              }, PREPARE_DELAY);
              return runtimeInstance;
          }
          runCodeInInstance(info) {
              const runtimeInstance = this.findRuntimeInstance(info.id);
              if (isUndefined(runtimeInstance)) {
                  throw new Error('请先创建实例');
              }
              this.runInContext(info.resource, runtimeInstance);
          }
          preparePreCreateInstance(info) {
              let cacheList = this.preCreateInstanceCache[info.config.frameworkType];
              if (!cacheList) {
                  cacheList = this.preCreateInstanceCache[info.config.frameworkType] = [];
              }
              while (cacheList.length < this.preCreateInstanceNum) {
                  cacheList.push(this.preCreateInstance(info));
              }
          }
          runCodeInContext(func, runtimeInstance) {
              func.call(runtimeInstance.context, runtimeInstance.context);
          }
          getPreCreateInstance(info) {
              let cacheList = this.preCreateInstanceCache[info.config.frameworkType];
              if (cacheList && isNonEmptyArray(cacheList)) {
                  return cacheList.pop();
              }
              else {
                  return this.preCreateInstance(info);
              }
          }
          preCreateInstance(info) {
              let instance = new this.InstanceType({
                  localId: this.uniqLocalId,
                  config: info.config,
                  runtimeConfig: this.runtimeConfig,
                  execLib: (libInfo) => {
                      this.runLibInContext(libInfo, runtimeInstance);
                  },
              });
              const context = this.createInstanceContext(info.framework, instance);
              const runtimeInstance = {
                  instance,
                  framework: info.framework,
                  context,
              };
              return runtimeInstance;
          }
          runLibInContext(info, runtimeInstance) {
              let module = {
                  exports: {},
              };
              info.code.call(runtimeInstance.context, module, runtimeInstance.context);
              return (runtimeInstance.instance.libsMap[info.name] = module.exports);
          }
          runInContext(resource, runtimeInstance) {
              if (resource.libs) {
                  for (const libInfo of resource.libs) {
                      this.runLibInContext(libInfo, runtimeInstance);
                  }
              }
              Object.seal(runtimeInstance.instance);
              Object.seal(runtimeInstance);
              if (resource.code) {
                  this.runCodeInContext(resource.code, runtimeInstance);
              }
          }
          createInstanceContext(framework, liteInstance) {
              let runtimeContext = liteInstance.getContext();
              let instanceContext = runtimeContext;
              if (this.contextTransform) {
                  instanceContext = this.contextTransform(liteInstance, instanceContext);
              }
              Object.assign(instanceContext, framework.createInstanceContext(liteInstance.localId, runtimeContext, liteInstance), {
                  globalThis: instanceContext,
                  global: instanceContext,
                  self: instanceContext,
              });
              return instanceContext;
          }
      }

      const NotFramework = {
          createInstanceContext() {
              return {};
          },
          destroyInstance() { },
          refreshInstance() { }
      };

      const registerInstance = Register.getInstance();
      function bootstrap (manager, frameworks) {
          const targetGlobal = getGlobal();
          frameworks.NotFramework = NotFramework;
          Object.assign(targetGlobal, {
              runInInstance(id, resource) {
                  return manager.runCodeInInstance({
                      id,
                      resource
                  });
              },
              createInstance: (id, resource, instanceConfig) => {
                  return manager.createInstance({
                      id,
                      resource,
                      config: instanceConfig,
                      framework: frameworks[instanceConfig.frameworkType]
                  });
              },
              destroyInstance: (id) => {
                  manager.destroyInstance(id);
              },
              callJS(id, tasks) {
                  return manager.receive(id, tasks);
              },
              register(packets) {
                  registerInstance.register(packets);
              },
              loadFramework(frameworkType) {
                  return getGlobal().System.import(frameworkType);
              },
              setUp(config) {
                  manager.setUp(config);
                  for (const key in frameworks) {
                      if (key !== FrameworkType.NotFramework) {
                          manager.preparePreCreateInstance({
                              framework: frameworks[key],
                              config: { frameworkType: key }
                          });
                      }
                  }
              }
          });
      }

      const manager = new InstanceManager({
          InstanceType: StoreInstance
      });
      bootstrap(manager, getGlobal().frameworks);

    }
  };
});

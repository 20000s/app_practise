System.register(['./flutter-view.base.developer.js'], function () {
  'use strict';
  var getGlobal, getGlobalThis, objectCreate$1, createPropertyDescriptor, _export, objectSetPrototypeOf, objectGetPrototypeOf, createNonEnumerableProperty, toString_1, iterate, global_1, wellKnownSymbol, getBuiltIn, objectDefineProperty, descriptors, engineUserAgent, classofRaw, functionBindContext, fails, documentCreateElement, html, objectGetOwnPropertyDescriptor, aFunction, anObject, isObject$2, isForced_1, redefineAll, redefine, setToStringTag, inspectSource, engineV8Version, anInstance, speciesConstructor, internalState, path, es_array_iterator, commonjsGlobal, createCommonjsModule, FrameworkType;
  return {
    setters: [function (module) {
      getGlobal = module.g;
      getGlobalThis = module.a;
      objectCreate$1 = module.o;
      createPropertyDescriptor = module.c;
      _export = module._;
      objectSetPrototypeOf = module.b;
      objectGetPrototypeOf = module.d;
      createNonEnumerableProperty = module.e;
      toString_1 = module.t;
      iterate = module.i;
      global_1 = module.f;
      wellKnownSymbol = module.w;
      getBuiltIn = module.h;
      objectDefineProperty = module.j;
      descriptors = module.k;
      engineUserAgent = module.l;
      classofRaw = module.m;
      functionBindContext = module.n;
      fails = module.p;
      documentCreateElement = module.q;
      html = module.r;
      objectGetOwnPropertyDescriptor = module.s;
      aFunction = module.u;
      anObject = module.v;
      isObject$2 = module.x;
      isForced_1 = module.y;
      redefineAll = module.z;
      redefine = module.A;
      setToStringTag = module.B;
      inspectSource = module.C;
      engineV8Version = module.D;
      anInstance = module.E;
      speciesConstructor = module.F;
      internalState = module.G;
      path = module.H;
      es_array_iterator = module.I;
      commonjsGlobal = module.J;
      createCommonjsModule = module.K;
      FrameworkType = module.L;
    }],
    execute: function () {

      function isUndefined(val) {
          return typeof val === 'undefined';
      }
      function isExistValue(val) {
          return !isUndefined(val);
      }
      function isObject$1(val) {
          return Object.prototype.toString.call(val) === '[object Object]';
      }
      function isPlainObject(val) {
          return isObject$1(val);
      }
      function isArray$1(val) {
          return Object.prototype.toString.call(val) === '[object Array]';
      }
      function isString(val) {
          return Object.prototype.toString.call(val) === '[object String]';
      }
      function isNumber(val) {
          return Object.prototype.toString.call(val) === '[object Number]';
      }
      function isFunction$1(val) {
          return Object.prototype.toString.call(val) === '[object Function]';
      }
      function isNonEmptyArray(arr) {
          return arr.length > 0;
      }

      function logParams(method, ...args) {
          console[method](args
              .map((arg) => {
              if (isObject$1(arg) || isArray$1(arg)) {
                  return JSON.stringify(arg);
              }
              else {
                  return arg;
              }
          })
              .join(' '));
      }
      class BaseLogger {
          constructor(tag) {
              this.tag = 'base';
              this.tag = tag;
          }
          log(...args) {
              logParams('log', [this.tag], args);
          }
          info(...args) {
              logParams('info', [this.tag], args);
          }
          warn(...args) {
              logParams('warn', [this.tag], args);
          }
          error(...args) {
              logParams('error', [this.tag], args);
          }
          debug(...args) {
              logParams('debug', [this.tag], args);
          }
          timeoutInfo(timeout, ...args) {
              setTimeout(() => {
                  logParams('info', [this.tag], args);
              }, timeout);
          }
      }
      const runtimeLogger = new BaseLogger('runtime');
      new BaseLogger('bridge');
      const developLogger = new BaseLogger('develop');

      class Receiver {
          constructor(instance, configList, options = {}) {
              this.handleMap = {};
              this.isDestroy = false;
              this.instance = instance;
              this.afterReceiveHook = options.afterReceiveHook;
              configList.forEach((handlerConfig) => {
                  this.handleMap[handlerConfig.name] = handlerConfig.handler;
              });
          }
          destroy() {
              this.isDestroy = true;
          }
          receive(tasks) {
              if (this.isDestroy) {
                  runtimeLogger.error('实例已经销毁，无法接收调用');
                  return;
              }
              if (!this.instance.isReady) {
                  throw new Error('实例未加载');
              }
              let resultList = [];
              for (let task of tasks) {
                  let handler = this.handleMap[task.name];
                  let result;
                  if (handler) {
                      try {
                          result = handler(this.instance, ...(task.args || []));
                      }
                      catch (e) {
                          getGlobal().baseLibApi.reportError(this.instance.id, e.name, e.message, e.stack);
                      }
                  }
                  resultList.push(result);
              }
              if (this.afterReceiveHook) {
                  this.afterReceiveHook();
              }
              return JSON.stringify(resultList);
          }
      }

      const userGlobalBlackList = ['runInInstance', 'createInstance', 'destroyInstance', 'callJS', 'register', 'setUp', 'liteAppVDom', 'reporter', 'setRuntimeConfig', 'baseLibApi'];
      const codeTemplatePrefix = '__runner_';

      var ParamType;
      (function (ParamType) {
          ParamType["string"] = "string";
          ParamType["number"] = "number";
          ParamType["boolean"] = "boolean";
          ParamType["json"] = "json";
          ParamType["object"] = "object";
          ParamType["callback"] = "callback";
          ParamType["raw"] = "raw";
      })(ParamType || (ParamType = {}));
      var ReturnType;
      (function (ReturnType) {
          ReturnType["raw"] = "raw";
          ReturnType["json"] = "json";
          ReturnType["promise"] = "promise";
          ReturnType["string"] = "string";
      })(ReturnType || (ReturnType = {}));
      const ParamDefaultValueMap = {
          [ParamType.string]: '',
          [ParamType.number]: 0,
          [ParamType.boolean]: false,
          [ParamType.object]: undefined,
          [ParamType.callback]: -1,
          [ParamType.json]: '{}',
          [ParamType.raw]: undefined,
      };
      function isObjectMethodParam(paramDefinition) {
          return paramDefinition.type === ParamType.object;
      }
      var RegisterType;
      (function (RegisterType) {
          RegisterType["module"] = "module";
          RegisterType["component"] = "component";
      })(RegisterType || (RegisterType = {}));
      class Register {
          constructor() {
              this.modulesInfo = {};
              this.componentsInfo = {};
          }
          static getInstance() {
              if (!Register.instance) {
                  Register.instance = new Register();
              }
              return Register.instance;
          }
          get publicModuleNames() {
              let result = [];
              for (const [key, module] of Object.entries(this.modulesInfo)) {
                  if (!module.private) {
                      result.push(key);
                  }
              }
              return result;
          }
          register(packets) {
              for (const packet of packets) {
                  switch (packet.type) {
                      case RegisterType.module:
                          this.registerModules(packet.info);
                          break;
                      case RegisterType.component:
                          this.registerComponents(packet.info);
                          break;
                  }
              }
          }
          registerComponents(componentsInfo) {
              for (let key in componentsInfo) {
                  if (componentsInfo.hasOwnProperty(key)) {
                      this.componentsInfo[key] = componentsInfo[key];
                  }
              }
          }
          registerModules(modulesInfo) {
              for (let key in modulesInfo) {
                  if (modulesInfo.hasOwnProperty(key)) {
                      const moduleInfo = modulesInfo[key];
                      const moduleBridge = moduleInfo.bridge;
                      this.modulesInfo[key] = moduleInfo;
                      if (moduleBridge.type === 'global') {
                          if (userGlobalBlackList.indexOf(moduleBridge.name) < 0) {
                              userGlobalBlackList.push(moduleBridge.name);
                          }
                      }
                  }
              }
          }
      }

      var ApiType;
      (function (ApiType) {
          ApiType["dom"] = "dom";
          ApiType["domMethod"] = "domMethod";
          ApiType["global"] = "global";
          ApiType["dynamic"] = "dynamic";
          ApiType["component"] = "component";
      })(ApiType || (ApiType = {}));
      class ApiCenter {
          constructor(config) {
              this.callBuffer = [];
              this.isReady = false;
              this.isDestroy = false;
              this.callbackManager = config.callbackManager;
              this.instance = config.instance;
              this.startUp();
          }
          startUp() {
              if (this.instance.isReady) {
                  this.isReady = true;
                  this.Promise = this.instance.injectContext.Promise;
                  this.callBuffer.forEach((task) => {
                      this.callApi(task.apiType, task.params);
                  });
              }
          }
          destroy() {
              this.isDestroy = true;
          }
          callApi(apiType, params) {
              if (this.isDestroy)
                  return;
              if (!this.isReady) {
                  this.callBuffer.push({
                      apiType,
                      params,
                  });
                  return;
              }
              return this.taskExecution(apiType, params);
          }
          taskExecution(apiType, params) {
              if (apiType === ApiType.dynamic) {
                  let callParams = params;
                  let globalObj = getGlobal();
                  return this.commonCallMethod(globalObj, globalObj.callDynamicModule, callParams, [callParams.moduleName, callParams.method], true);
              }
              else if (apiType === ApiType.global) {
                  let callParams = params;
                  return this.callGlobalMethod(callParams);
              }
              else ;
          }
          serializeArgument(arg) {
              switch (typeof arg) {
                  case 'object':
                      if (arg instanceof Array) {
                          return this.serializeArgumentArray(arg);
                      }
                      else {
                          let newObj = {};
                          for (let key in arg) {
                              if (typeof arg[key] !== 'undefined') {
                                  newObj[key] = this.serializeArgument(arg[key]);
                              }
                          }
                          return newObj;
                      }
                  case 'function':
                      return this.callbackManager.add(arg);
                  default:
                      return arg;
              }
          }
          serializeArgumentArray(args) {
              const result = [];
              for (let item of args) {
                  result.push(this.serializeArgument(item));
              }
              return result;
          }
          serializeArgumentArrayWithDefinition(args, paramsDefinitions) {
              const result = [];
              paramsDefinitions.forEach((definition, index) => {
                  const argItem = args[index];
                  result.push(this.serializeArgumentWithDefinition(argItem, definition, index.toString()));
              });
              return result;
          }
          serializeArgumentWithDefinition(arg, definition, debugInfo) {
              if (isUndefined(arg)) {
                  if (!isUndefined(definition.defaultValue)) {
                      return definition.defaultValue;
                  }
                  if (definition.optional) {
                      return ParamDefaultValueMap[definition.type];
                  }
                  throw new Error(`缺少参数 ${debugInfo}`);
              }
              else {
                  if (isObjectMethodParam(definition)) {
                      if (definition.props) {
                          return this.serializeArgumentObjectWithDefinition(arg, definition.props);
                      }
                      else {
                          return arg;
                      }
                  }
                  else {
                      switch (definition.type) {
                          case ParamType.callback:
                              return this.callbackManager.add(arg);
                          case ParamType.json:
                              return JSON.stringify(arg);
                          default:
                              return arg;
                      }
                  }
              }
          }
          serializeArgumentObjectWithDefinition(argMap, paramsDefinitionMap) {
              const result = {};
              for (const key in paramsDefinitionMap) {
                  let arg = argMap[key];
                  result[key] = this.serializeArgumentWithDefinition(arg, paramsDefinitionMap[key], key);
              }
              return result;
          }
          argumentToStringArray(args) {
              for (let i = 0; i < args.length; i++) {
                  let item = args[i];
                  if (!item) {
                      args[i] = '';
                  }
                  else if (isObject$1(item)) {
                      args[i] = JSON.stringify(item);
                  }
                  else {
                      args[i] = item.toString();
                  }
              }
              return args;
          }
          commonCallMethod(methodHost, methodInstance, params, prefixArgs = [], stringProtocol = false) {
              var _a, _b;
              let sourceArgs = params.args || [];
              let args = sourceArgs;
              const paramsDefinitions = ((_a = params.methodInfo) === null || _a === void 0 ? void 0 : _a.params) || [];
              if (params.methodInfo) {
                  if (args.length > paramsDefinitions.length) ;
                  args = this.serializeArgumentArrayWithDefinition(sourceArgs, paramsDefinitions);
              }
              if (stringProtocol) {
                  args = [this.argumentToStringArray(args)];
              }
              args = prefixArgs === null || prefixArgs === void 0 ? void 0 : prefixArgs.concat(args);
              let resultDefinition = (_b = params.methodInfo) === null || _b === void 0 ? void 0 : _b.result;
              if (resultDefinition && resultDefinition.type === ReturnType.promise) {
                  let callback;
                  if (sourceArgs.length > paramsDefinitions.length && isFunction$1(sourceArgs[paramsDefinitions.length])) {
                      callback = sourceArgs[paramsDefinitions.length];
                  }
                  if (callback) {
                      let callbackId = this.callbackManager.add(callback);
                      args.push(callbackId);
                      args.unshift(this.instance.id);
                      return methodInstance.apply(methodHost, args);
                  }
                  else {
                      return new this.Promise((resolve, reject) => {
                          let callbackId = this.callbackManager.add((err, result) => {
                              if (err) {
                                  reject(err);
                              }
                              else {
                                  resolve(result);
                              }
                          });
                          args.push(callbackId);
                          args.unshift(this.instance.id);
                          return methodInstance.apply(methodHost, args);
                      });
                  }
              }
              else {
                  args.unshift(this.instance.id);
                  let methodResult = methodInstance.apply(methodHost, args);
                  if (resultDefinition) {
                      if (resultDefinition.type === ReturnType.json) {
                          methodResult = JSON.parse(methodResult);
                      }
                  }
                  return methodResult;
              }
          }
          callGlobalMethod(params) {
              const globalBridge = getGlobal()[params.globalKey];
              if (!globalBridge)
                  throw new Error(`全局对象 ${params.globalKey} 不存在`);
              if (!globalBridge[params.method]) {
                  throw new Error(`全局对象 ${params.globalKey} 的方法 ${params.method} 不存在`);
              }
              return this.commonCallMethod(globalBridge, globalBridge[params.method], params);
          }
      }

      class ApiCenterFlutterView extends ApiCenter {
          constructor(config) {
              super(config);
              this.liteAppVDom = getGlobal().liteAppVDom;
          }
          taskExecution(apiType, params) {
              var _a, _b;
              let sourceArgs = params.args || [];
              switch (apiType) {
                  case ApiType.dom:
                      let resultArgs = this.serializeArgumentArray(sourceArgs);
                      resultArgs.unshift(this.instance.id);
                      return this.liteAppVDom[params.method].apply(this.liteAppVDom, resultArgs);
                  case ApiType.domMethod:
                      let callParams = params;
                      let args = sourceArgs;
                      const paramsDefinitions = ((_a = callParams.methodInfo) === null || _a === void 0 ? void 0 : _a.params) || [];
                      if (callParams.methodInfo) {
                          if (args.length > paramsDefinitions.length) ;
                          args = this.serializeArgumentArrayWithDefinition(sourceArgs, paramsDefinitions);
                      }
                      let resultDefinition = (_b = callParams.methodInfo) === null || _b === void 0 ? void 0 : _b.result;
                      if (resultDefinition && resultDefinition.type === ReturnType.promise) {
                          let callback;
                          if (sourceArgs.length > paramsDefinitions.length && isFunction$1(sourceArgs[paramsDefinitions.length])) {
                              callback = sourceArgs[paramsDefinitions.length];
                          }
                          if (callback) {
                              let callbackId = this.callbackManager.add(callback);
                              args.push(callbackId);
                              return this.liteAppVDom.callMethod(this.instance.id, callParams.nodeId, callParams.method, JSON.stringify(args));
                          }
                          else {
                              return new this.Promise((resolve, reject) => {
                                  let callbackId = this.callbackManager.add((err, result) => {
                                      if (err) {
                                          reject(err);
                                      }
                                      else {
                                          resolve(result);
                                      }
                                  });
                                  args.push(callbackId);
                                  return this.liteAppVDom.callMethod(this.instance.id, callParams.nodeId, callParams.method, JSON.stringify(args));
                              });
                          }
                      }
                      else {
                          let methodResult = this.liteAppVDom.callMethod(this.instance.id, callParams.nodeId, callParams.method, JSON.stringify(args));
                          if (resultDefinition) {
                              if (resultDefinition.type === ReturnType.json) {
                                  methodResult = JSON.parse(methodResult);
                              }
                          }
                          return methodResult;
                      }
                  default:
                      return super.taskExecution(apiType, params);
              }
          }
      }

      const CALLBACK_ID_MAX = 1000000000;
      class CallbackManager {
          constructor() {
              this.lastCallbackId = 0;
              this.callbacks = [];
          }
          add(callback) {
              if (this.lastCallbackId < CALLBACK_ID_MAX) {
                  this.lastCallbackId++;
              }
              else {
                  this.lastCallbackId = 1;
              }
              let currentId = this.lastCallbackId;
              this.callbacks[currentId] = callback;
              callback.__dispose = () => {
                  this.remove(currentId);
              };
              return currentId;
          }
          remove(callbackId) {
              let callback;
              if (isNumber(callbackId)) {
                  callback = this.callbacks[callbackId];
                  delete this.callbacks[callbackId];
              }
              else {
                  const index = this.callbacks.findIndex(callbackId);
                  callback = this.callbacks[index];
                  delete this.callbacks[index];
              }
              return callback;
          }
          trigger(callbackId, data, keepAlive = false) {
              const callback = this.callbacks[callbackId];
              if (!keepAlive) {
                  delete this.callbacks[callbackId];
              }
              if (typeof callback === 'function') {
                  if (isArray$1(data)) {
                      return callback.apply(null, data);
                  }
                  else {
                      return callback.call(null, data);
                  }
              }
              else {
                  throw new Error('callback not found: ' + callbackId);
              }
          }
          destroy() {
              this.callbacks = [];
          }
      }

      function assignDefaultValue(target, source) {
          for (const key in source) {
              const value = source[key];
              if (isUndefined(target[key]) && isExistValue(value)) {
                  target[key] = value;
              }
          }
          return target;
      }
      let camelCaseCache = {};
      let dashCaseCache = {};
      function toCamelCase(str) {
          if (!camelCaseCache[str]) {
              camelCaseCache[str] = str.replace(/-([a-z])/g, (_, char) => {
                  return char.toUpperCase();
              });
          }
          return camelCaseCache[str];
      }
      function toDashStyle(str) {
          if (!dashCaseCache[str]) {
              dashCaseCache[str] = str.replace(/([A-Z])/g, (_, char) => {
                  return `-${char.toLowerCase()}`;
              });
          }
          return dashCaseCache[str];
      }
      function isInObject(target, value) {
          return (Object.keys(target)
              .map((key) => {
              return target[key];
          })
              .findIndex((item) => {
              return item === value;
          }) >= 0);
      }
      const qs = {
          stringify(obj) {
              let result = '';
              for (const key in obj) {
                  result = result + '&' + key + '=' + (isUndefined(obj[key]) ? '' : obj[key].toString());
              }
              return result.slice(1);
          },
          parse(str) {
              if (!str) {
                  return {};
              }
              const pairs = str.split('&');
              const result = {};
              for (const pair of pairs) {
                  let [key, value] = pair.split('=');
                  result[key] = value;
              }
              return result;
          },
      };
      function once(fn) {
          let flag = false;
          return function (...args) {
              if (!flag) {
                  fn(...args);
                  flag = true;
              }
          };
      }

      var PageViewEventType;
      (function (PageViewEventType) {
          PageViewEventType["routeEnter"] = "routeEnter";
          PageViewEventType["load"] = "load";
          PageViewEventType["ready"] = "ready";
          PageViewEventType["show"] = "show";
          PageViewEventType["hide"] = "hide";
          PageViewEventType["unload"] = "unload";
          PageViewEventType["reachBottom"] = "reachBottom";
          PageViewEventType["error"] = "error";
      })(PageViewEventType || (PageViewEventType = {}));
      var StoreEventType;
      (function (StoreEventType) {
          StoreEventType["load"] = "load";
          StoreEventType["unload"] = "unload";
          StoreEventType["viewVisibilityChange"] = "viewVisibilityChange";
          StoreEventType["viewEnter"] = "viewEnter";
          StoreEventType["viewLeave"] = "viewLeave";
          StoreEventType["pageEnter"] = "pageEnter";
          StoreEventType["pageLeave"] = "pageLeave";
          StoreEventType["pagePreload"] = "pagePreload";
      })(StoreEventType || (StoreEventType = {}));
      var ConnectEventType;
      (function (ConnectEventType) {
          ConnectEventType["dispatch"] = "connect.dispatch";
          ConnectEventType["subscribe"] = "connect.subscribe";
          ConnectEventType["unsubscribe"] = "connect.unsubscribe";
          ConnectEventType["data"] = "connect.data";
      })(ConnectEventType || (ConnectEventType = {}));
      var AppShareEventType;
      (function (AppShareEventType) {
          AppShareEventType["share"] = "app.shareMessage";
      })(AppShareEventType || (AppShareEventType = {}));
      class EventManagerClass {
          constructor(instance, option) {
              this.event = {};
              this.skipDeferEvent = {};
              this.deferDispatchList = [];
              this.defer = false;
              this.dispatchBacktrackingHistory = [];
              this.baseLibApi = instance.requirePrivateModule('baseLibApi');
              if (option) {
                  this.defer = option.defer;
              }
          }
          addEventListener(type, listener, skipDefer = false) {
              if (this.actionInject) {
                  this.actionInject(type);
              }
              let eventList = this.event[type];
              if (!eventList) {
                  eventList = this.event[type] = [];
              }
              listener.skipDefer = skipDefer;
              eventList.push(listener);
              if (eventList.length === 1) {
                  this.baseLibApi.subscribeEvent(type);
              }
              this.flushBacktrackingEvent(type, listener);
          }
          removeEventListener(type, listener) {
              const eventList = this.event[type];
              if (!eventList || !eventList.length) {
                  return;
              }
              if (listener) {
                  const foundIndex = eventList.findIndex((item) => {
                      return item === listener;
                  });
                  if (foundIndex >= 0) {
                      eventList.splice(foundIndex, 1);
                  }
              }
              else {
                  eventList.splice(0, eventList.length);
              }
              if (eventList.length === 0) {
                  this.baseLibApi.unSubscribeEvent(type);
              }
          }
          flushDeferEvent() {
              this.defer = false;
              for (const event of this.deferDispatchList) {
                  this.dispatchEvent(event.type, event.args);
              }
          }
          dispatchEvent(type, args, options = {}) {
              if (this.defer) {
                  this.deferDispatchList.push({
                      type,
                      args,
                  });
              }
              if (!isKnowEvent(type)) ;
              const eventList = this.event[type];
              if (!this.defer && options.backtracking) {
                  this.dispatchBacktrackingHistory.push({
                      type,
                      args,
                      backtracking: true,
                  });
              }
              if (eventList) {
                  const cloneList = [...eventList];
                  for (const listener of cloneList) {
                      if (!this.defer) {
                          listener(...args);
                      }
                      else {
                          if (listener.skipDefer) {
                              listener(...args);
                              this.removeEventListener(type, listener);
                          }
                      }
                  }
              }
          }
          destroy() {
              this.event = {};
          }
          flushBacktrackingEvent(type, listener) {
              setTimeout(() => {
                  this.dispatchBacktrackingHistory.forEach((item) => {
                      if (item.type === type) {
                          listener(...item.args);
                      }
                  });
              }, 1);
          }
      }
      function isKnowEvent(eventType) {
          return eventType in PageViewEventType || eventType in StoreEventType || isInObject(ConnectEventType, eventType);
      }

      const loadLibDefind = {
          globalKey: 'base',
          method: 'loadLib',
          methodInfo: {
              name: 'loadLib',
              params: [
                  {
                      type: ParamType.string
                  },
                  {
                      type: ParamType.callback
                  }
              ]
          }
      };
      class BaseLibModuleClass {
          constructor(instance) {
              this.instance = instance;
          }
          loadLib(moduleName, callback) {
              return this.instance.apiCenter.callApi(ApiType.global, Object.assign(Object.assign({}, loadLibDefind), { args: [moduleName, callback] }));
          }
      }
      function baseLibModuleBuilder(instance) {
          return new BaseLibModuleClass(instance);
      }

      getGlobalThis().Promise;
      getGlobalThis().Promise = {};

      var $AggregateError = function AggregateError(errors, message) {
        var that = this;
        if (!(that instanceof $AggregateError)) return new $AggregateError(errors, message);
        if (objectSetPrototypeOf) {
          // eslint-disable-next-line unicorn/error-message -- expected
          that = objectSetPrototypeOf(new Error(undefined), objectGetPrototypeOf(that));
        }
        if (message !== undefined) createNonEnumerableProperty(that, 'message', toString_1(message));
        var errorsArray = [];
        iterate(errors, errorsArray.push, { that: errorsArray });
        createNonEnumerableProperty(that, 'errors', errorsArray);
        return that;
      };

      $AggregateError.prototype = objectCreate$1(Error.prototype, {
        constructor: createPropertyDescriptor(5, $AggregateError),
        message: createPropertyDescriptor(5, ''),
        name: createPropertyDescriptor(5, 'AggregateError')
      });

      // `AggregateError` constructor
      // https://tc39.es/ecma262/#sec-aggregate-error-constructor
      _export({ global: true }, {
        AggregateError: $AggregateError
      });

      var nativePromiseConstructor = global_1.Promise;

      var SPECIES$1 = wellKnownSymbol('species');

      var setSpecies = function (CONSTRUCTOR_NAME) {
        var Constructor = getBuiltIn(CONSTRUCTOR_NAME);
        var defineProperty = objectDefineProperty.f;

        if (descriptors && Constructor && !Constructor[SPECIES$1]) {
          defineProperty(Constructor, SPECIES$1, {
            configurable: true,
            get: function () { return this; }
          });
        }
      };

      var ITERATOR$1 = wellKnownSymbol('iterator');
      var SAFE_CLOSING = false;

      try {
        var called = 0;
        var iteratorWithReturn = {
          next: function () {
            return { done: !!called++ };
          },
          'return': function () {
            SAFE_CLOSING = true;
          }
        };
        iteratorWithReturn[ITERATOR$1] = function () {
          return this;
        };
        // eslint-disable-next-line es/no-array-from, no-throw-literal -- required for testing
        Array.from(iteratorWithReturn, function () { throw 2; });
      } catch (error) { /* empty */ }

      var checkCorrectnessOfIteration = function (exec, SKIP_CLOSING) {
        if (!SKIP_CLOSING && !SAFE_CLOSING) return false;
        var ITERATION_SUPPORT = false;
        try {
          var object = {};
          object[ITERATOR$1] = function () {
            return {
              next: function () {
                return { done: ITERATION_SUPPORT = true };
              }
            };
          };
          exec(object);
        } catch (error) { /* empty */ }
        return ITERATION_SUPPORT;
      };

      var engineIsIos = /(?:iphone|ipod|ipad).*applewebkit/i.test(engineUserAgent);

      var engineIsNode = classofRaw(global_1.process) == 'process';

      var set = global_1.setImmediate;
      var clear = global_1.clearImmediate;
      var process$2 = global_1.process;
      var MessageChannel = global_1.MessageChannel;
      var Dispatch = global_1.Dispatch;
      var counter = 0;
      var queue = {};
      var ONREADYSTATECHANGE = 'onreadystatechange';
      var location, defer, channel, port;

      try {
        // Deno throws a ReferenceError on `location` access without `--location` flag
        location = global_1.location;
      } catch (error) { /* empty */ }

      var run = function (id) {
        // eslint-disable-next-line no-prototype-builtins -- safe
        if (queue.hasOwnProperty(id)) {
          var fn = queue[id];
          delete queue[id];
          fn();
        }
      };

      var runner = function (id) {
        return function () {
          run(id);
        };
      };

      var listener = function (event) {
        run(event.data);
      };

      var post = function (id) {
        // old engines have not location.origin
        global_1.postMessage(String(id), location.protocol + '//' + location.host);
      };

      // Node.js 0.9+ & IE10+ has setImmediate, otherwise:
      if (!set || !clear) {
        set = function setImmediate(fn) {
          var args = [];
          var argumentsLength = arguments.length;
          var i = 1;
          while (argumentsLength > i) args.push(arguments[i++]);
          queue[++counter] = function () {
            // eslint-disable-next-line no-new-func -- spec requirement
            (typeof fn == 'function' ? fn : Function(fn)).apply(undefined, args);
          };
          defer(counter);
          return counter;
        };
        clear = function clearImmediate(id) {
          delete queue[id];
        };
        // Node.js 0.8-
        if (engineIsNode) {
          defer = function (id) {
            process$2.nextTick(runner(id));
          };
        // Sphere (JS game engine) Dispatch API
        } else if (Dispatch && Dispatch.now) {
          defer = function (id) {
            Dispatch.now(runner(id));
          };
        // Browsers with MessageChannel, includes WebWorkers
        // except iOS - https://github.com/zloirock/core-js/issues/624
        } else if (MessageChannel && !engineIsIos) {
          channel = new MessageChannel();
          port = channel.port2;
          channel.port1.onmessage = listener;
          defer = functionBindContext(port.postMessage, port, 1);
        // Browsers with postMessage, skip WebWorkers
        // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
        } else if (
          global_1.addEventListener &&
          typeof postMessage == 'function' &&
          !global_1.importScripts &&
          location && location.protocol !== 'file:' &&
          !fails(post)
        ) {
          defer = post;
          global_1.addEventListener('message', listener, false);
        // IE8-
        } else if (ONREADYSTATECHANGE in documentCreateElement('script')) {
          defer = function (id) {
            html.appendChild(documentCreateElement('script'))[ONREADYSTATECHANGE] = function () {
              html.removeChild(this);
              run(id);
            };
          };
        // Rest old browsers
        } else {
          defer = function (id) {
            setTimeout(runner(id), 0);
          };
        }
      }

      var task$1 = {
        set: set,
        clear: clear
      };

      var engineIsIosPebble = /iphone|ipod|ipad/i.test(engineUserAgent) && global_1.Pebble !== undefined;

      var engineIsWebosWebkit = /web0s(?!.*chrome)/i.test(engineUserAgent);

      var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
      var macrotask = task$1.set;





      var MutationObserver = global_1.MutationObserver || global_1.WebKitMutationObserver;
      var document$1 = global_1.document;
      var process$1 = global_1.process;
      var Promise$2 = global_1.Promise;
      // Node.js 11 shows ExperimentalWarning on getting `queueMicrotask`
      var queueMicrotaskDescriptor = getOwnPropertyDescriptor(global_1, 'queueMicrotask');
      var queueMicrotask = queueMicrotaskDescriptor && queueMicrotaskDescriptor.value;

      var flush, head, last, notify$1, toggle, node, promise, then;

      // modern engines have queueMicrotask method
      if (!queueMicrotask) {
        flush = function () {
          var parent, fn;
          if (engineIsNode && (parent = process$1.domain)) parent.exit();
          while (head) {
            fn = head.fn;
            head = head.next;
            try {
              fn();
            } catch (error) {
              if (head) notify$1();
              else last = undefined;
              throw error;
            }
          } last = undefined;
          if (parent) parent.enter();
        };

        // browsers with MutationObserver, except iOS - https://github.com/zloirock/core-js/issues/339
        // also except WebOS Webkit https://github.com/zloirock/core-js/issues/898
        if (!engineIsIos && !engineIsNode && !engineIsWebosWebkit && MutationObserver && document$1) {
          toggle = true;
          node = document$1.createTextNode('');
          new MutationObserver(flush).observe(node, { characterData: true });
          notify$1 = function () {
            node.data = toggle = !toggle;
          };
        // environments with maybe non-completely correct, but existent Promise
        } else if (!engineIsIosPebble && Promise$2 && Promise$2.resolve) {
          // Promise.resolve without an argument throws an error in LG WebOS 2
          promise = Promise$2.resolve(undefined);
          // workaround of WebKit ~ iOS Safari 10.1 bug
          promise.constructor = Promise$2;
          then = promise.then;
          notify$1 = function () {
            then.call(promise, flush);
          };
        // Node.js without promises
        } else if (engineIsNode) {
          notify$1 = function () {
            process$1.nextTick(flush);
          };
        // for other environments - macrotask based on:
        // - setImmediate
        // - MessageChannel
        // - window.postMessag
        // - onreadystatechange
        // - setTimeout
        } else {
          notify$1 = function () {
            // strange IE + webpack dev server bug - use .call(global)
            macrotask.call(global_1, flush);
          };
        }
      }

      var microtask = queueMicrotask || function (fn) {
        var task = { fn: fn, next: undefined };
        if (last) last.next = task;
        if (!head) {
          head = task;
          notify$1();
        } last = task;
      };

      var PromiseCapability = function (C) {
        var resolve, reject;
        this.promise = new C(function ($$resolve, $$reject) {
          if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
          resolve = $$resolve;
          reject = $$reject;
        });
        this.resolve = aFunction(resolve);
        this.reject = aFunction(reject);
      };

      // `NewPromiseCapability` abstract operation
      // https://tc39.es/ecma262/#sec-newpromisecapability
      var f = function (C) {
        return new PromiseCapability(C);
      };

      var newPromiseCapability$1 = {
      	f: f
      };

      var promiseResolve = function (C, x) {
        anObject(C);
        if (isObject$2(x) && x.constructor === C) return x;
        var promiseCapability = newPromiseCapability$1.f(C);
        var resolve = promiseCapability.resolve;
        resolve(x);
        return promiseCapability.promise;
      };

      var hostReportErrors = function (a, b) {
        var console = global_1.console;
        if (console && console.error) {
          arguments.length === 1 ? console.error(a) : console.error(a, b);
        }
      };

      var perform = function (exec) {
        try {
          return { error: false, value: exec() };
        } catch (error) {
          return { error: true, value: error };
        }
      };

      var engineIsBrowser = typeof window == 'object';

      var task = task$1.set;












      var SPECIES = wellKnownSymbol('species');
      var PROMISE = 'Promise';
      var getInternalState = internalState.get;
      var setInternalState = internalState.set;
      var getInternalPromiseState = internalState.getterFor(PROMISE);
      var NativePromisePrototype = nativePromiseConstructor && nativePromiseConstructor.prototype;
      var PromiseConstructor = nativePromiseConstructor;
      var PromiseConstructorPrototype = NativePromisePrototype;
      var TypeError$1 = global_1.TypeError;
      var document = global_1.document;
      var process = global_1.process;
      var newPromiseCapability = newPromiseCapability$1.f;
      var newGenericPromiseCapability = newPromiseCapability;
      var DISPATCH_EVENT = !!(document && document.createEvent && global_1.dispatchEvent);
      var NATIVE_REJECTION_EVENT = typeof PromiseRejectionEvent == 'function';
      var UNHANDLED_REJECTION = 'unhandledrejection';
      var REJECTION_HANDLED = 'rejectionhandled';
      var PENDING = 0;
      var FULFILLED = 1;
      var REJECTED = 2;
      var HANDLED = 1;
      var UNHANDLED = 2;
      var SUBCLASSING = false;
      var Internal, OwnPromiseCapability, PromiseWrapper, nativeThen;

      var FORCED = isForced_1(PROMISE, function () {
        var PROMISE_CONSTRUCTOR_SOURCE = inspectSource(PromiseConstructor);
        var GLOBAL_CORE_JS_PROMISE = PROMISE_CONSTRUCTOR_SOURCE !== String(PromiseConstructor);
        // V8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
        // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
        // We can't detect it synchronously, so just check versions
        if (!GLOBAL_CORE_JS_PROMISE && engineV8Version === 66) return true;
        // We can't use @@species feature detection in V8 since it causes
        // deoptimization and performance degradation
        // https://github.com/zloirock/core-js/issues/679
        if (engineV8Version >= 51 && /native code/.test(PROMISE_CONSTRUCTOR_SOURCE)) return false;
        // Detect correctness of subclassing with @@species support
        var promise = new PromiseConstructor(function (resolve) { resolve(1); });
        var FakePromise = function (exec) {
          exec(function () { /* empty */ }, function () { /* empty */ });
        };
        var constructor = promise.constructor = {};
        constructor[SPECIES] = FakePromise;
        SUBCLASSING = promise.then(function () { /* empty */ }) instanceof FakePromise;
        if (!SUBCLASSING) return true;
        // Unhandled rejections tracking support, NodeJS Promise without it fails @@species test
        return !GLOBAL_CORE_JS_PROMISE && engineIsBrowser && !NATIVE_REJECTION_EVENT;
      });

      var INCORRECT_ITERATION = FORCED || !checkCorrectnessOfIteration(function (iterable) {
        PromiseConstructor.all(iterable)['catch'](function () { /* empty */ });
      });

      // helpers
      var isThenable = function (it) {
        var then;
        return isObject$2(it) && typeof (then = it.then) == 'function' ? then : false;
      };

      var notify = function (state, isReject) {
        if (state.notified) return;
        state.notified = true;
        var chain = state.reactions;
        microtask(function () {
          var value = state.value;
          var ok = state.state == FULFILLED;
          var index = 0;
          // variable length - can't use forEach
          while (chain.length > index) {
            var reaction = chain[index++];
            var handler = ok ? reaction.ok : reaction.fail;
            var resolve = reaction.resolve;
            var reject = reaction.reject;
            var domain = reaction.domain;
            var result, then, exited;
            try {
              if (handler) {
                if (!ok) {
                  if (state.rejection === UNHANDLED) onHandleUnhandled(state);
                  state.rejection = HANDLED;
                }
                if (handler === true) result = value;
                else {
                  if (domain) domain.enter();
                  result = handler(value); // can throw
                  if (domain) {
                    domain.exit();
                    exited = true;
                  }
                }
                if (result === reaction.promise) {
                  reject(TypeError$1('Promise-chain cycle'));
                } else if (then = isThenable(result)) {
                  then.call(result, resolve, reject);
                } else resolve(result);
              } else reject(value);
            } catch (error) {
              if (domain && !exited) domain.exit();
              reject(error);
            }
          }
          state.reactions = [];
          state.notified = false;
          if (isReject && !state.rejection) onUnhandled(state);
        });
      };

      var dispatchEvent = function (name, promise, reason) {
        var event, handler;
        if (DISPATCH_EVENT) {
          event = document.createEvent('Event');
          event.promise = promise;
          event.reason = reason;
          event.initEvent(name, false, true);
          global_1.dispatchEvent(event);
        } else event = { promise: promise, reason: reason };
        if (!NATIVE_REJECTION_EVENT && (handler = global_1['on' + name])) handler(event);
        else if (name === UNHANDLED_REJECTION) hostReportErrors('Unhandled promise rejection', reason);
      };

      var onUnhandled = function (state) {
        task.call(global_1, function () {
          var promise = state.facade;
          var value = state.value;
          var IS_UNHANDLED = isUnhandled(state);
          var result;
          if (IS_UNHANDLED) {
            result = perform(function () {
              if (engineIsNode) {
                process.emit('unhandledRejection', value, promise);
              } else dispatchEvent(UNHANDLED_REJECTION, promise, value);
            });
            // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
            state.rejection = engineIsNode || isUnhandled(state) ? UNHANDLED : HANDLED;
            if (result.error) throw result.value;
          }
        });
      };

      var isUnhandled = function (state) {
        return state.rejection !== HANDLED && !state.parent;
      };

      var onHandleUnhandled = function (state) {
        task.call(global_1, function () {
          var promise = state.facade;
          if (engineIsNode) {
            process.emit('rejectionHandled', promise);
          } else dispatchEvent(REJECTION_HANDLED, promise, state.value);
        });
      };

      var bind = function (fn, state, unwrap) {
        return function (value) {
          fn(state, value, unwrap);
        };
      };

      var internalReject = function (state, value, unwrap) {
        if (state.done) return;
        state.done = true;
        if (unwrap) state = unwrap;
        state.value = value;
        state.state = REJECTED;
        notify(state, true);
      };

      var internalResolve = function (state, value, unwrap) {
        if (state.done) return;
        state.done = true;
        if (unwrap) state = unwrap;
        try {
          if (state.facade === value) throw TypeError$1("Promise can't be resolved itself");
          var then = isThenable(value);
          if (then) {
            microtask(function () {
              var wrapper = { done: false };
              try {
                then.call(value,
                  bind(internalResolve, wrapper, state),
                  bind(internalReject, wrapper, state)
                );
              } catch (error) {
                internalReject(wrapper, error, state);
              }
            });
          } else {
            state.value = value;
            state.state = FULFILLED;
            notify(state, false);
          }
        } catch (error) {
          internalReject({ done: false }, error, state);
        }
      };

      // constructor polyfill
      if (FORCED) {
        // 25.4.3.1 Promise(executor)
        PromiseConstructor = function Promise(executor) {
          anInstance(this, PromiseConstructor, PROMISE);
          aFunction(executor);
          Internal.call(this);
          var state = getInternalState(this);
          try {
            executor(bind(internalResolve, state), bind(internalReject, state));
          } catch (error) {
            internalReject(state, error);
          }
        };
        PromiseConstructorPrototype = PromiseConstructor.prototype;
        // eslint-disable-next-line no-unused-vars -- required for `.length`
        Internal = function Promise(executor) {
          setInternalState(this, {
            type: PROMISE,
            done: false,
            notified: false,
            parent: false,
            reactions: [],
            rejection: false,
            state: PENDING,
            value: undefined
          });
        };
        Internal.prototype = redefineAll(PromiseConstructorPrototype, {
          // `Promise.prototype.then` method
          // https://tc39.es/ecma262/#sec-promise.prototype.then
          then: function then(onFulfilled, onRejected) {
            var state = getInternalPromiseState(this);
            var reaction = newPromiseCapability(speciesConstructor(this, PromiseConstructor));
            reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
            reaction.fail = typeof onRejected == 'function' && onRejected;
            reaction.domain = engineIsNode ? process.domain : undefined;
            state.parent = true;
            state.reactions.push(reaction);
            if (state.state != PENDING) notify(state, false);
            return reaction.promise;
          },
          // `Promise.prototype.catch` method
          // https://tc39.es/ecma262/#sec-promise.prototype.catch
          'catch': function (onRejected) {
            return this.then(undefined, onRejected);
          }
        });
        OwnPromiseCapability = function () {
          var promise = new Internal();
          var state = getInternalState(promise);
          this.promise = promise;
          this.resolve = bind(internalResolve, state);
          this.reject = bind(internalReject, state);
        };
        newPromiseCapability$1.f = newPromiseCapability = function (C) {
          return C === PromiseConstructor || C === PromiseWrapper
            ? new OwnPromiseCapability(C)
            : newGenericPromiseCapability(C);
        };

        if (typeof nativePromiseConstructor == 'function' && NativePromisePrototype !== Object.prototype) {
          nativeThen = NativePromisePrototype.then;

          if (!SUBCLASSING) {
            // make `Promise#then` return a polyfilled `Promise` for native promise-based APIs
            redefine(NativePromisePrototype, 'then', function then(onFulfilled, onRejected) {
              var that = this;
              return new PromiseConstructor(function (resolve, reject) {
                nativeThen.call(that, resolve, reject);
              }).then(onFulfilled, onRejected);
            // https://github.com/zloirock/core-js/issues/640
            }, { unsafe: true });

            // makes sure that native promise-based APIs `Promise#catch` properly works with patched `Promise#then`
            redefine(NativePromisePrototype, 'catch', PromiseConstructorPrototype['catch'], { unsafe: true });
          }

          // make `.constructor === Promise` work for native promise-based APIs
          try {
            delete NativePromisePrototype.constructor;
          } catch (error) { /* empty */ }

          // make `instanceof Promise` work for native promise-based APIs
          if (objectSetPrototypeOf) {
            objectSetPrototypeOf(NativePromisePrototype, PromiseConstructorPrototype);
          }
        }
      }

      _export({ global: true, wrap: true, forced: FORCED }, {
        Promise: PromiseConstructor
      });

      setToStringTag(PromiseConstructor, PROMISE, false);
      setSpecies(PROMISE);

      PromiseWrapper = getBuiltIn(PROMISE);

      // statics
      _export({ target: PROMISE, stat: true, forced: FORCED }, {
        // `Promise.reject` method
        // https://tc39.es/ecma262/#sec-promise.reject
        reject: function reject(r) {
          var capability = newPromiseCapability(this);
          capability.reject.call(undefined, r);
          return capability.promise;
        }
      });

      _export({ target: PROMISE, stat: true, forced: FORCED }, {
        // `Promise.resolve` method
        // https://tc39.es/ecma262/#sec-promise.resolve
        resolve: function resolve(x) {
          return promiseResolve(this, x);
        }
      });

      _export({ target: PROMISE, stat: true, forced: INCORRECT_ITERATION }, {
        // `Promise.all` method
        // https://tc39.es/ecma262/#sec-promise.all
        all: function all(iterable) {
          var C = this;
          var capability = newPromiseCapability(C);
          var resolve = capability.resolve;
          var reject = capability.reject;
          var result = perform(function () {
            var $promiseResolve = aFunction(C.resolve);
            var values = [];
            var counter = 0;
            var remaining = 1;
            iterate(iterable, function (promise) {
              var index = counter++;
              var alreadyCalled = false;
              values.push(undefined);
              remaining++;
              $promiseResolve.call(C, promise).then(function (value) {
                if (alreadyCalled) return;
                alreadyCalled = true;
                values[index] = value;
                --remaining || resolve(values);
              }, reject);
            });
            --remaining || resolve(values);
          });
          if (result.error) reject(result.value);
          return capability.promise;
        },
        // `Promise.race` method
        // https://tc39.es/ecma262/#sec-promise.race
        race: function race(iterable) {
          var C = this;
          var capability = newPromiseCapability(C);
          var reject = capability.reject;
          var result = perform(function () {
            var $promiseResolve = aFunction(C.resolve);
            iterate(iterable, function (promise) {
              $promiseResolve.call(C, promise).then(capability.resolve, reject);
            });
          });
          if (result.error) reject(result.value);
          return capability.promise;
        }
      });

      // `Promise.allSettled` method
      // https://tc39.es/ecma262/#sec-promise.allsettled
      _export({ target: 'Promise', stat: true }, {
        allSettled: function allSettled(iterable) {
          var C = this;
          var capability = newPromiseCapability$1.f(C);
          var resolve = capability.resolve;
          var reject = capability.reject;
          var result = perform(function () {
            var promiseResolve = aFunction(C.resolve);
            var values = [];
            var counter = 0;
            var remaining = 1;
            iterate(iterable, function (promise) {
              var index = counter++;
              var alreadyCalled = false;
              values.push(undefined);
              remaining++;
              promiseResolve.call(C, promise).then(function (value) {
                if (alreadyCalled) return;
                alreadyCalled = true;
                values[index] = { status: 'fulfilled', value: value };
                --remaining || resolve(values);
              }, function (error) {
                if (alreadyCalled) return;
                alreadyCalled = true;
                values[index] = { status: 'rejected', reason: error };
                --remaining || resolve(values);
              });
            });
            --remaining || resolve(values);
          });
          if (result.error) reject(result.value);
          return capability.promise;
        }
      });

      var PROMISE_ANY_ERROR = 'No one promise resolved';

      // `Promise.any` method
      // https://tc39.es/ecma262/#sec-promise.any
      _export({ target: 'Promise', stat: true }, {
        any: function any(iterable) {
          var C = this;
          var capability = newPromiseCapability$1.f(C);
          var resolve = capability.resolve;
          var reject = capability.reject;
          var result = perform(function () {
            var promiseResolve = aFunction(C.resolve);
            var errors = [];
            var counter = 0;
            var remaining = 1;
            var alreadyResolved = false;
            iterate(iterable, function (promise) {
              var index = counter++;
              var alreadyRejected = false;
              errors.push(undefined);
              remaining++;
              promiseResolve.call(C, promise).then(function (value) {
                if (alreadyRejected || alreadyResolved) return;
                alreadyResolved = true;
                resolve(value);
              }, function (error) {
                if (alreadyRejected || alreadyResolved) return;
                alreadyRejected = true;
                errors[index] = error;
                --remaining || reject(new (getBuiltIn('AggregateError'))(errors, PROMISE_ANY_ERROR));
              });
            });
            --remaining || reject(new (getBuiltIn('AggregateError'))(errors, PROMISE_ANY_ERROR));
          });
          if (result.error) reject(result.value);
          return capability.promise;
        }
      });

      // Safari bug https://bugs.webkit.org/show_bug.cgi?id=200829
      var NON_GENERIC = !!nativePromiseConstructor && fails(function () {
        nativePromiseConstructor.prototype['finally'].call({ then: function () { /* empty */ } }, function () { /* empty */ });
      });

      // `Promise.prototype.finally` method
      // https://tc39.es/ecma262/#sec-promise.prototype.finally
      _export({ target: 'Promise', proto: true, real: true, forced: NON_GENERIC }, {
        'finally': function (onFinally) {
          var C = speciesConstructor(this, getBuiltIn('Promise'));
          var isFunction = typeof onFinally == 'function';
          return this.then(
            isFunction ? function (x) {
              return promiseResolve(C, onFinally()).then(function () { return x; });
            } : onFinally,
            isFunction ? function (e) {
              return promiseResolve(C, onFinally()).then(function () { throw e; });
            } : onFinally
          );
        }
      });

      // makes sure that native promise-based APIs `Promise#finally` properly works with patched `Promise#then`
      if (typeof nativePromiseConstructor == 'function') {
        var method = getBuiltIn('Promise').prototype['finally'];
        if (nativePromiseConstructor.prototype['finally'] !== method) {
          redefine(nativePromiseConstructor.prototype, 'finally', method, { unsafe: true });
        }
      }

      path.Promise;

      // iterable DOM collections
      // flag - `iterable` interface - 'entries', 'keys', 'values', 'forEach' methods
      var domIterables = {
        CSSRuleList: 0,
        CSSStyleDeclaration: 0,
        CSSValueList: 0,
        ClientRectList: 0,
        DOMRectList: 0,
        DOMStringList: 0,
        DOMTokenList: 1,
        DataTransferItemList: 0,
        FileList: 0,
        HTMLAllCollection: 0,
        HTMLCollection: 0,
        HTMLFormElement: 0,
        HTMLSelectElement: 0,
        MediaList: 0,
        MimeTypeArray: 0,
        NamedNodeMap: 0,
        NodeList: 1,
        PaintRequestList: 0,
        Plugin: 0,
        PluginArray: 0,
        SVGLengthList: 0,
        SVGNumberList: 0,
        SVGPathSegList: 0,
        SVGPointList: 0,
        SVGStringList: 0,
        SVGTransformList: 0,
        SourceBufferList: 0,
        StyleSheetList: 0,
        TextTrackCueList: 0,
        TextTrackList: 0,
        TouchList: 0
      };

      var ITERATOR = wellKnownSymbol('iterator');
      var TO_STRING_TAG = wellKnownSymbol('toStringTag');
      var ArrayValues = es_array_iterator.values;

      for (var COLLECTION_NAME in domIterables) {
        var Collection = global_1[COLLECTION_NAME];
        var CollectionPrototype = Collection && Collection.prototype;
        if (CollectionPrototype) {
          // some Chrome versions have non-configurable methods on DOMTokenList
          if (CollectionPrototype[ITERATOR] !== ArrayValues) try {
            createNonEnumerableProperty(CollectionPrototype, ITERATOR, ArrayValues);
          } catch (error) {
            CollectionPrototype[ITERATOR] = ArrayValues;
          }
          if (!CollectionPrototype[TO_STRING_TAG]) {
            createNonEnumerableProperty(CollectionPrototype, TO_STRING_TAG, COLLECTION_NAME);
          }
          if (domIterables[COLLECTION_NAME]) for (var METHOD_NAME in es_array_iterator) {
            // some Chrome versions have non-configurable methods on DOMTokenList
            if (CollectionPrototype[METHOD_NAME] !== es_array_iterator[METHOD_NAME]) try {
              createNonEnumerableProperty(CollectionPrototype, METHOD_NAME, es_array_iterator[METHOD_NAME]);
            } catch (error) {
              CollectionPrototype[METHOD_NAME] = es_array_iterator[METHOD_NAME];
            }
          }
        }
      }

      // `Promise.try` method
      // https://github.com/tc39/proposal-promise-try
      _export({ target: 'Promise', stat: true }, {
        'try': function (callbackfn) {
          var promiseCapability = newPromiseCapability$1.f(this);
          var result = perform(callbackfn);
          (result.error ? promiseCapability.reject : promiseCapability.resolve)(result.value);
          return promiseCapability.promise;
        }
      });

      function getFetch(props) {
          return (input, init) => {
              const sourcePromise = fetch(input, init);
              sourcePromise.id = props.id;
              return Promise.resolve(sourcePromise);
          };
      }
      ['finally', 'then', 'catch'].forEach((key) => {
          let old = Promise.prototype[key];
          Promise.prototype[key] = function (...args) {
              let wrapArgs = args.map((item) => {
                  if (item instanceof Function && this.id) {
                      return (x) => {
                          const result = item(x);
                          getGlobal().callJS(this.id, []);
                          return result;
                      };
                  }
                  else {
                      return item;
                  }
              });
              let result = old.call(this, ...wrapArgs);
              result.id = this.id;
              return result;
          };
      });
      function getPromise(props) {
          let isDestory = false;
          class NewPromise extends Promise {
              constructor(args) {
                  super(args);
              }
              then(onfulfilled, onrejected) {
                  return super.then(onfulfilled
                      ? (...args) => {
                          if (isDestory)
                              return;
                          return onfulfilled(...args);
                      }
                      : undefined, onrejected
                      ? (reason) => {
                          if (isDestory)
                              return;
                          return onrejected(reason);
                      }
                      : undefined);
              }
              catch(onrejected) {
                  return super.catch(onrejected
                      ? (reason) => {
                          if (isDestory)
                              return;
                          return onrejected(reason);
                      }
                      : undefined);
              }
          }
          let methods = ['all', 'race', 'resolve', 'reject'];
          let handler = {
              construct(_, args) {
                  let obj = new NewPromise(args[0]);
                  obj.id = props.id || 0;
                  return obj;
              },
              get(_, key) {
                  if (methods.indexOf(key) > -1) {
                      return (...args) => {
                          let result = NewPromise[key](...args);
                          result.id = props.id || 0;
                          return result;
                      };
                  }
                  else if (key === 'destroy') {
                      return () => {
                          isDestory = true;
                      };
                  }
                  else {
                      return NewPromise[key];
                  }
              },
          };
          let proxy = new Proxy(NewPromise, handler);
          return proxy;
      }

      var ReceiverType;
      (function (ReceiverType) {
          ReceiverType["callback"] = "callback";
          ReceiverType["fireDomEvent"] = "fireDomEvent";
          ReceiverType["globalEvent"] = "globalEvent";
          ReceiverType["syncCall"] = "syncCall";
      })(ReceiverType || (ReceiverType = {}));

      var SyncCallType;
      (function (SyncCallType) {
          SyncCallType["connect"] = "connect.syncCall";
      })(SyncCallType || (SyncCallType = {}));
      class SyncCallManager {
          constructor() {
              this.callMap = {};
          }
          addHandler(type, handler) {
              if (this.callMap[type]) {
                  throw new Error(`type:${type} 类型的 handler 已存在`);
              }
              this.callMap[type] = handler;
          }
          removeHandler(type) {
              delete this.callMap[type];
          }
          dispatch(type, args) {
              if (!this.callMap[type]) {
                  throw new Error(`方法 ${type} 未找到`);
              }
              const result = this.callMap[type](...args);
              return result;
          }
          destroy() {
              this.callMap = {};
          }
      }

      function isLocal(prop) {
          return 'localId' in prop;
      }
      class InstanceContext {
          constructor(instance) {
              const theGlobal = getGlobal();
              this.Promise = getPromise(instance.runtimeProps);
              this.URL = theGlobal.URL;
              this.debugData = instance.debugData;
              this.fetch = getFetch(instance.runtimeProps);
          }
      }
      class BaseInstance {
          constructor(props) {
              this.reportInfo = {};
              this.id = -9999;
              this.runtimeProps = {};
              this.runtimeContext = {};
              this.callbackManager = new CallbackManager();
              this.syncCallManager = new SyncCallManager();
              this.isReady = false;
              this.libsMap = {};
              this.debugData = {};
              this.name = 'unnamed';
              this.moduleCache = {};
              this.currentUniqueId = 1;
              this.timerDisposers = {
                  setTimeout: [],
                  setInterval: []
              };
              if (isLocal(props)) {
                  this.localId = props.localId;
              }
              else {
                  this.id = props.id;
                  this.localId = props.id;
                  this.isReady = true;
              }
              this.execLib = props.execLib;
              this.baseLibModule = baseLibModuleBuilder(this);
              this.config = props.config;
              this.runtimeConfig = props.runtimeConfig;
          }
          setRuntimeContext(context) {
              this.runtimeContext = context;
          }
          wrapTimer(timerName, customerPostFn) {
              let timer = this.timerDisposers[timerName];
              return (func, delay, ...args) => {
                  let id = getGlobal()[timerName].call(null, () => {
                      try {
                          func();
                          if (customerPostFn)
                              customerPostFn();
                      }
                      catch (e) {
                          this.receiver.receive([
                              {
                                  name: ReceiverType.globalEvent,
                                  args: ['error', [e, 'uncaughtException']]
                              }
                          ]);
                          getGlobal().baseLibApi.reportError(this.id, 'timer', e.message, e.stack);
                      }
                      timer.splice(timer.indexOf(id), 1);
                  }, delay, ...args);
                  timer.push(id);
                  return id;
              };
          }
          startUp(instanceId, { name }) {
              this.id = instanceId;
              this.runtimeProps.id = instanceId;
              this.isReady = true;
              if (name) {
                  this.name = name;
              }
              this.apiCenter.startUp();
          }
          uniqueId() {
              return this.currentUniqueId++;
          }
          destroy() {
              this.reportInfo.callbackNumAtDestroy = this.callbackManager.callbacks.length;
              this.reportInfo.moduleRequireNumber = this.moduleManager.requireNumber;
              this.timerDisposers.setTimeout.forEach(id => {
                  getGlobal().clearTimeout(id);
              });
              this.timerDisposers.setInterval.forEach(id => {
                  getGlobal().clearInterval(id);
              });
              this.receiver.destroy();
              this.apiCenter.destroy();
              this.injectContext.Promise.destroy();
          }
          debugMode() { }
          afterRunCode() {
              this.reportInfo.callbackNumAtFirstRun = this.callbackManager.callbacks.length;
          }
          requirePrivateModule(moduleName) {
              let targetModule = this.moduleCache[moduleName];
              if (isUndefined(targetModule)) {
                  targetModule = this.moduleManager.requirePrivateModule(this, moduleName);
                  if (targetModule) {
                      this.moduleCache[moduleName] = targetModule;
                  }
              }
              return targetModule;
          }
          requireModule(moduleName) {
              let targetModule = this.moduleCache[moduleName];
              if (isUndefined(targetModule)) {
                  targetModule = Object.seal(this.moduleManager.requireModule(this, moduleName));
                  if (targetModule) {
                      this.moduleCache[moduleName] = targetModule;
                  }
              }
              return targetModule;
          }
          dynamicImport(moduleName) {
              return new Promise((resolve, reject) => {
                  if (isUndefined(this.libsMap[moduleName])) {
                      this.baseLibModule.loadLib(moduleName, (error, info) => {
                          if (error || !info) {
                              reject(error);
                          }
                          else {
                              resolve(this.libsMap[moduleName]);
                          }
                      });
                  }
                  else {
                      resolve(this.libsMap[moduleName]);
                  }
              });
          }
      }

      class PageInstance extends BaseInstance {
      }

      var ModuleSnapshotType;
      (function (ModuleSnapshotType) {
          ModuleSnapshotType[ModuleSnapshotType["lastCall"] = 0] = "lastCall";
      })(ModuleSnapshotType || (ModuleSnapshotType = {}));

      class ModuleManager {
          constructor(moduleSnapshotConfig = {}) {
              this.moduleSnapshotConfig = moduleSnapshotConfig;
              this.requireNumber = 0;
              this.register = Register.getInstance();
              this.localModuleBuilders = {};
          }
          get moduleNames() {
              return Object.keys(this.localModuleBuilders).concat(this.register.publicModuleNames);
          }
          add(name, moduleBuilder) {
              this.localModuleBuilders[name] = moduleBuilder;
          }
          requireModule(instance, name) {
              if (this.localModuleBuilders[name]) {
                  this.requireNumber++;
                  return this.bindLocalModules(instance, this.localModuleBuilders[name]);
              }
              const moduleInfo = this.register.modulesInfo[name];
              if (moduleInfo && !moduleInfo.private) {
                  this.requireNumber++;
                  return this.bindRegisterModules(instance, name, this.register.modulesInfo[name]);
              }
              developLogger.error(`加载了不存在的 Module "${name}"`);
          }
          bingRegisterModuleMethods(instance, boundModule, moduleName, moduleInfo) {
              const methods = moduleInfo.methods;
              for (const method of methods) {
                  this.bingRegisterModuleMethod(instance, boundModule, moduleName, method, moduleInfo);
              }
          }
          bingRegisterModuleAccessorProps(instance, boundModule, moduleInfo) {
              const accessorProps = moduleInfo.accessorProps;
              if (accessorProps) {
                  for (const accessorInfo of accessorProps) {
                      let camelCaseAccessorName = accessorInfo.name[0].toUpperCase() + accessorInfo.name.slice(1);
                      let getKey = `get${camelCaseAccessorName}`;
                      let setKey = accessorInfo.setter ? `set${camelCaseAccessorName}` : '';
                      Object.defineProperty(boundModule, accessorInfo.name, {
                          enumerable: true,
                          configurable: true,
                          get: () => {
                              return instance.apiCenter.callApi(ApiType.global, {
                                  globalKey: moduleInfo.bridge.name,
                                  methodInfo: {
                                      name: getKey,
                                      result: accessorInfo.getter.result,
                                      params: []
                                  },
                                  method: getKey,
                                  args: []
                              });
                          },
                          set: setKey
                              ? (value) => {
                                  return instance.apiCenter.callApi(ApiType.global, {
                                      globalKey: moduleInfo.bridge.name,
                                      methodInfo: {
                                          name: setKey,
                                          params: accessorInfo.setter && [accessorInfo.setter.param]
                                      },
                                      method: setKey,
                                      args: [value]
                                  });
                              }
                              : undefined
                      });
                  }
              }
          }
          bindRegisterModules(instance, moduleName, moduleInfo) {
              const boundModule = {};
              const bridge = moduleInfo.bridge;
              const snapshotConfig = this.moduleSnapshotConfig[moduleName];
              const apiType = bridge.type === 'global' ? ApiType.global : ApiType.dynamic;
              if (snapshotConfig) {
                  boundModule.__lite__ = {
                      snapshotConfig,
                      snapshotCallLastCallMap: {},
                      replay: records => {
                          for (let record of records) {
                              let methodInfo = moduleInfo.methods.find(methodInfo => {
                                  return methodInfo.name === record.method;
                              });
                              if (methodInfo) {
                                  instance.apiCenter.callApi(apiType, {
                                      globalKey: bridge.name,
                                      methodInfo,
                                      method: methodInfo.name,
                                      args: record.args
                                  });
                              }
                              else {
                                  runtimeLogger.error('[view] replay module record with method not exist');
                              }
                          }
                      }
                  };
              }
              this.bingRegisterModuleMethods(instance, boundModule, moduleName, moduleInfo);
              this.bingRegisterModuleAccessorProps(instance, boundModule, moduleInfo);
              const props = moduleInfo.props;
              Object.assign(boundModule, props);
              return boundModule;
          }
          bindLocalModules(instance, builder) {
              const localModule = builder(instance);
              return localModule;
          }
          requirePrivateModule(instance, name) {
              const moduleInfo = this.register.modulesInfo[name];
              if (moduleInfo) {
                  return this.bindRegisterModules(instance, name, this.register.modulesInfo[name]);
              }
          }
          bingRegisterModuleMethod(instance, boundModule, moduleName, methodInfo, moduleInfo) {
              const bridge = moduleInfo.bridge;
              let methodCaller;
              if (bridge.type === 'global') {
                  if (boundModule.__lite__ &&
                      boundModule.__lite__.snapshotConfig[methodInfo.name] &&
                      boundModule.__lite__.snapshotConfig[methodInfo.name].type === ModuleSnapshotType.lastCall) {
                      const callMap = boundModule.__lite__.snapshotCallLastCallMap;
                      methodCaller = (...args) => {
                          callMap[methodInfo.name] = {
                              method: methodInfo.name,
                              args
                          };
                          return instance.apiCenter.callApi(ApiType.global, {
                              globalKey: moduleInfo.bridge.name,
                              methodInfo,
                              method: methodInfo.name,
                              args
                          });
                      };
                  }
                  else {
                      methodCaller = (...args) => {
                          return instance.apiCenter.callApi(ApiType.global, {
                              globalKey: moduleInfo.bridge.name,
                              methodInfo,
                              method: methodInfo.name,
                              args
                          });
                      };
                  }
              }
              else {
                  methodCaller = (...args) => {
                      return instance.apiCenter.callApi(ApiType.dynamic, {
                          moduleName,
                          methodInfo,
                          method: methodInfo.name,
                          args
                      });
                  };
              }
              Object.defineProperty(boundModule, methodInfo.name, {
                  enumerable: false,
                  configurable: false,
                  get: () => {
                      return methodCaller;
                  }
              });
          }
      }

      const FireDomEventHandler = {
          name: ReceiverType.fireDomEvent,
          handler: (instance, ...args) => {
              let [nodeId, eventType, detail] = args;
              instance.document.fireEvent(nodeId, eventType, detail);
          }
      };

      const CallbackHandler = {
          name: ReceiverType.callback,
          handler: (instance, callbackId, data, keepAlive = false) => {
              instance.callbackManager.trigger(callbackId, data, keepAlive);
          }
      };

      const GlobalEventHandler = {
          name: ReceiverType.globalEvent,
          handler: (instance, eventType, args) => {
              instance.globalEventManager.dispatchEvent(eventType, args);
          }
      };

      const FAKER_INSTANCE_ID = -1;
      const Reporter = {
          reportKv(id, str) {
              getGlobal().reporter.reportKv(FAKER_INSTANCE_ID, id, str);
          },
          reportRuntimeInfo(data) {
              getGlobal().reporter.dataReporting(FAKER_INSTANCE_ID, 'runtimeInfo', JSON.stringify(data));
          },
      };
      class ReportTimer {
          static start(tag) {
              this.timeMap[tag] = Date.now();
          }
          static end(tag) {
              let start = this.timeMap[tag];
              if (isUndefined(start)) {
                  return 0;
              }
              else {
                  delete this.timeMap[tag];
                  return Date.now() - start;
              }
          }
      }
      ReportTimer.timeMap = {};

      class LiteProxy {
          constructor(instance, extendMethods = []) {
              this.methodNames = ['requireLib', 'requireModule', 'addEventListener', 'removeEventListener'];
              const ownKeys = this.methodNames.concat(instance.moduleManager.moduleNames, extendMethods);
              this.instance = instance;
              return new Proxy(this, {
                  ownKeys() {
                      return ownKeys;
                  },
                  getOwnPropertyDescriptor(target, prop) {
                      if (isString(prop)) {
                          if (target.methodNames.indexOf(prop) > -1) {
                              return {
                                  enumerable: false,
                                  configurable: true,
                              };
                          }
                          else {
                              return {
                                  enumerable: true,
                                  configurable: true,
                              };
                          }
                      }
                      return undefined;
                  },
                  get(target, prop) {
                      let targetValue = Reflect.get(target, prop);
                      if (isUndefined(targetValue) && isString(prop)) {
                          targetValue = target.requireModule(prop);
                      }
                      return targetValue;
                  },
                  set() {
                      return false;
                  },
              });
          }
          requireLib(moduleName) {
              return this.instance.dynamicImport.call(this.instance, moduleName);
          }
          requireModule(moduleName) {
              return this.instance.requireModule(moduleName);
          }
          addEventListener(eventType, listener) {
              this.instance.globalEventManager.addEventListener(eventType, listener);
          }
          removeEventListener(eventType, listener) {
              this.instance.globalEventManager.removeEventListener(eventType, listener);
          }
      }

      ({
          name: ReceiverType.syncCall,
          handler: (instance, type, args) => {
              return instance.syncCallManager.dispatch(type, args);
          },
      });

      var DomApi;
      (function (DomApi) {
          DomApi["release"] = "release";
          DomApi["createElement"] = "createElement";
          DomApi["getParentNode"] = "getParentNode";
          DomApi["getChildNode"] = "getChildNode";
          DomApi["appendChild"] = "appendChild";
          DomApi["insertChild"] = "insertChild";
          DomApi["removeChild"] = "removeChild";
          DomApi["replaceChild"] = "replaceChild";
          DomApi["spliceChild"] = "spliceChild";
          DomApi["findChildPosition"] = "findChildPosition";
          DomApi["childrenLength"] = "childrenLength";
          DomApi["setId"] = "setId";
          DomApi["setClass"] = "setClass";
          DomApi["setStyle"] = "setStyle";
          DomApi["appendStyle"] = "appendStyle";
          DomApi["replaceStyle"] = "replaceStyle";
          DomApi["clearStyle"] = "clearStyle";
          DomApi["requestLayout"] = "requestLayout";
          DomApi["getWindowWidth"] = "getWindowWidth";
          DomApi["getWindowHeight"] = "getWindowHeight";
          DomApi["getBoundingClientRect"] = "getBoundingClientRect";
          DomApi["getClientLeft"] = "getClientLeft";
          DomApi["getClientTop"] = "getClientTop";
          DomApi["getClientWidth"] = "getClientWidth";
          DomApi["getClientHeight"] = "getClientHeight";
          DomApi["getOffsetLeft"] = "getOffsetLeft";
          DomApi["getOffsetTop"] = "getOffsetTop";
          DomApi["getOffsetWidth"] = "getOffsetWidth";
          DomApi["getOffsetHeight"] = "getOffsetHeight";
          DomApi["getComputedStyle"] = "getComputedStyle";
          DomApi["getScrollPosition"] = "getScrollPosition";
          DomApi["setScrollPosition"] = "setScrollPosition";
          DomApi["setAttr"] = "setAttr";
          DomApi["setText"] = "setText";
          DomApi["setRootNode"] = "setRootNode";
          DomApi["getDevicePixelRatio"] = "getDevicePixelRatio";
          DomApi["eventListenerChange"] = "eventListenerChange";
          DomApi["querySelector"] = "querySelector";
          DomApi["querySelectorAll"] = "querySelectorAll";
          DomApi["createIntersectionObserver"] = "createIntersectionObserver";
          DomApi["deleteIntersectionObserver"] = "deleteIntersectionObserver";
          DomApi["addIntersectionObserver"] = "addIntersectionObserver";
          DomApi["removeIntersectionObserver"] = "removeIntersectionObserver";
          DomApi["showModal"] = "showModal";
          DomApi["showToast"] = "showToast";
          DomApi["hideToast"] = "hideToast";
          DomApi["showActionSheet"] = "showActionSheet";
          DomApi["setTitle"] = "setTitle";
          DomApi["setTitleAlpha"] = "setTitleAlpha";
          DomApi["callMethod"] = "callMethod";
      })(DomApi || (DomApi = {}));
      const batchMap = {
          release: true,
          createElement: true,
          appendChild: true,
          insertChild: true,
          removeChild: true,
          replaceChild: true,
          spliceChild: true,
          setId: true,
          setClass: true,
          setStyle: true,
          setAttr: true,
          setText: true,
          eventListenerChange: true
      };
      var BatchIndex;
      (function (BatchIndex) {
          BatchIndex[BatchIndex["release"] = 0] = "release";
          BatchIndex[BatchIndex["createElement"] = 1] = "createElement";
          BatchIndex[BatchIndex["appendChild"] = 2] = "appendChild";
          BatchIndex[BatchIndex["insertChild"] = 3] = "insertChild";
          BatchIndex[BatchIndex["removeChild"] = 4] = "removeChild";
          BatchIndex[BatchIndex["replaceChild"] = 5] = "replaceChild";
          BatchIndex[BatchIndex["spliceChild"] = 6] = "spliceChild";
          BatchIndex[BatchIndex["setId"] = 7] = "setId";
          BatchIndex[BatchIndex["setClass"] = 8] = "setClass";
          BatchIndex[BatchIndex["setStyle"] = 9] = "setStyle";
          BatchIndex[BatchIndex["setAttr"] = 10] = "setAttr";
          BatchIndex[BatchIndex["setText"] = 11] = "setText";
          BatchIndex[BatchIndex["eventListenerChange"] = 12] = "eventListenerChange";
      })(BatchIndex || (BatchIndex = {}));
      function callDomApi(instance, apiType, params) {
          const result = instance.apiCenter.callApi(apiType, params);
          if (typeof result === 'string') {
              return JSON.parse(result);
          }
          else {
              return result;
          }
      }
      function flutterViewDomModuleBuilder(instance) {
          let batchCallBuffer = [];
          let module = {};
          for (const methodName in DomApi) {
              if (methodName === 'callMethod') {
                  module[methodName] = (nodeId, domMethodName, methodInfo, args) => {
                      return callDomApi(instance, ApiType.domMethod, {
                          method: domMethodName,
                          nodeId,
                          methodInfo,
                          args
                      });
                  };
              }
              else if (methodName === 'requestLayout') {
                  module[methodName] = (...args) => {
                      batch();
                      developLogger.info('request layout');
                      return callDomApi(instance, ApiType.dom, {
                          method: methodName,
                          args
                      });
                  };
              }
              else {
                  if (batchMap[methodName] === true && "production" === 'production') {
                      module[methodName] = (...args) => {
                          batchCallBuffer.push({
                              method: BatchIndex[methodName],
                              args
                          });
                      };
                  }
                  else {
                      module[methodName] = (...args) => {
                          return callDomApi(instance, ApiType.dom, {
                              method: methodName,
                              args
                          });
                      };
                  }
              }
          }
          function batch() {
              developLogger.info(`batch call : ${batchCallBuffer.length}`);
              if (batchCallBuffer.length) {
                  callDomApi(instance, ApiType.dom, {
                      method: 'batchCall',
                      args: [JSON.stringify(batchCallBuffer)]
                  });
              }
              batchCallBuffer.length = 0;
          }
          module.batch = batch;
          module.version = '0.0.0';
          return module;
      }

      class NoticeModuleClass {
          constructor(instance) {
              this.instance = instance;
          }
          showModal(option) {
              this.instance.requireModule('dom').showModal(JSON.stringify(option), option.success || -1, option.fail || -1, option.complete || -1);
          }
          showActionSheet(option) {
              this.instance.requireModule('dom').showActionSheet(JSON.stringify(option), option.success || -1, option.fail || -1, option.complete || -1);
          }
          showToast(option) {
              this.instance.requireModule('dom').showToast(JSON.stringify(option), option.success || -1, option.fail || -1, option.complete || -1);
          }
          hideToast(option) {
              this.instance.requireModule('dom').hideToast(option.success || -1, option.fail || -1, option.complete || -1);
          }
      }
      function noticeModuleBuilder(instance) {
          return new NoticeModuleClass(instance);
      }

      /*! *****************************************************************************
      Copyright (c) Microsoft Corporation.

      Permission to use, copy, modify, and/or distribute this software for any
      purpose with or without fee is hereby granted.

      THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
      REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
      AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
      INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
      LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
      OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
      PERFORMANCE OF THIS SOFTWARE.
      ***************************************************************************** */

      function __awaiter(thisArg, _arguments, P, generator) {
          function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
          return new (P || (P = Promise))(function (resolve, reject) {
              function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
              function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
              function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
              step((generator = generator.apply(thisArg, _arguments || [])).next());
          });
      }

      function merge(runtimeContext, target, source) {
          let targetKeys = Object.keys(target);
          let deleteKeys = targetKeys.filter(key => {
              return !source.hasOwnProperty(key);
          });
          Object.keys(source).forEach(key => {
              let sourceItem = source[key];
              let targetItem = target[key];
              mergeItem(runtimeContext, target, key, targetItem, sourceItem);
          });
          deleteKeys.forEach(key => {
              delete target[key];
          });
      }
      function mergeItem(runtimeContext, hostObj, key, targetItem, sourceItem) {
          if (targetItem) {
              if (isArray$1(sourceItem) && isArray$1(targetItem)) {
                  mergeArray(runtimeContext, targetItem, sourceItem);
              }
              else if (isObject$1(sourceItem) && isObject$1(targetItem)) {
                  merge(runtimeContext, targetItem, sourceItem);
              }
          }
          if (isArray$1(hostObj)) {
              runtimeContext.Vue.set(hostObj, key, sourceItem);
          }
          else {
              hostObj[key] = sourceItem;
          }
      }
      function mergeArray(runtimeContext, target, source) {
          for (let i = 0; i < source.length; i++) {
              let targetItem = target[i];
              let sourceItem = source[i];
              mergeItem(runtimeContext, target, i, targetItem, sourceItem);
          }
          if (target.length > source.length) {
              target.splice(source.length);
          }
      }

      /**
       * Checks if `value` is the
       * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
       * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
       *
       * @static
       * @memberOf _
       * @since 0.1.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is an object, else `false`.
       * @example
       *
       * _.isObject({});
       * // => true
       *
       * _.isObject([1, 2, 3]);
       * // => true
       *
       * _.isObject(_.noop);
       * // => true
       *
       * _.isObject(null);
       * // => false
       */
      function isObject(value) {
        var type = typeof value;
        return value != null && (type == 'object' || type == 'function');
      }

      var isObject_1 = isObject;

      /** Detect free variable `global` from Node.js. */
      var freeGlobal = typeof commonjsGlobal == 'object' && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;

      var _freeGlobal = freeGlobal;

      /** Detect free variable `self`. */
      var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

      /** Used as a reference to the global object. */
      var root = _freeGlobal || freeSelf || Function('return this')();

      var _root = root;

      /**
       * Gets the timestamp of the number of milliseconds that have elapsed since
       * the Unix epoch (1 January 1970 00:00:00 UTC).
       *
       * @static
       * @memberOf _
       * @since 2.4.0
       * @category Date
       * @returns {number} Returns the timestamp.
       * @example
       *
       * _.defer(function(stamp) {
       *   console.log(_.now() - stamp);
       * }, _.now());
       * // => Logs the number of milliseconds it took for the deferred invocation.
       */
      var now = function() {
        return _root.Date.now();
      };

      var now_1 = now;

      /** Used to match a single whitespace character. */
      var reWhitespace = /\s/;

      /**
       * Used by `_.trim` and `_.trimEnd` to get the index of the last non-whitespace
       * character of `string`.
       *
       * @private
       * @param {string} string The string to inspect.
       * @returns {number} Returns the index of the last non-whitespace character.
       */
      function trimmedEndIndex(string) {
        var index = string.length;

        while (index-- && reWhitespace.test(string.charAt(index))) {}
        return index;
      }

      var _trimmedEndIndex = trimmedEndIndex;

      /** Used to match leading whitespace. */
      var reTrimStart = /^\s+/;

      /**
       * The base implementation of `_.trim`.
       *
       * @private
       * @param {string} string The string to trim.
       * @returns {string} Returns the trimmed string.
       */
      function baseTrim(string) {
        return string
          ? string.slice(0, _trimmedEndIndex(string) + 1).replace(reTrimStart, '')
          : string;
      }

      var _baseTrim = baseTrim;

      /** Built-in value references. */
      var Symbol$1 = _root.Symbol;

      var _Symbol = Symbol$1;

      /** Used for built-in method references. */
      var objectProto$c = Object.prototype;

      /** Used to check objects for own properties. */
      var hasOwnProperty$9 = objectProto$c.hasOwnProperty;

      /**
       * Used to resolve the
       * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
       * of values.
       */
      var nativeObjectToString$1 = objectProto$c.toString;

      /** Built-in value references. */
      var symToStringTag$1 = _Symbol ? _Symbol.toStringTag : undefined;

      /**
       * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
       *
       * @private
       * @param {*} value The value to query.
       * @returns {string} Returns the raw `toStringTag`.
       */
      function getRawTag(value) {
        var isOwn = hasOwnProperty$9.call(value, symToStringTag$1),
            tag = value[symToStringTag$1];

        try {
          value[symToStringTag$1] = undefined;
          var unmasked = true;
        } catch (e) {}

        var result = nativeObjectToString$1.call(value);
        if (unmasked) {
          if (isOwn) {
            value[symToStringTag$1] = tag;
          } else {
            delete value[symToStringTag$1];
          }
        }
        return result;
      }

      var _getRawTag = getRawTag;

      /** Used for built-in method references. */
      var objectProto$b = Object.prototype;

      /**
       * Used to resolve the
       * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
       * of values.
       */
      var nativeObjectToString = objectProto$b.toString;

      /**
       * Converts `value` to a string using `Object.prototype.toString`.
       *
       * @private
       * @param {*} value The value to convert.
       * @returns {string} Returns the converted string.
       */
      function objectToString(value) {
        return nativeObjectToString.call(value);
      }

      var _objectToString = objectToString;

      /** `Object#toString` result references. */
      var nullTag = '[object Null]',
          undefinedTag = '[object Undefined]';

      /** Built-in value references. */
      var symToStringTag = _Symbol ? _Symbol.toStringTag : undefined;

      /**
       * The base implementation of `getTag` without fallbacks for buggy environments.
       *
       * @private
       * @param {*} value The value to query.
       * @returns {string} Returns the `toStringTag`.
       */
      function baseGetTag(value) {
        if (value == null) {
          return value === undefined ? undefinedTag : nullTag;
        }
        return (symToStringTag && symToStringTag in Object(value))
          ? _getRawTag(value)
          : _objectToString(value);
      }

      var _baseGetTag = baseGetTag;

      /**
       * Checks if `value` is object-like. A value is object-like if it's not `null`
       * and has a `typeof` result of "object".
       *
       * @static
       * @memberOf _
       * @since 4.0.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
       * @example
       *
       * _.isObjectLike({});
       * // => true
       *
       * _.isObjectLike([1, 2, 3]);
       * // => true
       *
       * _.isObjectLike(_.noop);
       * // => false
       *
       * _.isObjectLike(null);
       * // => false
       */
      function isObjectLike(value) {
        return value != null && typeof value == 'object';
      }

      var isObjectLike_1 = isObjectLike;

      /** `Object#toString` result references. */
      var symbolTag$2 = '[object Symbol]';

      /**
       * Checks if `value` is classified as a `Symbol` primitive or object.
       *
       * @static
       * @memberOf _
       * @since 4.0.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
       * @example
       *
       * _.isSymbol(Symbol.iterator);
       * // => true
       *
       * _.isSymbol('abc');
       * // => false
       */
      function isSymbol(value) {
        return typeof value == 'symbol' ||
          (isObjectLike_1(value) && _baseGetTag(value) == symbolTag$2);
      }

      var isSymbol_1 = isSymbol;

      /** Used as references for various `Number` constants. */
      var NAN = 0 / 0;

      /** Used to detect bad signed hexadecimal string values. */
      var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

      /** Used to detect binary string values. */
      var reIsBinary = /^0b[01]+$/i;

      /** Used to detect octal string values. */
      var reIsOctal = /^0o[0-7]+$/i;

      /** Built-in method references without a dependency on `root`. */
      var freeParseInt = parseInt;

      /**
       * Converts `value` to a number.
       *
       * @static
       * @memberOf _
       * @since 4.0.0
       * @category Lang
       * @param {*} value The value to process.
       * @returns {number} Returns the number.
       * @example
       *
       * _.toNumber(3.2);
       * // => 3.2
       *
       * _.toNumber(Number.MIN_VALUE);
       * // => 5e-324
       *
       * _.toNumber(Infinity);
       * // => Infinity
       *
       * _.toNumber('3.2');
       * // => 3.2
       */
      function toNumber(value) {
        if (typeof value == 'number') {
          return value;
        }
        if (isSymbol_1(value)) {
          return NAN;
        }
        if (isObject_1(value)) {
          var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
          value = isObject_1(other) ? (other + '') : other;
        }
        if (typeof value != 'string') {
          return value === 0 ? value : +value;
        }
        value = _baseTrim(value);
        var isBinary = reIsBinary.test(value);
        return (isBinary || reIsOctal.test(value))
          ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
          : (reIsBadHex.test(value) ? NAN : +value);
      }

      var toNumber_1 = toNumber;

      /** Error message constants. */
      var FUNC_ERROR_TEXT = 'Expected a function';

      /* Built-in method references for those with the same name as other `lodash` methods. */
      var nativeMax = Math.max,
          nativeMin = Math.min;

      /**
       * Creates a debounced function that delays invoking `func` until after `wait`
       * milliseconds have elapsed since the last time the debounced function was
       * invoked. The debounced function comes with a `cancel` method to cancel
       * delayed `func` invocations and a `flush` method to immediately invoke them.
       * Provide `options` to indicate whether `func` should be invoked on the
       * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
       * with the last arguments provided to the debounced function. Subsequent
       * calls to the debounced function return the result of the last `func`
       * invocation.
       *
       * **Note:** If `leading` and `trailing` options are `true`, `func` is
       * invoked on the trailing edge of the timeout only if the debounced function
       * is invoked more than once during the `wait` timeout.
       *
       * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
       * until to the next tick, similar to `setTimeout` with a timeout of `0`.
       *
       * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
       * for details over the differences between `_.debounce` and `_.throttle`.
       *
       * @static
       * @memberOf _
       * @since 0.1.0
       * @category Function
       * @param {Function} func The function to debounce.
       * @param {number} [wait=0] The number of milliseconds to delay.
       * @param {Object} [options={}] The options object.
       * @param {boolean} [options.leading=false]
       *  Specify invoking on the leading edge of the timeout.
       * @param {number} [options.maxWait]
       *  The maximum time `func` is allowed to be delayed before it's invoked.
       * @param {boolean} [options.trailing=true]
       *  Specify invoking on the trailing edge of the timeout.
       * @returns {Function} Returns the new debounced function.
       * @example
       *
       * // Avoid costly calculations while the window size is in flux.
       * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
       *
       * // Invoke `sendMail` when clicked, debouncing subsequent calls.
       * jQuery(element).on('click', _.debounce(sendMail, 300, {
       *   'leading': true,
       *   'trailing': false
       * }));
       *
       * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
       * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
       * var source = new EventSource('/stream');
       * jQuery(source).on('message', debounced);
       *
       * // Cancel the trailing debounced invocation.
       * jQuery(window).on('popstate', debounced.cancel);
       */
      function debounce(func, wait, options) {
        var lastArgs,
            lastThis,
            maxWait,
            result,
            timerId,
            lastCallTime,
            lastInvokeTime = 0,
            leading = false,
            maxing = false,
            trailing = true;

        if (typeof func != 'function') {
          throw new TypeError(FUNC_ERROR_TEXT);
        }
        wait = toNumber_1(wait) || 0;
        if (isObject_1(options)) {
          leading = !!options.leading;
          maxing = 'maxWait' in options;
          maxWait = maxing ? nativeMax(toNumber_1(options.maxWait) || 0, wait) : maxWait;
          trailing = 'trailing' in options ? !!options.trailing : trailing;
        }

        function invokeFunc(time) {
          var args = lastArgs,
              thisArg = lastThis;

          lastArgs = lastThis = undefined;
          lastInvokeTime = time;
          result = func.apply(thisArg, args);
          return result;
        }

        function leadingEdge(time) {
          // Reset any `maxWait` timer.
          lastInvokeTime = time;
          // Start the timer for the trailing edge.
          timerId = setTimeout(timerExpired, wait);
          // Invoke the leading edge.
          return leading ? invokeFunc(time) : result;
        }

        function remainingWait(time) {
          var timeSinceLastCall = time - lastCallTime,
              timeSinceLastInvoke = time - lastInvokeTime,
              timeWaiting = wait - timeSinceLastCall;

          return maxing
            ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke)
            : timeWaiting;
        }

        function shouldInvoke(time) {
          var timeSinceLastCall = time - lastCallTime,
              timeSinceLastInvoke = time - lastInvokeTime;

          // Either this is the first call, activity has stopped and we're at the
          // trailing edge, the system time has gone backwards and we're treating
          // it as the trailing edge, or we've hit the `maxWait` limit.
          return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
            (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
        }

        function timerExpired() {
          var time = now_1();
          if (shouldInvoke(time)) {
            return trailingEdge(time);
          }
          // Restart the timer.
          timerId = setTimeout(timerExpired, remainingWait(time));
        }

        function trailingEdge(time) {
          timerId = undefined;

          // Only invoke if we have `lastArgs` which means `func` has been
          // debounced at least once.
          if (trailing && lastArgs) {
            return invokeFunc(time);
          }
          lastArgs = lastThis = undefined;
          return result;
        }

        function cancel() {
          if (timerId !== undefined) {
            clearTimeout(timerId);
          }
          lastInvokeTime = 0;
          lastArgs = lastCallTime = lastThis = timerId = undefined;
        }

        function flush() {
          return timerId === undefined ? result : trailingEdge(now_1());
        }

        function debounced() {
          var time = now_1(),
              isInvoking = shouldInvoke(time);

          lastArgs = arguments;
          lastThis = this;
          lastCallTime = time;

          if (isInvoking) {
            if (timerId === undefined) {
              return leadingEdge(lastCallTime);
            }
            if (maxing) {
              // Handle invocations in a tight loop.
              clearTimeout(timerId);
              timerId = setTimeout(timerExpired, wait);
              return invokeFunc(lastCallTime);
            }
          }
          if (timerId === undefined) {
            timerId = setTimeout(timerExpired, wait);
          }
          return result;
        }
        debounced.cancel = cancel;
        debounced.flush = flush;
        return debounced;
      }

      var debounce_1 = debounce;

      /**
       * Removes all key-value entries from the list cache.
       *
       * @private
       * @name clear
       * @memberOf ListCache
       */
      function listCacheClear() {
        this.__data__ = [];
        this.size = 0;
      }

      var _listCacheClear = listCacheClear;

      /**
       * Performs a
       * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
       * comparison between two values to determine if they are equivalent.
       *
       * @static
       * @memberOf _
       * @since 4.0.0
       * @category Lang
       * @param {*} value The value to compare.
       * @param {*} other The other value to compare.
       * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
       * @example
       *
       * var object = { 'a': 1 };
       * var other = { 'a': 1 };
       *
       * _.eq(object, object);
       * // => true
       *
       * _.eq(object, other);
       * // => false
       *
       * _.eq('a', 'a');
       * // => true
       *
       * _.eq('a', Object('a'));
       * // => false
       *
       * _.eq(NaN, NaN);
       * // => true
       */
      function eq(value, other) {
        return value === other || (value !== value && other !== other);
      }

      var eq_1 = eq;

      /**
       * Gets the index at which the `key` is found in `array` of key-value pairs.
       *
       * @private
       * @param {Array} array The array to inspect.
       * @param {*} key The key to search for.
       * @returns {number} Returns the index of the matched value, else `-1`.
       */
      function assocIndexOf(array, key) {
        var length = array.length;
        while (length--) {
          if (eq_1(array[length][0], key)) {
            return length;
          }
        }
        return -1;
      }

      var _assocIndexOf = assocIndexOf;

      /** Used for built-in method references. */
      var arrayProto = Array.prototype;

      /** Built-in value references. */
      var splice = arrayProto.splice;

      /**
       * Removes `key` and its value from the list cache.
       *
       * @private
       * @name delete
       * @memberOf ListCache
       * @param {string} key The key of the value to remove.
       * @returns {boolean} Returns `true` if the entry was removed, else `false`.
       */
      function listCacheDelete(key) {
        var data = this.__data__,
            index = _assocIndexOf(data, key);

        if (index < 0) {
          return false;
        }
        var lastIndex = data.length - 1;
        if (index == lastIndex) {
          data.pop();
        } else {
          splice.call(data, index, 1);
        }
        --this.size;
        return true;
      }

      var _listCacheDelete = listCacheDelete;

      /**
       * Gets the list cache value for `key`.
       *
       * @private
       * @name get
       * @memberOf ListCache
       * @param {string} key The key of the value to get.
       * @returns {*} Returns the entry value.
       */
      function listCacheGet(key) {
        var data = this.__data__,
            index = _assocIndexOf(data, key);

        return index < 0 ? undefined : data[index][1];
      }

      var _listCacheGet = listCacheGet;

      /**
       * Checks if a list cache value for `key` exists.
       *
       * @private
       * @name has
       * @memberOf ListCache
       * @param {string} key The key of the entry to check.
       * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
       */
      function listCacheHas(key) {
        return _assocIndexOf(this.__data__, key) > -1;
      }

      var _listCacheHas = listCacheHas;

      /**
       * Sets the list cache `key` to `value`.
       *
       * @private
       * @name set
       * @memberOf ListCache
       * @param {string} key The key of the value to set.
       * @param {*} value The value to set.
       * @returns {Object} Returns the list cache instance.
       */
      function listCacheSet(key, value) {
        var data = this.__data__,
            index = _assocIndexOf(data, key);

        if (index < 0) {
          ++this.size;
          data.push([key, value]);
        } else {
          data[index][1] = value;
        }
        return this;
      }

      var _listCacheSet = listCacheSet;

      /**
       * Creates an list cache object.
       *
       * @private
       * @constructor
       * @param {Array} [entries] The key-value pairs to cache.
       */
      function ListCache(entries) {
        var index = -1,
            length = entries == null ? 0 : entries.length;

        this.clear();
        while (++index < length) {
          var entry = entries[index];
          this.set(entry[0], entry[1]);
        }
      }

      // Add methods to `ListCache`.
      ListCache.prototype.clear = _listCacheClear;
      ListCache.prototype['delete'] = _listCacheDelete;
      ListCache.prototype.get = _listCacheGet;
      ListCache.prototype.has = _listCacheHas;
      ListCache.prototype.set = _listCacheSet;

      var _ListCache = ListCache;

      /**
       * Removes all key-value entries from the stack.
       *
       * @private
       * @name clear
       * @memberOf Stack
       */
      function stackClear() {
        this.__data__ = new _ListCache;
        this.size = 0;
      }

      var _stackClear = stackClear;

      /**
       * Removes `key` and its value from the stack.
       *
       * @private
       * @name delete
       * @memberOf Stack
       * @param {string} key The key of the value to remove.
       * @returns {boolean} Returns `true` if the entry was removed, else `false`.
       */
      function stackDelete(key) {
        var data = this.__data__,
            result = data['delete'](key);

        this.size = data.size;
        return result;
      }

      var _stackDelete = stackDelete;

      /**
       * Gets the stack value for `key`.
       *
       * @private
       * @name get
       * @memberOf Stack
       * @param {string} key The key of the value to get.
       * @returns {*} Returns the entry value.
       */
      function stackGet(key) {
        return this.__data__.get(key);
      }

      var _stackGet = stackGet;

      /**
       * Checks if a stack value for `key` exists.
       *
       * @private
       * @name has
       * @memberOf Stack
       * @param {string} key The key of the entry to check.
       * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
       */
      function stackHas(key) {
        return this.__data__.has(key);
      }

      var _stackHas = stackHas;

      /** `Object#toString` result references. */
      var asyncTag = '[object AsyncFunction]',
          funcTag$2 = '[object Function]',
          genTag$1 = '[object GeneratorFunction]',
          proxyTag = '[object Proxy]';

      /**
       * Checks if `value` is classified as a `Function` object.
       *
       * @static
       * @memberOf _
       * @since 0.1.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a function, else `false`.
       * @example
       *
       * _.isFunction(_);
       * // => true
       *
       * _.isFunction(/abc/);
       * // => false
       */
      function isFunction(value) {
        if (!isObject_1(value)) {
          return false;
        }
        // The use of `Object#toString` avoids issues with the `typeof` operator
        // in Safari 9 which returns 'object' for typed arrays and other constructors.
        var tag = _baseGetTag(value);
        return tag == funcTag$2 || tag == genTag$1 || tag == asyncTag || tag == proxyTag;
      }

      var isFunction_1 = isFunction;

      /** Used to detect overreaching core-js shims. */
      var coreJsData = _root['__core-js_shared__'];

      var _coreJsData = coreJsData;

      /** Used to detect methods masquerading as native. */
      var maskSrcKey = (function() {
        var uid = /[^.]+$/.exec(_coreJsData && _coreJsData.keys && _coreJsData.keys.IE_PROTO || '');
        return uid ? ('Symbol(src)_1.' + uid) : '';
      }());

      /**
       * Checks if `func` has its source masked.
       *
       * @private
       * @param {Function} func The function to check.
       * @returns {boolean} Returns `true` if `func` is masked, else `false`.
       */
      function isMasked(func) {
        return !!maskSrcKey && (maskSrcKey in func);
      }

      var _isMasked = isMasked;

      /** Used for built-in method references. */
      var funcProto$1 = Function.prototype;

      /** Used to resolve the decompiled source of functions. */
      var funcToString$1 = funcProto$1.toString;

      /**
       * Converts `func` to its source code.
       *
       * @private
       * @param {Function} func The function to convert.
       * @returns {string} Returns the source code.
       */
      function toSource(func) {
        if (func != null) {
          try {
            return funcToString$1.call(func);
          } catch (e) {}
          try {
            return (func + '');
          } catch (e) {}
        }
        return '';
      }

      var _toSource = toSource;

      /**
       * Used to match `RegExp`
       * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
       */
      var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

      /** Used to detect host constructors (Safari). */
      var reIsHostCtor = /^\[object .+?Constructor\]$/;

      /** Used for built-in method references. */
      var funcProto = Function.prototype,
          objectProto$a = Object.prototype;

      /** Used to resolve the decompiled source of functions. */
      var funcToString = funcProto.toString;

      /** Used to check objects for own properties. */
      var hasOwnProperty$8 = objectProto$a.hasOwnProperty;

      /** Used to detect if a method is native. */
      var reIsNative = RegExp('^' +
        funcToString.call(hasOwnProperty$8).replace(reRegExpChar, '\\$&')
        .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
      );

      /**
       * The base implementation of `_.isNative` without bad shim checks.
       *
       * @private
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a native function,
       *  else `false`.
       */
      function baseIsNative(value) {
        if (!isObject_1(value) || _isMasked(value)) {
          return false;
        }
        var pattern = isFunction_1(value) ? reIsNative : reIsHostCtor;
        return pattern.test(_toSource(value));
      }

      var _baseIsNative = baseIsNative;

      /**
       * Gets the value at `key` of `object`.
       *
       * @private
       * @param {Object} [object] The object to query.
       * @param {string} key The key of the property to get.
       * @returns {*} Returns the property value.
       */
      function getValue(object, key) {
        return object == null ? undefined : object[key];
      }

      var _getValue = getValue;

      /**
       * Gets the native function at `key` of `object`.
       *
       * @private
       * @param {Object} object The object to query.
       * @param {string} key The key of the method to get.
       * @returns {*} Returns the function if it's native, else `undefined`.
       */
      function getNative(object, key) {
        var value = _getValue(object, key);
        return _baseIsNative(value) ? value : undefined;
      }

      var _getNative = getNative;

      /* Built-in method references that are verified to be native. */
      var Map = _getNative(_root, 'Map');

      var _Map = Map;

      /* Built-in method references that are verified to be native. */
      var nativeCreate = _getNative(Object, 'create');

      var _nativeCreate = nativeCreate;

      /**
       * Removes all key-value entries from the hash.
       *
       * @private
       * @name clear
       * @memberOf Hash
       */
      function hashClear() {
        this.__data__ = _nativeCreate ? _nativeCreate(null) : {};
        this.size = 0;
      }

      var _hashClear = hashClear;

      /**
       * Removes `key` and its value from the hash.
       *
       * @private
       * @name delete
       * @memberOf Hash
       * @param {Object} hash The hash to modify.
       * @param {string} key The key of the value to remove.
       * @returns {boolean} Returns `true` if the entry was removed, else `false`.
       */
      function hashDelete(key) {
        var result = this.has(key) && delete this.__data__[key];
        this.size -= result ? 1 : 0;
        return result;
      }

      var _hashDelete = hashDelete;

      /** Used to stand-in for `undefined` hash values. */
      var HASH_UNDEFINED$1 = '__lodash_hash_undefined__';

      /** Used for built-in method references. */
      var objectProto$9 = Object.prototype;

      /** Used to check objects for own properties. */
      var hasOwnProperty$7 = objectProto$9.hasOwnProperty;

      /**
       * Gets the hash value for `key`.
       *
       * @private
       * @name get
       * @memberOf Hash
       * @param {string} key The key of the value to get.
       * @returns {*} Returns the entry value.
       */
      function hashGet(key) {
        var data = this.__data__;
        if (_nativeCreate) {
          var result = data[key];
          return result === HASH_UNDEFINED$1 ? undefined : result;
        }
        return hasOwnProperty$7.call(data, key) ? data[key] : undefined;
      }

      var _hashGet = hashGet;

      /** Used for built-in method references. */
      var objectProto$8 = Object.prototype;

      /** Used to check objects for own properties. */
      var hasOwnProperty$6 = objectProto$8.hasOwnProperty;

      /**
       * Checks if a hash value for `key` exists.
       *
       * @private
       * @name has
       * @memberOf Hash
       * @param {string} key The key of the entry to check.
       * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
       */
      function hashHas(key) {
        var data = this.__data__;
        return _nativeCreate ? (data[key] !== undefined) : hasOwnProperty$6.call(data, key);
      }

      var _hashHas = hashHas;

      /** Used to stand-in for `undefined` hash values. */
      var HASH_UNDEFINED = '__lodash_hash_undefined__';

      /**
       * Sets the hash `key` to `value`.
       *
       * @private
       * @name set
       * @memberOf Hash
       * @param {string} key The key of the value to set.
       * @param {*} value The value to set.
       * @returns {Object} Returns the hash instance.
       */
      function hashSet(key, value) {
        var data = this.__data__;
        this.size += this.has(key) ? 0 : 1;
        data[key] = (_nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
        return this;
      }

      var _hashSet = hashSet;

      /**
       * Creates a hash object.
       *
       * @private
       * @constructor
       * @param {Array} [entries] The key-value pairs to cache.
       */
      function Hash(entries) {
        var index = -1,
            length = entries == null ? 0 : entries.length;

        this.clear();
        while (++index < length) {
          var entry = entries[index];
          this.set(entry[0], entry[1]);
        }
      }

      // Add methods to `Hash`.
      Hash.prototype.clear = _hashClear;
      Hash.prototype['delete'] = _hashDelete;
      Hash.prototype.get = _hashGet;
      Hash.prototype.has = _hashHas;
      Hash.prototype.set = _hashSet;

      var _Hash = Hash;

      /**
       * Removes all key-value entries from the map.
       *
       * @private
       * @name clear
       * @memberOf MapCache
       */
      function mapCacheClear() {
        this.size = 0;
        this.__data__ = {
          'hash': new _Hash,
          'map': new (_Map || _ListCache),
          'string': new _Hash
        };
      }

      var _mapCacheClear = mapCacheClear;

      /**
       * Checks if `value` is suitable for use as unique object key.
       *
       * @private
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
       */
      function isKeyable(value) {
        var type = typeof value;
        return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
          ? (value !== '__proto__')
          : (value === null);
      }

      var _isKeyable = isKeyable;

      /**
       * Gets the data for `map`.
       *
       * @private
       * @param {Object} map The map to query.
       * @param {string} key The reference key.
       * @returns {*} Returns the map data.
       */
      function getMapData(map, key) {
        var data = map.__data__;
        return _isKeyable(key)
          ? data[typeof key == 'string' ? 'string' : 'hash']
          : data.map;
      }

      var _getMapData = getMapData;

      /**
       * Removes `key` and its value from the map.
       *
       * @private
       * @name delete
       * @memberOf MapCache
       * @param {string} key The key of the value to remove.
       * @returns {boolean} Returns `true` if the entry was removed, else `false`.
       */
      function mapCacheDelete(key) {
        var result = _getMapData(this, key)['delete'](key);
        this.size -= result ? 1 : 0;
        return result;
      }

      var _mapCacheDelete = mapCacheDelete;

      /**
       * Gets the map value for `key`.
       *
       * @private
       * @name get
       * @memberOf MapCache
       * @param {string} key The key of the value to get.
       * @returns {*} Returns the entry value.
       */
      function mapCacheGet(key) {
        return _getMapData(this, key).get(key);
      }

      var _mapCacheGet = mapCacheGet;

      /**
       * Checks if a map value for `key` exists.
       *
       * @private
       * @name has
       * @memberOf MapCache
       * @param {string} key The key of the entry to check.
       * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
       */
      function mapCacheHas(key) {
        return _getMapData(this, key).has(key);
      }

      var _mapCacheHas = mapCacheHas;

      /**
       * Sets the map `key` to `value`.
       *
       * @private
       * @name set
       * @memberOf MapCache
       * @param {string} key The key of the value to set.
       * @param {*} value The value to set.
       * @returns {Object} Returns the map cache instance.
       */
      function mapCacheSet(key, value) {
        var data = _getMapData(this, key),
            size = data.size;

        data.set(key, value);
        this.size += data.size == size ? 0 : 1;
        return this;
      }

      var _mapCacheSet = mapCacheSet;

      /**
       * Creates a map cache object to store key-value pairs.
       *
       * @private
       * @constructor
       * @param {Array} [entries] The key-value pairs to cache.
       */
      function MapCache(entries) {
        var index = -1,
            length = entries == null ? 0 : entries.length;

        this.clear();
        while (++index < length) {
          var entry = entries[index];
          this.set(entry[0], entry[1]);
        }
      }

      // Add methods to `MapCache`.
      MapCache.prototype.clear = _mapCacheClear;
      MapCache.prototype['delete'] = _mapCacheDelete;
      MapCache.prototype.get = _mapCacheGet;
      MapCache.prototype.has = _mapCacheHas;
      MapCache.prototype.set = _mapCacheSet;

      var _MapCache = MapCache;

      /** Used as the size to enable large array optimizations. */
      var LARGE_ARRAY_SIZE = 200;

      /**
       * Sets the stack `key` to `value`.
       *
       * @private
       * @name set
       * @memberOf Stack
       * @param {string} key The key of the value to set.
       * @param {*} value The value to set.
       * @returns {Object} Returns the stack cache instance.
       */
      function stackSet(key, value) {
        var data = this.__data__;
        if (data instanceof _ListCache) {
          var pairs = data.__data__;
          if (!_Map || (pairs.length < LARGE_ARRAY_SIZE - 1)) {
            pairs.push([key, value]);
            this.size = ++data.size;
            return this;
          }
          data = this.__data__ = new _MapCache(pairs);
        }
        data.set(key, value);
        this.size = data.size;
        return this;
      }

      var _stackSet = stackSet;

      /**
       * Creates a stack cache object to store key-value pairs.
       *
       * @private
       * @constructor
       * @param {Array} [entries] The key-value pairs to cache.
       */
      function Stack(entries) {
        var data = this.__data__ = new _ListCache(entries);
        this.size = data.size;
      }

      // Add methods to `Stack`.
      Stack.prototype.clear = _stackClear;
      Stack.prototype['delete'] = _stackDelete;
      Stack.prototype.get = _stackGet;
      Stack.prototype.has = _stackHas;
      Stack.prototype.set = _stackSet;

      var _Stack = Stack;

      /**
       * A specialized version of `_.forEach` for arrays without support for
       * iteratee shorthands.
       *
       * @private
       * @param {Array} [array] The array to iterate over.
       * @param {Function} iteratee The function invoked per iteration.
       * @returns {Array} Returns `array`.
       */
      function arrayEach(array, iteratee) {
        var index = -1,
            length = array == null ? 0 : array.length;

        while (++index < length) {
          if (iteratee(array[index], index, array) === false) {
            break;
          }
        }
        return array;
      }

      var _arrayEach = arrayEach;

      var defineProperty = (function() {
        try {
          var func = _getNative(Object, 'defineProperty');
          func({}, '', {});
          return func;
        } catch (e) {}
      }());

      var _defineProperty = defineProperty;

      /**
       * The base implementation of `assignValue` and `assignMergeValue` without
       * value checks.
       *
       * @private
       * @param {Object} object The object to modify.
       * @param {string} key The key of the property to assign.
       * @param {*} value The value to assign.
       */
      function baseAssignValue(object, key, value) {
        if (key == '__proto__' && _defineProperty) {
          _defineProperty(object, key, {
            'configurable': true,
            'enumerable': true,
            'value': value,
            'writable': true
          });
        } else {
          object[key] = value;
        }
      }

      var _baseAssignValue = baseAssignValue;

      /** Used for built-in method references. */
      var objectProto$7 = Object.prototype;

      /** Used to check objects for own properties. */
      var hasOwnProperty$5 = objectProto$7.hasOwnProperty;

      /**
       * Assigns `value` to `key` of `object` if the existing value is not equivalent
       * using [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
       * for equality comparisons.
       *
       * @private
       * @param {Object} object The object to modify.
       * @param {string} key The key of the property to assign.
       * @param {*} value The value to assign.
       */
      function assignValue(object, key, value) {
        var objValue = object[key];
        if (!(hasOwnProperty$5.call(object, key) && eq_1(objValue, value)) ||
            (value === undefined && !(key in object))) {
          _baseAssignValue(object, key, value);
        }
      }

      var _assignValue = assignValue;

      /**
       * Copies properties of `source` to `object`.
       *
       * @private
       * @param {Object} source The object to copy properties from.
       * @param {Array} props The property identifiers to copy.
       * @param {Object} [object={}] The object to copy properties to.
       * @param {Function} [customizer] The function to customize copied values.
       * @returns {Object} Returns `object`.
       */
      function copyObject(source, props, object, customizer) {
        var isNew = !object;
        object || (object = {});

        var index = -1,
            length = props.length;

        while (++index < length) {
          var key = props[index];

          var newValue = customizer
            ? customizer(object[key], source[key], key, object, source)
            : undefined;

          if (newValue === undefined) {
            newValue = source[key];
          }
          if (isNew) {
            _baseAssignValue(object, key, newValue);
          } else {
            _assignValue(object, key, newValue);
          }
        }
        return object;
      }

      var _copyObject = copyObject;

      /**
       * The base implementation of `_.times` without support for iteratee shorthands
       * or max array length checks.
       *
       * @private
       * @param {number} n The number of times to invoke `iteratee`.
       * @param {Function} iteratee The function invoked per iteration.
       * @returns {Array} Returns the array of results.
       */
      function baseTimes(n, iteratee) {
        var index = -1,
            result = Array(n);

        while (++index < n) {
          result[index] = iteratee(index);
        }
        return result;
      }

      var _baseTimes = baseTimes;

      /** `Object#toString` result references. */
      var argsTag$2 = '[object Arguments]';

      /**
       * The base implementation of `_.isArguments`.
       *
       * @private
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is an `arguments` object,
       */
      function baseIsArguments(value) {
        return isObjectLike_1(value) && _baseGetTag(value) == argsTag$2;
      }

      var _baseIsArguments = baseIsArguments;

      /** Used for built-in method references. */
      var objectProto$6 = Object.prototype;

      /** Used to check objects for own properties. */
      var hasOwnProperty$4 = objectProto$6.hasOwnProperty;

      /** Built-in value references. */
      var propertyIsEnumerable$1 = objectProto$6.propertyIsEnumerable;

      /**
       * Checks if `value` is likely an `arguments` object.
       *
       * @static
       * @memberOf _
       * @since 0.1.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is an `arguments` object,
       *  else `false`.
       * @example
       *
       * _.isArguments(function() { return arguments; }());
       * // => true
       *
       * _.isArguments([1, 2, 3]);
       * // => false
       */
      var isArguments = _baseIsArguments(function() { return arguments; }()) ? _baseIsArguments : function(value) {
        return isObjectLike_1(value) && hasOwnProperty$4.call(value, 'callee') &&
          !propertyIsEnumerable$1.call(value, 'callee');
      };

      var isArguments_1 = isArguments;

      /**
       * Checks if `value` is classified as an `Array` object.
       *
       * @static
       * @memberOf _
       * @since 0.1.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is an array, else `false`.
       * @example
       *
       * _.isArray([1, 2, 3]);
       * // => true
       *
       * _.isArray(document.body.children);
       * // => false
       *
       * _.isArray('abc');
       * // => false
       *
       * _.isArray(_.noop);
       * // => false
       */
      var isArray = Array.isArray;

      var isArray_1 = isArray;

      /**
       * This method returns `false`.
       *
       * @static
       * @memberOf _
       * @since 4.13.0
       * @category Util
       * @returns {boolean} Returns `false`.
       * @example
       *
       * _.times(2, _.stubFalse);
       * // => [false, false]
       */
      function stubFalse() {
        return false;
      }

      var stubFalse_1 = stubFalse;

      var isBuffer_1 = createCommonjsModule(function (module, exports) {
      /** Detect free variable `exports`. */
      var freeExports = exports && !exports.nodeType && exports;

      /** Detect free variable `module`. */
      var freeModule = freeExports && 'object' == 'object' && module && !module.nodeType && module;

      /** Detect the popular CommonJS extension `module.exports`. */
      var moduleExports = freeModule && freeModule.exports === freeExports;

      /** Built-in value references. */
      var Buffer = moduleExports ? _root.Buffer : undefined;

      /* Built-in method references for those with the same name as other `lodash` methods. */
      var nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined;

      /**
       * Checks if `value` is a buffer.
       *
       * @static
       * @memberOf _
       * @since 4.3.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
       * @example
       *
       * _.isBuffer(new Buffer(2));
       * // => true
       *
       * _.isBuffer(new Uint8Array(2));
       * // => false
       */
      var isBuffer = nativeIsBuffer || stubFalse_1;

      module.exports = isBuffer;
      });

      /** Used as references for various `Number` constants. */
      var MAX_SAFE_INTEGER$1 = 9007199254740991;

      /** Used to detect unsigned integer values. */
      var reIsUint = /^(?:0|[1-9]\d*)$/;

      /**
       * Checks if `value` is a valid array-like index.
       *
       * @private
       * @param {*} value The value to check.
       * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
       * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
       */
      function isIndex(value, length) {
        var type = typeof value;
        length = length == null ? MAX_SAFE_INTEGER$1 : length;

        return !!length &&
          (type == 'number' ||
            (type != 'symbol' && reIsUint.test(value))) &&
              (value > -1 && value % 1 == 0 && value < length);
      }

      var _isIndex = isIndex;

      /** Used as references for various `Number` constants. */
      var MAX_SAFE_INTEGER = 9007199254740991;

      /**
       * Checks if `value` is a valid array-like length.
       *
       * **Note:** This method is loosely based on
       * [`ToLength`](http://ecma-international.org/ecma-262/7.0/#sec-tolength).
       *
       * @static
       * @memberOf _
       * @since 4.0.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
       * @example
       *
       * _.isLength(3);
       * // => true
       *
       * _.isLength(Number.MIN_VALUE);
       * // => false
       *
       * _.isLength(Infinity);
       * // => false
       *
       * _.isLength('3');
       * // => false
       */
      function isLength(value) {
        return typeof value == 'number' &&
          value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
      }

      var isLength_1 = isLength;

      /** `Object#toString` result references. */
      var argsTag$1 = '[object Arguments]',
          arrayTag$1 = '[object Array]',
          boolTag$2 = '[object Boolean]',
          dateTag$2 = '[object Date]',
          errorTag$1 = '[object Error]',
          funcTag$1 = '[object Function]',
          mapTag$4 = '[object Map]',
          numberTag$2 = '[object Number]',
          objectTag$2 = '[object Object]',
          regexpTag$2 = '[object RegExp]',
          setTag$4 = '[object Set]',
          stringTag$2 = '[object String]',
          weakMapTag$2 = '[object WeakMap]';

      var arrayBufferTag$2 = '[object ArrayBuffer]',
          dataViewTag$3 = '[object DataView]',
          float32Tag$2 = '[object Float32Array]',
          float64Tag$2 = '[object Float64Array]',
          int8Tag$2 = '[object Int8Array]',
          int16Tag$2 = '[object Int16Array]',
          int32Tag$2 = '[object Int32Array]',
          uint8Tag$2 = '[object Uint8Array]',
          uint8ClampedTag$2 = '[object Uint8ClampedArray]',
          uint16Tag$2 = '[object Uint16Array]',
          uint32Tag$2 = '[object Uint32Array]';

      /** Used to identify `toStringTag` values of typed arrays. */
      var typedArrayTags = {};
      typedArrayTags[float32Tag$2] = typedArrayTags[float64Tag$2] =
      typedArrayTags[int8Tag$2] = typedArrayTags[int16Tag$2] =
      typedArrayTags[int32Tag$2] = typedArrayTags[uint8Tag$2] =
      typedArrayTags[uint8ClampedTag$2] = typedArrayTags[uint16Tag$2] =
      typedArrayTags[uint32Tag$2] = true;
      typedArrayTags[argsTag$1] = typedArrayTags[arrayTag$1] =
      typedArrayTags[arrayBufferTag$2] = typedArrayTags[boolTag$2] =
      typedArrayTags[dataViewTag$3] = typedArrayTags[dateTag$2] =
      typedArrayTags[errorTag$1] = typedArrayTags[funcTag$1] =
      typedArrayTags[mapTag$4] = typedArrayTags[numberTag$2] =
      typedArrayTags[objectTag$2] = typedArrayTags[regexpTag$2] =
      typedArrayTags[setTag$4] = typedArrayTags[stringTag$2] =
      typedArrayTags[weakMapTag$2] = false;

      /**
       * The base implementation of `_.isTypedArray` without Node.js optimizations.
       *
       * @private
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
       */
      function baseIsTypedArray(value) {
        return isObjectLike_1(value) &&
          isLength_1(value.length) && !!typedArrayTags[_baseGetTag(value)];
      }

      var _baseIsTypedArray = baseIsTypedArray;

      /**
       * The base implementation of `_.unary` without support for storing metadata.
       *
       * @private
       * @param {Function} func The function to cap arguments for.
       * @returns {Function} Returns the new capped function.
       */
      function baseUnary(func) {
        return function(value) {
          return func(value);
        };
      }

      var _baseUnary = baseUnary;

      var _nodeUtil = createCommonjsModule(function (module, exports) {
      /** Detect free variable `exports`. */
      var freeExports = exports && !exports.nodeType && exports;

      /** Detect free variable `module`. */
      var freeModule = freeExports && 'object' == 'object' && module && !module.nodeType && module;

      /** Detect the popular CommonJS extension `module.exports`. */
      var moduleExports = freeModule && freeModule.exports === freeExports;

      /** Detect free variable `process` from Node.js. */
      var freeProcess = moduleExports && _freeGlobal.process;

      /** Used to access faster Node.js helpers. */
      var nodeUtil = (function() {
        try {
          // Use `util.types` for Node.js 10+.
          var types = freeModule && freeModule.require && freeModule.require('util').types;

          if (types) {
            return types;
          }

          // Legacy `process.binding('util')` for Node.js < 10.
          return freeProcess && freeProcess.binding && freeProcess.binding('util');
        } catch (e) {}
      }());

      module.exports = nodeUtil;
      });

      /* Node.js helper references. */
      var nodeIsTypedArray = _nodeUtil && _nodeUtil.isTypedArray;

      /**
       * Checks if `value` is classified as a typed array.
       *
       * @static
       * @memberOf _
       * @since 3.0.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
       * @example
       *
       * _.isTypedArray(new Uint8Array);
       * // => true
       *
       * _.isTypedArray([]);
       * // => false
       */
      var isTypedArray = nodeIsTypedArray ? _baseUnary(nodeIsTypedArray) : _baseIsTypedArray;

      var isTypedArray_1 = isTypedArray;

      /** Used for built-in method references. */
      var objectProto$5 = Object.prototype;

      /** Used to check objects for own properties. */
      var hasOwnProperty$3 = objectProto$5.hasOwnProperty;

      /**
       * Creates an array of the enumerable property names of the array-like `value`.
       *
       * @private
       * @param {*} value The value to query.
       * @param {boolean} inherited Specify returning inherited property names.
       * @returns {Array} Returns the array of property names.
       */
      function arrayLikeKeys(value, inherited) {
        var isArr = isArray_1(value),
            isArg = !isArr && isArguments_1(value),
            isBuff = !isArr && !isArg && isBuffer_1(value),
            isType = !isArr && !isArg && !isBuff && isTypedArray_1(value),
            skipIndexes = isArr || isArg || isBuff || isType,
            result = skipIndexes ? _baseTimes(value.length, String) : [],
            length = result.length;

        for (var key in value) {
          if ((inherited || hasOwnProperty$3.call(value, key)) &&
              !(skipIndexes && (
                 // Safari 9 has enumerable `arguments.length` in strict mode.
                 key == 'length' ||
                 // Node.js 0.10 has enumerable non-index properties on buffers.
                 (isBuff && (key == 'offset' || key == 'parent')) ||
                 // PhantomJS 2 has enumerable non-index properties on typed arrays.
                 (isType && (key == 'buffer' || key == 'byteLength' || key == 'byteOffset')) ||
                 // Skip index properties.
                 _isIndex(key, length)
              ))) {
            result.push(key);
          }
        }
        return result;
      }

      var _arrayLikeKeys = arrayLikeKeys;

      /** Used for built-in method references. */
      var objectProto$4 = Object.prototype;

      /**
       * Checks if `value` is likely a prototype object.
       *
       * @private
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a prototype, else `false`.
       */
      function isPrototype(value) {
        var Ctor = value && value.constructor,
            proto = (typeof Ctor == 'function' && Ctor.prototype) || objectProto$4;

        return value === proto;
      }

      var _isPrototype = isPrototype;

      /**
       * Creates a unary function that invokes `func` with its argument transformed.
       *
       * @private
       * @param {Function} func The function to wrap.
       * @param {Function} transform The argument transform.
       * @returns {Function} Returns the new function.
       */
      function overArg(func, transform) {
        return function(arg) {
          return func(transform(arg));
        };
      }

      var _overArg = overArg;

      /* Built-in method references for those with the same name as other `lodash` methods. */
      var nativeKeys = _overArg(Object.keys, Object);

      var _nativeKeys = nativeKeys;

      /** Used for built-in method references. */
      var objectProto$3 = Object.prototype;

      /** Used to check objects for own properties. */
      var hasOwnProperty$2 = objectProto$3.hasOwnProperty;

      /**
       * The base implementation of `_.keys` which doesn't treat sparse arrays as dense.
       *
       * @private
       * @param {Object} object The object to query.
       * @returns {Array} Returns the array of property names.
       */
      function baseKeys(object) {
        if (!_isPrototype(object)) {
          return _nativeKeys(object);
        }
        var result = [];
        for (var key in Object(object)) {
          if (hasOwnProperty$2.call(object, key) && key != 'constructor') {
            result.push(key);
          }
        }
        return result;
      }

      var _baseKeys = baseKeys;

      /**
       * Checks if `value` is array-like. A value is considered array-like if it's
       * not a function and has a `value.length` that's an integer greater than or
       * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
       *
       * @static
       * @memberOf _
       * @since 4.0.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
       * @example
       *
       * _.isArrayLike([1, 2, 3]);
       * // => true
       *
       * _.isArrayLike(document.body.children);
       * // => true
       *
       * _.isArrayLike('abc');
       * // => true
       *
       * _.isArrayLike(_.noop);
       * // => false
       */
      function isArrayLike(value) {
        return value != null && isLength_1(value.length) && !isFunction_1(value);
      }

      var isArrayLike_1 = isArrayLike;

      /**
       * Creates an array of the own enumerable property names of `object`.
       *
       * **Note:** Non-object values are coerced to objects. See the
       * [ES spec](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
       * for more details.
       *
       * @static
       * @since 0.1.0
       * @memberOf _
       * @category Object
       * @param {Object} object The object to query.
       * @returns {Array} Returns the array of property names.
       * @example
       *
       * function Foo() {
       *   this.a = 1;
       *   this.b = 2;
       * }
       *
       * Foo.prototype.c = 3;
       *
       * _.keys(new Foo);
       * // => ['a', 'b'] (iteration order is not guaranteed)
       *
       * _.keys('hi');
       * // => ['0', '1']
       */
      function keys(object) {
        return isArrayLike_1(object) ? _arrayLikeKeys(object) : _baseKeys(object);
      }

      var keys_1 = keys;

      /**
       * The base implementation of `_.assign` without support for multiple sources
       * or `customizer` functions.
       *
       * @private
       * @param {Object} object The destination object.
       * @param {Object} source The source object.
       * @returns {Object} Returns `object`.
       */
      function baseAssign(object, source) {
        return object && _copyObject(source, keys_1(source), object);
      }

      var _baseAssign = baseAssign;

      /**
       * This function is like
       * [`Object.keys`](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
       * except that it includes inherited enumerable properties.
       *
       * @private
       * @param {Object} object The object to query.
       * @returns {Array} Returns the array of property names.
       */
      function nativeKeysIn(object) {
        var result = [];
        if (object != null) {
          for (var key in Object(object)) {
            result.push(key);
          }
        }
        return result;
      }

      var _nativeKeysIn = nativeKeysIn;

      /** Used for built-in method references. */
      var objectProto$2 = Object.prototype;

      /** Used to check objects for own properties. */
      var hasOwnProperty$1 = objectProto$2.hasOwnProperty;

      /**
       * The base implementation of `_.keysIn` which doesn't treat sparse arrays as dense.
       *
       * @private
       * @param {Object} object The object to query.
       * @returns {Array} Returns the array of property names.
       */
      function baseKeysIn(object) {
        if (!isObject_1(object)) {
          return _nativeKeysIn(object);
        }
        var isProto = _isPrototype(object),
            result = [];

        for (var key in object) {
          if (!(key == 'constructor' && (isProto || !hasOwnProperty$1.call(object, key)))) {
            result.push(key);
          }
        }
        return result;
      }

      var _baseKeysIn = baseKeysIn;

      /**
       * Creates an array of the own and inherited enumerable property names of `object`.
       *
       * **Note:** Non-object values are coerced to objects.
       *
       * @static
       * @memberOf _
       * @since 3.0.0
       * @category Object
       * @param {Object} object The object to query.
       * @returns {Array} Returns the array of property names.
       * @example
       *
       * function Foo() {
       *   this.a = 1;
       *   this.b = 2;
       * }
       *
       * Foo.prototype.c = 3;
       *
       * _.keysIn(new Foo);
       * // => ['a', 'b', 'c'] (iteration order is not guaranteed)
       */
      function keysIn(object) {
        return isArrayLike_1(object) ? _arrayLikeKeys(object, true) : _baseKeysIn(object);
      }

      var keysIn_1 = keysIn;

      /**
       * The base implementation of `_.assignIn` without support for multiple sources
       * or `customizer` functions.
       *
       * @private
       * @param {Object} object The destination object.
       * @param {Object} source The source object.
       * @returns {Object} Returns `object`.
       */
      function baseAssignIn(object, source) {
        return object && _copyObject(source, keysIn_1(source), object);
      }

      var _baseAssignIn = baseAssignIn;

      var _cloneBuffer = createCommonjsModule(function (module, exports) {
      /** Detect free variable `exports`. */
      var freeExports = exports && !exports.nodeType && exports;

      /** Detect free variable `module`. */
      var freeModule = freeExports && 'object' == 'object' && module && !module.nodeType && module;

      /** Detect the popular CommonJS extension `module.exports`. */
      var moduleExports = freeModule && freeModule.exports === freeExports;

      /** Built-in value references. */
      var Buffer = moduleExports ? _root.Buffer : undefined,
          allocUnsafe = Buffer ? Buffer.allocUnsafe : undefined;

      /**
       * Creates a clone of  `buffer`.
       *
       * @private
       * @param {Buffer} buffer The buffer to clone.
       * @param {boolean} [isDeep] Specify a deep clone.
       * @returns {Buffer} Returns the cloned buffer.
       */
      function cloneBuffer(buffer, isDeep) {
        if (isDeep) {
          return buffer.slice();
        }
        var length = buffer.length,
            result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);

        buffer.copy(result);
        return result;
      }

      module.exports = cloneBuffer;
      });

      /**
       * Copies the values of `source` to `array`.
       *
       * @private
       * @param {Array} source The array to copy values from.
       * @param {Array} [array=[]] The array to copy values to.
       * @returns {Array} Returns `array`.
       */
      function copyArray(source, array) {
        var index = -1,
            length = source.length;

        array || (array = Array(length));
        while (++index < length) {
          array[index] = source[index];
        }
        return array;
      }

      var _copyArray = copyArray;

      /**
       * A specialized version of `_.filter` for arrays without support for
       * iteratee shorthands.
       *
       * @private
       * @param {Array} [array] The array to iterate over.
       * @param {Function} predicate The function invoked per iteration.
       * @returns {Array} Returns the new filtered array.
       */
      function arrayFilter(array, predicate) {
        var index = -1,
            length = array == null ? 0 : array.length,
            resIndex = 0,
            result = [];

        while (++index < length) {
          var value = array[index];
          if (predicate(value, index, array)) {
            result[resIndex++] = value;
          }
        }
        return result;
      }

      var _arrayFilter = arrayFilter;

      /**
       * This method returns a new empty array.
       *
       * @static
       * @memberOf _
       * @since 4.13.0
       * @category Util
       * @returns {Array} Returns the new empty array.
       * @example
       *
       * var arrays = _.times(2, _.stubArray);
       *
       * console.log(arrays);
       * // => [[], []]
       *
       * console.log(arrays[0] === arrays[1]);
       * // => false
       */
      function stubArray() {
        return [];
      }

      var stubArray_1 = stubArray;

      /** Used for built-in method references. */
      var objectProto$1 = Object.prototype;

      /** Built-in value references. */
      var propertyIsEnumerable = objectProto$1.propertyIsEnumerable;

      /* Built-in method references for those with the same name as other `lodash` methods. */
      var nativeGetSymbols$1 = Object.getOwnPropertySymbols;

      /**
       * Creates an array of the own enumerable symbols of `object`.
       *
       * @private
       * @param {Object} object The object to query.
       * @returns {Array} Returns the array of symbols.
       */
      var getSymbols = !nativeGetSymbols$1 ? stubArray_1 : function(object) {
        if (object == null) {
          return [];
        }
        object = Object(object);
        return _arrayFilter(nativeGetSymbols$1(object), function(symbol) {
          return propertyIsEnumerable.call(object, symbol);
        });
      };

      var _getSymbols = getSymbols;

      /**
       * Copies own symbols of `source` to `object`.
       *
       * @private
       * @param {Object} source The object to copy symbols from.
       * @param {Object} [object={}] The object to copy symbols to.
       * @returns {Object} Returns `object`.
       */
      function copySymbols(source, object) {
        return _copyObject(source, _getSymbols(source), object);
      }

      var _copySymbols = copySymbols;

      /**
       * Appends the elements of `values` to `array`.
       *
       * @private
       * @param {Array} array The array to modify.
       * @param {Array} values The values to append.
       * @returns {Array} Returns `array`.
       */
      function arrayPush(array, values) {
        var index = -1,
            length = values.length,
            offset = array.length;

        while (++index < length) {
          array[offset + index] = values[index];
        }
        return array;
      }

      var _arrayPush = arrayPush;

      /** Built-in value references. */
      var getPrototype = _overArg(Object.getPrototypeOf, Object);

      var _getPrototype = getPrototype;

      /* Built-in method references for those with the same name as other `lodash` methods. */
      var nativeGetSymbols = Object.getOwnPropertySymbols;

      /**
       * Creates an array of the own and inherited enumerable symbols of `object`.
       *
       * @private
       * @param {Object} object The object to query.
       * @returns {Array} Returns the array of symbols.
       */
      var getSymbolsIn = !nativeGetSymbols ? stubArray_1 : function(object) {
        var result = [];
        while (object) {
          _arrayPush(result, _getSymbols(object));
          object = _getPrototype(object);
        }
        return result;
      };

      var _getSymbolsIn = getSymbolsIn;

      /**
       * Copies own and inherited symbols of `source` to `object`.
       *
       * @private
       * @param {Object} source The object to copy symbols from.
       * @param {Object} [object={}] The object to copy symbols to.
       * @returns {Object} Returns `object`.
       */
      function copySymbolsIn(source, object) {
        return _copyObject(source, _getSymbolsIn(source), object);
      }

      var _copySymbolsIn = copySymbolsIn;

      /**
       * The base implementation of `getAllKeys` and `getAllKeysIn` which uses
       * `keysFunc` and `symbolsFunc` to get the enumerable property names and
       * symbols of `object`.
       *
       * @private
       * @param {Object} object The object to query.
       * @param {Function} keysFunc The function to get the keys of `object`.
       * @param {Function} symbolsFunc The function to get the symbols of `object`.
       * @returns {Array} Returns the array of property names and symbols.
       */
      function baseGetAllKeys(object, keysFunc, symbolsFunc) {
        var result = keysFunc(object);
        return isArray_1(object) ? result : _arrayPush(result, symbolsFunc(object));
      }

      var _baseGetAllKeys = baseGetAllKeys;

      /**
       * Creates an array of own enumerable property names and symbols of `object`.
       *
       * @private
       * @param {Object} object The object to query.
       * @returns {Array} Returns the array of property names and symbols.
       */
      function getAllKeys(object) {
        return _baseGetAllKeys(object, keys_1, _getSymbols);
      }

      var _getAllKeys = getAllKeys;

      /**
       * Creates an array of own and inherited enumerable property names and
       * symbols of `object`.
       *
       * @private
       * @param {Object} object The object to query.
       * @returns {Array} Returns the array of property names and symbols.
       */
      function getAllKeysIn(object) {
        return _baseGetAllKeys(object, keysIn_1, _getSymbolsIn);
      }

      var _getAllKeysIn = getAllKeysIn;

      /* Built-in method references that are verified to be native. */
      var DataView = _getNative(_root, 'DataView');

      var _DataView = DataView;

      /* Built-in method references that are verified to be native. */
      var Promise$1 = _getNative(_root, 'Promise');

      var _Promise = Promise$1;

      /* Built-in method references that are verified to be native. */
      var Set = _getNative(_root, 'Set');

      var _Set = Set;

      /* Built-in method references that are verified to be native. */
      var WeakMap = _getNative(_root, 'WeakMap');

      var _WeakMap = WeakMap;

      /** `Object#toString` result references. */
      var mapTag$3 = '[object Map]',
          objectTag$1 = '[object Object]',
          promiseTag = '[object Promise]',
          setTag$3 = '[object Set]',
          weakMapTag$1 = '[object WeakMap]';

      var dataViewTag$2 = '[object DataView]';

      /** Used to detect maps, sets, and weakmaps. */
      var dataViewCtorString = _toSource(_DataView),
          mapCtorString = _toSource(_Map),
          promiseCtorString = _toSource(_Promise),
          setCtorString = _toSource(_Set),
          weakMapCtorString = _toSource(_WeakMap);

      /**
       * Gets the `toStringTag` of `value`.
       *
       * @private
       * @param {*} value The value to query.
       * @returns {string} Returns the `toStringTag`.
       */
      var getTag = _baseGetTag;

      // Fallback for data views, maps, sets, and weak maps in IE 11 and promises in Node.js < 6.
      if ((_DataView && getTag(new _DataView(new ArrayBuffer(1))) != dataViewTag$2) ||
          (_Map && getTag(new _Map) != mapTag$3) ||
          (_Promise && getTag(_Promise.resolve()) != promiseTag) ||
          (_Set && getTag(new _Set) != setTag$3) ||
          (_WeakMap && getTag(new _WeakMap) != weakMapTag$1)) {
        getTag = function(value) {
          var result = _baseGetTag(value),
              Ctor = result == objectTag$1 ? value.constructor : undefined,
              ctorString = Ctor ? _toSource(Ctor) : '';

          if (ctorString) {
            switch (ctorString) {
              case dataViewCtorString: return dataViewTag$2;
              case mapCtorString: return mapTag$3;
              case promiseCtorString: return promiseTag;
              case setCtorString: return setTag$3;
              case weakMapCtorString: return weakMapTag$1;
            }
          }
          return result;
        };
      }

      var _getTag = getTag;

      /** Used for built-in method references. */
      var objectProto = Object.prototype;

      /** Used to check objects for own properties. */
      var hasOwnProperty = objectProto.hasOwnProperty;

      /**
       * Initializes an array clone.
       *
       * @private
       * @param {Array} array The array to clone.
       * @returns {Array} Returns the initialized clone.
       */
      function initCloneArray(array) {
        var length = array.length,
            result = new array.constructor(length);

        // Add properties assigned by `RegExp#exec`.
        if (length && typeof array[0] == 'string' && hasOwnProperty.call(array, 'index')) {
          result.index = array.index;
          result.input = array.input;
        }
        return result;
      }

      var _initCloneArray = initCloneArray;

      /** Built-in value references. */
      var Uint8Array = _root.Uint8Array;

      var _Uint8Array = Uint8Array;

      /**
       * Creates a clone of `arrayBuffer`.
       *
       * @private
       * @param {ArrayBuffer} arrayBuffer The array buffer to clone.
       * @returns {ArrayBuffer} Returns the cloned array buffer.
       */
      function cloneArrayBuffer(arrayBuffer) {
        var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
        new _Uint8Array(result).set(new _Uint8Array(arrayBuffer));
        return result;
      }

      var _cloneArrayBuffer = cloneArrayBuffer;

      /**
       * Creates a clone of `dataView`.
       *
       * @private
       * @param {Object} dataView The data view to clone.
       * @param {boolean} [isDeep] Specify a deep clone.
       * @returns {Object} Returns the cloned data view.
       */
      function cloneDataView(dataView, isDeep) {
        var buffer = isDeep ? _cloneArrayBuffer(dataView.buffer) : dataView.buffer;
        return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
      }

      var _cloneDataView = cloneDataView;

      /** Used to match `RegExp` flags from their coerced string values. */
      var reFlags = /\w*$/;

      /**
       * Creates a clone of `regexp`.
       *
       * @private
       * @param {Object} regexp The regexp to clone.
       * @returns {Object} Returns the cloned regexp.
       */
      function cloneRegExp(regexp) {
        var result = new regexp.constructor(regexp.source, reFlags.exec(regexp));
        result.lastIndex = regexp.lastIndex;
        return result;
      }

      var _cloneRegExp = cloneRegExp;

      /** Used to convert symbols to primitives and strings. */
      var symbolProto = _Symbol ? _Symbol.prototype : undefined,
          symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;

      /**
       * Creates a clone of the `symbol` object.
       *
       * @private
       * @param {Object} symbol The symbol object to clone.
       * @returns {Object} Returns the cloned symbol object.
       */
      function cloneSymbol(symbol) {
        return symbolValueOf ? Object(symbolValueOf.call(symbol)) : {};
      }

      var _cloneSymbol = cloneSymbol;

      /**
       * Creates a clone of `typedArray`.
       *
       * @private
       * @param {Object} typedArray The typed array to clone.
       * @param {boolean} [isDeep] Specify a deep clone.
       * @returns {Object} Returns the cloned typed array.
       */
      function cloneTypedArray(typedArray, isDeep) {
        var buffer = isDeep ? _cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
        return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
      }

      var _cloneTypedArray = cloneTypedArray;

      /** `Object#toString` result references. */
      var boolTag$1 = '[object Boolean]',
          dateTag$1 = '[object Date]',
          mapTag$2 = '[object Map]',
          numberTag$1 = '[object Number]',
          regexpTag$1 = '[object RegExp]',
          setTag$2 = '[object Set]',
          stringTag$1 = '[object String]',
          symbolTag$1 = '[object Symbol]';

      var arrayBufferTag$1 = '[object ArrayBuffer]',
          dataViewTag$1 = '[object DataView]',
          float32Tag$1 = '[object Float32Array]',
          float64Tag$1 = '[object Float64Array]',
          int8Tag$1 = '[object Int8Array]',
          int16Tag$1 = '[object Int16Array]',
          int32Tag$1 = '[object Int32Array]',
          uint8Tag$1 = '[object Uint8Array]',
          uint8ClampedTag$1 = '[object Uint8ClampedArray]',
          uint16Tag$1 = '[object Uint16Array]',
          uint32Tag$1 = '[object Uint32Array]';

      /**
       * Initializes an object clone based on its `toStringTag`.
       *
       * **Note:** This function only supports cloning values with tags of
       * `Boolean`, `Date`, `Error`, `Map`, `Number`, `RegExp`, `Set`, or `String`.
       *
       * @private
       * @param {Object} object The object to clone.
       * @param {string} tag The `toStringTag` of the object to clone.
       * @param {boolean} [isDeep] Specify a deep clone.
       * @returns {Object} Returns the initialized clone.
       */
      function initCloneByTag(object, tag, isDeep) {
        var Ctor = object.constructor;
        switch (tag) {
          case arrayBufferTag$1:
            return _cloneArrayBuffer(object);

          case boolTag$1:
          case dateTag$1:
            return new Ctor(+object);

          case dataViewTag$1:
            return _cloneDataView(object, isDeep);

          case float32Tag$1: case float64Tag$1:
          case int8Tag$1: case int16Tag$1: case int32Tag$1:
          case uint8Tag$1: case uint8ClampedTag$1: case uint16Tag$1: case uint32Tag$1:
            return _cloneTypedArray(object, isDeep);

          case mapTag$2:
            return new Ctor;

          case numberTag$1:
          case stringTag$1:
            return new Ctor(object);

          case regexpTag$1:
            return _cloneRegExp(object);

          case setTag$2:
            return new Ctor;

          case symbolTag$1:
            return _cloneSymbol(object);
        }
      }

      var _initCloneByTag = initCloneByTag;

      /** Built-in value references. */
      var objectCreate = Object.create;

      /**
       * The base implementation of `_.create` without support for assigning
       * properties to the created object.
       *
       * @private
       * @param {Object} proto The object to inherit from.
       * @returns {Object} Returns the new object.
       */
      var baseCreate = (function() {
        function object() {}
        return function(proto) {
          if (!isObject_1(proto)) {
            return {};
          }
          if (objectCreate) {
            return objectCreate(proto);
          }
          object.prototype = proto;
          var result = new object;
          object.prototype = undefined;
          return result;
        };
      }());

      var _baseCreate = baseCreate;

      /**
       * Initializes an object clone.
       *
       * @private
       * @param {Object} object The object to clone.
       * @returns {Object} Returns the initialized clone.
       */
      function initCloneObject(object) {
        return (typeof object.constructor == 'function' && !_isPrototype(object))
          ? _baseCreate(_getPrototype(object))
          : {};
      }

      var _initCloneObject = initCloneObject;

      /** `Object#toString` result references. */
      var mapTag$1 = '[object Map]';

      /**
       * The base implementation of `_.isMap` without Node.js optimizations.
       *
       * @private
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a map, else `false`.
       */
      function baseIsMap(value) {
        return isObjectLike_1(value) && _getTag(value) == mapTag$1;
      }

      var _baseIsMap = baseIsMap;

      /* Node.js helper references. */
      var nodeIsMap = _nodeUtil && _nodeUtil.isMap;

      /**
       * Checks if `value` is classified as a `Map` object.
       *
       * @static
       * @memberOf _
       * @since 4.3.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a map, else `false`.
       * @example
       *
       * _.isMap(new Map);
       * // => true
       *
       * _.isMap(new WeakMap);
       * // => false
       */
      var isMap = nodeIsMap ? _baseUnary(nodeIsMap) : _baseIsMap;

      var isMap_1 = isMap;

      /** `Object#toString` result references. */
      var setTag$1 = '[object Set]';

      /**
       * The base implementation of `_.isSet` without Node.js optimizations.
       *
       * @private
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a set, else `false`.
       */
      function baseIsSet(value) {
        return isObjectLike_1(value) && _getTag(value) == setTag$1;
      }

      var _baseIsSet = baseIsSet;

      /* Node.js helper references. */
      var nodeIsSet = _nodeUtil && _nodeUtil.isSet;

      /**
       * Checks if `value` is classified as a `Set` object.
       *
       * @static
       * @memberOf _
       * @since 4.3.0
       * @category Lang
       * @param {*} value The value to check.
       * @returns {boolean} Returns `true` if `value` is a set, else `false`.
       * @example
       *
       * _.isSet(new Set);
       * // => true
       *
       * _.isSet(new WeakSet);
       * // => false
       */
      var isSet = nodeIsSet ? _baseUnary(nodeIsSet) : _baseIsSet;

      var isSet_1 = isSet;

      /** Used to compose bitmasks for cloning. */
      var CLONE_DEEP_FLAG$1 = 1,
          CLONE_FLAT_FLAG = 2,
          CLONE_SYMBOLS_FLAG$1 = 4;

      /** `Object#toString` result references. */
      var argsTag = '[object Arguments]',
          arrayTag = '[object Array]',
          boolTag = '[object Boolean]',
          dateTag = '[object Date]',
          errorTag = '[object Error]',
          funcTag = '[object Function]',
          genTag = '[object GeneratorFunction]',
          mapTag = '[object Map]',
          numberTag = '[object Number]',
          objectTag = '[object Object]',
          regexpTag = '[object RegExp]',
          setTag = '[object Set]',
          stringTag = '[object String]',
          symbolTag = '[object Symbol]',
          weakMapTag = '[object WeakMap]';

      var arrayBufferTag = '[object ArrayBuffer]',
          dataViewTag = '[object DataView]',
          float32Tag = '[object Float32Array]',
          float64Tag = '[object Float64Array]',
          int8Tag = '[object Int8Array]',
          int16Tag = '[object Int16Array]',
          int32Tag = '[object Int32Array]',
          uint8Tag = '[object Uint8Array]',
          uint8ClampedTag = '[object Uint8ClampedArray]',
          uint16Tag = '[object Uint16Array]',
          uint32Tag = '[object Uint32Array]';

      /** Used to identify `toStringTag` values supported by `_.clone`. */
      var cloneableTags = {};
      cloneableTags[argsTag] = cloneableTags[arrayTag] =
      cloneableTags[arrayBufferTag] = cloneableTags[dataViewTag] =
      cloneableTags[boolTag] = cloneableTags[dateTag] =
      cloneableTags[float32Tag] = cloneableTags[float64Tag] =
      cloneableTags[int8Tag] = cloneableTags[int16Tag] =
      cloneableTags[int32Tag] = cloneableTags[mapTag] =
      cloneableTags[numberTag] = cloneableTags[objectTag] =
      cloneableTags[regexpTag] = cloneableTags[setTag] =
      cloneableTags[stringTag] = cloneableTags[symbolTag] =
      cloneableTags[uint8Tag] = cloneableTags[uint8ClampedTag] =
      cloneableTags[uint16Tag] = cloneableTags[uint32Tag] = true;
      cloneableTags[errorTag] = cloneableTags[funcTag] =
      cloneableTags[weakMapTag] = false;

      /**
       * The base implementation of `_.clone` and `_.cloneDeep` which tracks
       * traversed objects.
       *
       * @private
       * @param {*} value The value to clone.
       * @param {boolean} bitmask The bitmask flags.
       *  1 - Deep clone
       *  2 - Flatten inherited properties
       *  4 - Clone symbols
       * @param {Function} [customizer] The function to customize cloning.
       * @param {string} [key] The key of `value`.
       * @param {Object} [object] The parent object of `value`.
       * @param {Object} [stack] Tracks traversed objects and their clone counterparts.
       * @returns {*} Returns the cloned value.
       */
      function baseClone(value, bitmask, customizer, key, object, stack) {
        var result,
            isDeep = bitmask & CLONE_DEEP_FLAG$1,
            isFlat = bitmask & CLONE_FLAT_FLAG,
            isFull = bitmask & CLONE_SYMBOLS_FLAG$1;

        if (customizer) {
          result = object ? customizer(value, key, object, stack) : customizer(value);
        }
        if (result !== undefined) {
          return result;
        }
        if (!isObject_1(value)) {
          return value;
        }
        var isArr = isArray_1(value);
        if (isArr) {
          result = _initCloneArray(value);
          if (!isDeep) {
            return _copyArray(value, result);
          }
        } else {
          var tag = _getTag(value),
              isFunc = tag == funcTag || tag == genTag;

          if (isBuffer_1(value)) {
            return _cloneBuffer(value, isDeep);
          }
          if (tag == objectTag || tag == argsTag || (isFunc && !object)) {
            result = (isFlat || isFunc) ? {} : _initCloneObject(value);
            if (!isDeep) {
              return isFlat
                ? _copySymbolsIn(value, _baseAssignIn(result, value))
                : _copySymbols(value, _baseAssign(result, value));
            }
          } else {
            if (!cloneableTags[tag]) {
              return object ? value : {};
            }
            result = _initCloneByTag(value, tag, isDeep);
          }
        }
        // Check for circular references and return its corresponding clone.
        stack || (stack = new _Stack);
        var stacked = stack.get(value);
        if (stacked) {
          return stacked;
        }
        stack.set(value, result);

        if (isSet_1(value)) {
          value.forEach(function(subValue) {
            result.add(baseClone(subValue, bitmask, customizer, subValue, value, stack));
          });
        } else if (isMap_1(value)) {
          value.forEach(function(subValue, key) {
            result.set(key, baseClone(subValue, bitmask, customizer, key, value, stack));
          });
        }

        var keysFunc = isFull
          ? (isFlat ? _getAllKeysIn : _getAllKeys)
          : (isFlat ? keysIn_1 : keys_1);

        var props = isArr ? undefined : keysFunc(value);
        _arrayEach(props || value, function(subValue, key) {
          if (props) {
            key = subValue;
            subValue = value[key];
          }
          // Recursively populate clone (susceptible to call stack limits).
          _assignValue(result, key, baseClone(subValue, bitmask, customizer, key, value, stack));
        });
        return result;
      }

      var _baseClone = baseClone;

      /** Used to compose bitmasks for cloning. */
      var CLONE_DEEP_FLAG = 1,
          CLONE_SYMBOLS_FLAG = 4;

      /**
       * This method is like `_.clone` except that it recursively clones `value`.
       *
       * @static
       * @memberOf _
       * @since 1.0.0
       * @category Lang
       * @param {*} value The value to recursively clone.
       * @returns {*} Returns the deep cloned value.
       * @see _.clone
       * @example
       *
       * var objects = [{ 'a': 1 }, { 'b': 2 }];
       *
       * var deep = _.cloneDeep(objects);
       * console.log(deep[0] === objects[0]);
       * // => false
       */
      function cloneDeep(value) {
        return _baseClone(value, CLONE_DEEP_FLAG | CLONE_SYMBOLS_FLAG);
      }

      var cloneDeep_1 = cloneDeep;

      var ProcessState;
      (function (ProcessState) {
          ProcessState[ProcessState["wait"] = 0] = "wait";
          ProcessState[ProcessState["pass"] = 1] = "pass";
      })(ProcessState || (ProcessState = {}));
      class BaseProcessController {
          constructor(instance) {
              this.instance = instance;
              this.state = ProcessState.wait;
              this.taskBuffer = [];
              this.params = undefined;
          }
          flush(params) {
              this.params = params;
              this.state = ProcessState.pass;
              let task = this.taskBuffer.shift();
              while (task) {
                  task(this.params);
                  task = this.taskBuffer.shift();
              }
          }
          run(task) {
              if (this.state === ProcessState.pass) {
                  task(this.params);
              }
              else {
                  this.taskBuffer.push(task);
              }
          }
      }
      class RouteEnterProcessController extends BaseProcessController {
          constructor(instance) {
              super(instance);
              let resolveFunction = (event) => {
                  this.flush(event);
                  this.instance.globalEventManager.removeEventListener(PageViewEventType.routeEnter, resolveFunction);
              };
              this.instance.globalEventManager.addEventListener(PageViewEventType.routeEnter, resolveFunction, true);
          }
      }

      const DEFAULT_STORE_PAGE_INIT_ACTION = 'lite/pageInit';
      const DEFAULT_STORE_CONFIG = {
          pageInitAction: ''
      };

      function argsFormat(namespace, config, option) {
          let _namespace;
          let _config;
          let _option;
          if (isString(namespace)) {
              _config = config;
              _namespace = namespace;
              _option = option;
          }
          else {
              _namespace = '';
              _config = namespace;
              _option = config;
          }
          return {
              namespace: _namespace,
              config: _config,
              option: _option,
          };
      }
      function pointerCompose(...args) {
          const fragments = args.filter((item) => !!item);
          return fragments.join('/');
      }
      function ResolveBuilder(builder, vm, isDefault) {
          const config = builder.call(vm, isDefault);
          if (isString(config)) {
              return {
                  pointer: config,
              };
          }
          else {
              return config;
          }
      }
      function ConnectConfigPreProcess(config) {
          let staticItems = [];
          let builderItems = [];
          if (isArray$1(config)) {
              config.forEach((item) => {
                  staticItems.push({
                      pointer: item,
                      computedKey: item,
                  });
              });
          }
          else if (isPlainObject(config)) {
              Object.keys(config).map((key) => {
                  const value = config[key];
                  if (isFunction$1(value)) {
                      builderItems.push({
                          builder: value,
                          computedKey: key,
                      });
                  }
                  else if (isString(value)) {
                      staticItems.push({
                          pointer: value,
                          computedKey: key,
                      });
                  }
                  else {
                      staticItems.push(Object.assign(Object.assign({}, value), { computedKey: key }));
                  }
              });
          }
          return {
              builderItems,
              staticItems,
          };
      }
      function normalizeMap(map, namespace) {
          if (isArray$1(map)) {
              return map.map((key) => ({
                  key,
                  val: pointerCompose(namespace, key),
              }));
          }
          else if (isPlainObject(map)) {
              return Object.keys(map).map((key) => ({
                  key,
                  val: pointerCompose(namespace, map[key]),
              }));
          }
          else {
              return [];
          }
      }

      class Store {
          constructor(instance) {
              this.flushSubscribeDebounce = debounce_1(this.flushSubscribe, 1, {});
              this.subscribeBuffer = [];
              this.storeConfig = cloneDeep_1(DEFAULT_STORE_CONFIG);
              this.defaultDataCache = {};
              this.instance = instance;
              this.connectModule = instance.requireModule('connect');
              this.routerModule = instance.requireModule('router');
              this.useSyncCall = instance.instanceConfig.syncCall;
              this.state = instance.runtimeContext.Vue.reactive({});
              this.reactiveKeys = instance.runtimeContext.Vue.reactive({});
              this.setDataProcessController = new BaseProcessController(this.instance);
              this.initConnection();
          }
          destroy() {
              this.flushSubscribeDebounce.cancel();
          }
          config(config) {
              if (config.pageInitAction) {
                  if (isString(config.pageInitAction)) {
                      this.storeConfig.pageInitAction = config.pageInitAction;
                  }
                  else {
                      this.storeConfig.pageInitAction = DEFAULT_STORE_PAGE_INIT_ACTION;
                  }
                  this.instance.routeEnterProcessController.run(() => __awaiter(this, void 0, void 0, function* () {
                      yield new this.instance.injectContext.Promise(resolve => {
                          this.instance.injectContext.setTimeout(resolve, 1);
                      });
                      let result = null;
                      let err = null;
                      try {
                          result = yield this.dispatch(this.storeConfig.pageInitAction, {
                              query: this.routerModule.currentQuery,
                              route: this.routerModule.currentRoute
                          });
                      }
                      catch (err) {
                          developLogger.error(err);
                      }
                      developLogger.info('[store] setData process flush');
                      this.setDataProcessController.flush();
                      this.instance.globalEventManager.dispatchEvent('store.pageInit', [err, result], {
                          backtracking: true
                      });
                  }));
              }
          }
          init(storeShadow) { }
          dispatch(actionName, data, option) {
              return new this.instance.injectContext.Promise((resolve, reject) => {
                  developLogger.info('dispatch', actionName, data);
                  ReportTimer.start('dispatch');
                  this.connectModule.dispatch(actionName, data || {}, data => {
                      developLogger.info('dispatch.result', this.instance.id, actionName, data);
                      if (data.type === 'json') {
                          resolve(data.result);
                      }
                      else if (data.type === 'error') {
                          reject(new Error(data.result));
                      }
                      else {
                          resolve(data.result);
                      }
                  }, option);
              });
          }
          syncGetDefaultData(key) {
              if (!this.useSyncCall)
                  return;
              if (!this.defaultDataCache[key]) {
                  this.defaultDataCache[key] = {
                      value: this.connectModule.syncCall({
                          type: 'getData',
                          target: key
                      })
                  };
              }
              return this.defaultDataCache[key].value;
          }
          releaseDefaultData(key) {
              if (!this.useSyncCall)
                  return;
              delete this.defaultDataCache[key];
          }
          connectViews(namespace, config, option) {
              const formattedArgs = argsFormat(namespace, config, option);
              if (!formattedArgs.config) {
                  return {};
              }
              let result = {};
              const normalizedConfig = ConnectConfigPreProcess(formattedArgs.config);
              const self = this;
              for (const item of normalizedConfig.staticItems) {
                  let finalPointer = pointerCompose(formattedArgs.namespace, item.pointer);
                  this.state[finalPointer] = '';
                  result[item.computedKey] = () => {
                      return this.state[finalPointer];
                  };
              }
              for (const item of normalizedConfig.builderItems) {
                  const routerEnterOnce = once(this.routerEnter.bind(this));
                  result[item.computedKey] = function () {
                      const resolveItem = self.resolveFinalPointer(formattedArgs.namespace, item, this, true);
                      self.updateReactiveKey(item.computedKey, resolveItem.finalPointer);
                      routerEnterOnce(this, formattedArgs.namespace, item);
                      return self.state[self.reactiveKeys[item.computedKey]];
                  };
              }
              return result;
          }
          connectActions(namespace, config, option) {
              const formattedArgs = argsFormat(namespace, config, option);
              if (!formattedArgs.config) {
                  return {};
              }
              let result = {};
              const normalizedConfig = normalizeMap(formattedArgs.config, formattedArgs.namespace);
              normalizedConfig.forEach(({ key, val }) => {
                  result[key] = (payload) => {
                      return this.dispatch(val, payload, formattedArgs.option);
                  };
              });
              return result;
          }
          updateReactiveKey(computedKey, newValue) {
              let oldValue = this.reactiveKeys[computedKey];
              if (oldValue !== newValue) {
                  oldValue && this.unsubscribe(oldValue);
                  this.subscribe(newValue);
                  this.reactiveKeys[computedKey] = newValue;
                  this.state[newValue] = '';
              }
          }
          subscribe(key) {
              this.subscribeBuffer.push(key);
              this.flushSubscribeDebounce();
          }
          unsubscribe(key) {
              this.connectModule.unsubscribe([key]);
              this.releaseDefaultData(key);
          }
          routerEnter(context, namespace, item) {
              this.instance.routeEnterProcessController.run((param) => {
                  const resolveItem = this.resolveFinalPointer(namespace, item, context);
                  this.updateReactiveKey(item.computedKey, resolveItem.finalPointer);
                  developLogger.info('[store] resolve connectViews pointer success', resolveItem.finalPointer);
              });
          }
          resolveFinalPointer(namespace, item, vm, isDefault = false) {
              let uri = item.pointer;
              if (item.builder) {
                  let buildResult = ResolveBuilder(item.builder, vm, isDefault);
                  Object.assign(item, buildResult);
                  uri = buildResult.pointer;
              }
              if (!uri)
                  throw new Error('final pointer undefined');
              if (item.params) {
                  uri = `${uri}?${qs.stringify(item.params)}`;
              }
              uri = pointerCompose(namespace, uri);
              item.finalPointer = uri;
              return item;
          }
          flushSubscribe() {
              developLogger.info('flushSubscribe to store runtime');
              this.connectModule.subscribe(this.subscribeBuffer);
              this.subscribeBuffer.length = 0;
          }
          updateData(changes) {
              developLogger.info('[view] updateData', changes);
              for (const change of changes) {
                  if (this.state.hasOwnProperty(change.point)) {
                      mergeItem({
                          Vue: {
                              set(obj, key, value) {
                                  obj[key] = value;
                              }
                          }
                      }, this.state, change.point, this.state[change.point], change.value);
                  }
                  else {
                      developLogger.warn(`[view] abandon unnecessary data: ${change.point} value: ${change.value}`);
                  }
              }
              developLogger.timeoutInfo(0, `[view] updateData success`, changes);
          }
          initConnection() {
              this.instance.globalEventManager.addEventListener(ConnectEventType.data, (event) => __awaiter(this, void 0, void 0, function* () {
                  const changes = event.changes;
                  if (!changes) {
                      developLogger.info('[view][store.module] empty data');
                      return;
                  }
                  if (this.storeConfig.pageInitAction) {
                      this.setDataProcessController.run(() => {
                          this.updateData(changes);
                      });
                  }
                  else {
                      this.updateData(changes);
                  }
              }));
          }
      }

      class StoreModuleClass {
          constructor(instance) {
              this._pointerId = 1;
              this.initStoreShadow = {};
              this.relationRecord = {};
              this.flushSubscribeDebounce = debounce_1(this.flushSubscribe, 1, {});
              this.subscribeBuffer = [];
              this.storeConfig = cloneDeep_1(DEFAULT_STORE_CONFIG);
              this.defaultDataCache = {};
              this.instance = instance;
              this.connectModule = instance.requireModule('connect');
              this.routerModule = instance.requireModule('router');
              this.useSyncCall = instance.instanceConfig.syncCall;
              this.vueInstance = new instance.runtimeContext.Vue({
                  data: {
                      $$state: {},
                      $$pointerMap: {}
                  }
              });
              this.setDataProcessController = new BaseProcessController(this.instance);
              this.storeShadow = this.vueInstance.$data.$$state;
              this.initConnection();
          }
          get pointerId() {
              return (this._pointerId++).toString();
          }
          destroy() {
              this.flushSubscribeDebounce.cancel();
          }
          config(config) {
              if (config.pageInitAction) {
                  if (isString(config.pageInitAction)) {
                      this.storeConfig.pageInitAction = config.pageInitAction;
                  }
                  else {
                      this.storeConfig.pageInitAction = DEFAULT_STORE_PAGE_INIT_ACTION;
                  }
                  this.instance.routeEnterProcessController.run(() => __awaiter(this, void 0, void 0, function* () {
                      yield new this.instance.injectContext.Promise(resolve => {
                          this.instance.injectContext.setTimeout(resolve, 1);
                      });
                      let result = null;
                      let err = null;
                      try {
                          result = yield this.dispatch(this.storeConfig.pageInitAction, {
                              query: this.routerModule.currentQuery,
                              route: this.routerModule.currentRoute
                          });
                      }
                      catch (err) {
                          developLogger.error(err);
                      }
                      developLogger.info('[store] setData process flush');
                      this.setDataProcessController.flush();
                      this.instance.globalEventManager.dispatchEvent('store.pageInit', [err, result], {
                          backtracking: true
                      });
                  }));
              }
          }
          init(storeShadow) {
              Object.assign(this.initStoreShadow, storeShadow);
          }
          dispatch(actionName, data, option) {
              return new this.instance.injectContext.Promise((resolve, reject) => {
                  developLogger.info('dispatch', actionName, data);
                  ReportTimer.start('dispatch');
                  this.connectModule.dispatch(actionName, data || {}, data => {
                      developLogger.info('dispatch.result', this.instance.id, actionName, data);
                      if (data.type === 'json') {
                          resolve(data.result);
                      }
                      else if (data.type === 'error') {
                          reject(new Error(data.result));
                      }
                      else {
                          resolve(data.result);
                      }
                  }, option);
              });
          }
          syncGetDefaultData(pointer) {
              if (!this.useSyncCall)
                  return;
              if (!this.defaultDataCache[pointer]) {
                  this.defaultDataCache[pointer] = {
                      value: this.connectModule.syncCall({
                          type: 'getData',
                          target: pointer
                      })
                  };
              }
              return this.defaultDataCache[pointer].value;
          }
          releaseDefaultData(pointer) {
              if (!this.useSyncCall)
                  return;
              delete this.defaultDataCache[pointer];
          }
          connectViews(namespace, config, option) {
              const formattedArgs = argsFormat(namespace, config, option);
              if (!formattedArgs.config) {
                  return {};
              }
              let result = {};
              const normalizedConfig = ConnectConfigPreProcess(formattedArgs.config);
              const self = this;
              const buildRelationCache = {};
              for (const item of normalizedConfig.staticItems) {
                  const pointerUUID = this.pointerId;
                  let finalPointer = pointerCompose(formattedArgs.namespace, item.pointer);
                  result[item.computedKey] = () => {
                      if (!buildRelationCache[pointerUUID]) {
                          self.buildStoreRelation(finalPointer, item);
                          buildRelationCache[pointerUUID] = true;
                      }
                      return self.storeShadow[finalPointer];
                  };
              }
              for (const item of normalizedConfig.builderItems) {
                  const pointerUUID = this.pointerId;
                  self.vueInstance.$set(self.vueInstance.$data.$$pointerMap, pointerUUID, undefined);
                  result[item.computedKey] = function () {
                      let finalPointer = self.vueInstance.$data.$$pointerMap[pointerUUID];
                      if (!finalPointer) {
                          self.instance.routeEnterProcessController.run(() => {
                              const resolveItem = self.resolveFinalPointer(formattedArgs.namespace, item, this);
                              finalPointer = resolveItem.finalPointer;
                              self.buildStoreRelation(finalPointer, item);
                              self.vueInstance.$data.$$pointerMap[pointerUUID] = finalPointer;
                              developLogger.info('[store] resolve connectViews pointer success', finalPointer);
                          });
                          if (finalPointer) {
                              return self.storeShadow[finalPointer];
                          }
                          else {
                              const resolveItem = self.resolveFinalPointer(formattedArgs.namespace, item, this, true);
                              self.buildStoreRelation(resolveItem.finalPointer, item);
                              return self.storeShadow[resolveItem.finalPointer];
                          }
                      }
                      else {
                          const resolveItem = self.resolveFinalPointer(formattedArgs.namespace, item, this);
                          const newFinalPointer = resolveItem.finalPointer;
                          if (newFinalPointer !== finalPointer) {
                              self.buildStoreRelation(newFinalPointer, item);
                              self.vueInstance.$data.$$pointerMap[pointerUUID] = newFinalPointer;
                              self.releaseStoreRelation(finalPointer);
                              return self.storeShadow[newFinalPointer];
                          }
                          else {
                              return self.storeShadow[finalPointer];
                          }
                      }
                  };
              }
              return result;
          }
          connectActions(namespace, config, option) {
              const formattedArgs = argsFormat(namespace, config, option);
              if (!formattedArgs.config) {
                  return {};
              }
              let result = {};
              const normalizedConfig = normalizeMap(formattedArgs.config, formattedArgs.namespace);
              normalizedConfig.forEach(({ key, val }) => {
                  result[key] = (payload) => {
                      return this.dispatch(val, payload, formattedArgs.option);
                  };
              });
              return result;
          }
          flushSubscribe() {
              developLogger.info('flushSubscribe to store runtime');
              this.connectModule.subscribe(this.subscribeBuffer);
              this.subscribeBuffer.length = 0;
          }
          buildStoreRelation(finalPointer, item) {
              if (isUndefined(this.relationRecord[finalPointer]) || this.relationRecord[finalPointer] <= 0) {
                  let defaultValue = this.initStoreShadow[finalPointer];
                  if (!defaultValue) {
                      defaultValue = isUndefined(item.defaultValue) ? this.syncGetDefaultData(finalPointer) : item.defaultValue;
                  }
                  developLogger.info('subscribe', this.instance.id, finalPointer);
                  this.vueInstance.$set(this.storeShadow, finalPointer, defaultValue);
                  this.subscribeBuffer.push(finalPointer);
                  this.relationRecord[finalPointer] = 1;
                  this.flushSubscribeDebounce();
              }
              else {
                  this.relationRecord[finalPointer]++;
              }
          }
          releaseStoreRelation(finalPointer) {
              this.relationRecord[finalPointer]--;
              if (this.relationRecord[finalPointer] <= 0) {
                  developLogger.info('[view] release relation', this.instance.id, finalPointer);
                  delete this.storeShadow[finalPointer];
                  this.connectModule.unsubscribe([finalPointer]);
                  delete this.relationRecord[finalPointer];
                  this.releaseDefaultData(finalPointer);
              }
          }
          resolveFinalPointer(namespace, item, vm, isDefault = false) {
              let uri = item.pointer;
              if (item.builder) {
                  let buildResult = ResolveBuilder(item.builder, vm, isDefault);
                  Object.assign(item, buildResult);
                  uri = buildResult.pointer;
              }
              if (!uri)
                  throw new Error('final pointer undefined');
              if (item.params) {
                  uri = `${uri}?${qs.stringify(item.params)}`;
              }
              uri = pointerCompose(namespace, uri);
              item.finalPointer = uri;
              return item;
          }
          updateData(changes) {
              developLogger.info('[view] updateData', changes);
              for (const change of changes) {
                  if (this.relationRecord[change.point]) {
                      mergeItem(this.instance.runtimeContext, this.storeShadow, change.point, this.storeShadow[change.point], change.value);
                  }
                  else {
                      developLogger.warn(`[view] abandon unnecessary data: ${change.point} value: ${change.value}`);
                  }
              }
              developLogger.timeoutInfo(0, `[view] updateData success`, changes);
          }
          initConnection() {
              this.instance.globalEventManager.addEventListener(ConnectEventType.data, (event) => __awaiter(this, void 0, void 0, function* () {
                  const changes = event.changes;
                  if (!changes) {
                      developLogger.info('[view][store.module] empty data');
                      return;
                  }
                  if (this.storeConfig.pageInitAction) {
                      this.setDataProcessController.run(() => {
                          this.updateData(changes);
                      });
                  }
                  else {
                      this.updateData(changes);
                  }
              }));
          }
      }
      function storeModuleBuilder(instance) {
          if (instance.config.frameworkType === FrameworkType.Vue3ForFlutterPage) {
              return new Store(instance);
          }
          return new StoreModuleClass(instance);
      }

      class SnapshotModuleClass {
          constructor(instance) {
              this.snapshotManager = instance.snapshotManager;
          }
          get snapshotMode() {
              return this.snapshotManager.snapshotMode;
          }
          save() {
              this.snapshotManager.save();
          }
          remove() {
              this.snapshotManager.remove();
          }
          cancelAutoSave() {
              this.snapshotManager.cancelAutoSave();
          }
      }
      function snapshotModuleBuilder(instance) {
          return new SnapshotModuleClass(instance);
      }

      class FlutterPageViewModuleManager extends ModuleManager {
          static getInstance() {
              if (!FlutterPageViewModuleManager.instance) {
                  FlutterPageViewModuleManager.instance = new FlutterPageViewModuleManager({
                      controls: {
                          setTitle: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setTitleAlpha: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setTitleBackgroundColor: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setBottomBarColor: {
                              type: ModuleSnapshotType.lastCall
                          },
                          showTitle: {
                              type: ModuleSnapshotType.lastCall
                          },
                          hideTitle: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setHomeIcon: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setTitleIcon: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setSubtitle: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setSubtitleColor: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setTitleLeftText: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setTitleRightText: {
                              type: ModuleSnapshotType.lastCall
                          },
                          setTitleTextButtonColor: {
                              type: ModuleSnapshotType.lastCall
                          }
                      }
                  });
              }
              FlutterPageViewModuleManager.instance.add('dom', flutterViewDomModuleBuilder);
              FlutterPageViewModuleManager.instance.add('store', storeModuleBuilder);
              FlutterPageViewModuleManager.instance.add('notice', noticeModuleBuilder);
              FlutterPageViewModuleManager.instance.add('snapshot', snapshotModuleBuilder);
              return FlutterPageViewModuleManager.instance;
          }
      }

      class DOMTokenList {
          constructor(onChange) {
              this.length = 0;
              this.list = [];
              this.isDirty = true;
              this.className = '';
              this.onChange = onChange;
          }
          add(...classList) {
              for (const item of classList) {
                  if (this.list.indexOf(item) <= -1) {
                      this.list.push(item);
                  }
              }
              this.triggerChange();
              return this.list;
          }
          contains(className) {
              return this.list.indexOf(className) >= 0;
          }
          setClassList(classList) {
              this.list = classList;
              this.triggerChange();
          }
          item(index) {
              return this.list[index];
          }
          remove(...removeList) {
              this.list = this.list.filter(item => {
                  return removeList.indexOf(item) <= -1;
              });
              this.triggerChange();
              return this.list;
          }
          toClassName() {
              if (this.isDirty) {
                  this.className = this.list.join(' ');
                  this.isDirty = false;
              }
              return this.className;
          }
          fromClassName(className) {
              this.list = className.split(' ');
              this.triggerChange();
          }
          toggle(className, forceOperating) {
              const index = this.list.indexOf(className);
              const isExist = index >= 0;
              if (typeof forceOperating === 'undefined') {
                  if (isExist) {
                      this.list.splice(index, 1);
                  }
                  else {
                      this.list.push(className);
                  }
                  this.triggerChange();
                  return !isExist;
              }
              else {
                  if (forceOperating !== isExist) {
                      if (!forceOperating) {
                          this.list.splice(index, 1);
                      }
                      else {
                          this.list.push(className);
                      }
                  }
                  this.triggerChange();
                  return forceOperating;
              }
          }
          triggerChange() {
              const changedClassName = this.list.join(' ');
              if (this.className !== changedClassName) {
                  this.isDirty = false;
                  this.className = changedClassName;
                  this.onChange(changedClassName);
              }
          }
      }

      let NO_BUBBLE_EVENTS = ['scroll', 'load', 'focus', 'confirm', 'blur', 'timeupdate', 'scrolltoupper', 'scrolltolower', 'change'];
      function createEvent(type, target, detail) {
          const eventInit = {
              bubbles: true,
              cancelable: true
          };
          if (NO_BUBBLE_EVENTS.indexOf(type) >= 0) {
              eventInit.bubbles = false;
          }
          const event = new Event(type, eventInit);
          event.target = event.currentTarget = target;
          event.timeStamp = Date.now();
          event.detail = detail;
          return event;
      }
      class Event {
          constructor(typeArg, eventInit) {
              this.cancelBubble = false;
              this.isStopImmediatePropagation = false;
              this.currentTarget = null;
              this.defaultPrevented = false;
              this.target = null;
              this.timeStamp = 0;
              this.eventPhase = EventPhase.NONE;
              this.type = typeArg;
              this.bubbles = eventInit.bubbles;
              this.cancelable = eventInit.cancelable;
          }
          stopImmediatePropagation() {
              this.isStopImmediatePropagation = true;
              this.cancelBubble = true;
          }
          preventDefault() {
              this.defaultPrevented = true;
          }
          stopPropagation() {
              this.cancelBubble = true;
          }
      }
      var EventPhase;
      (function (EventPhase) {
          EventPhase[EventPhase["NONE"] = 0] = "NONE";
          EventPhase[EventPhase["CAPTURING_PHASE"] = 1] = "CAPTURING_PHASE";
          EventPhase[EventPhase["AT_TARGET"] = 2] = "AT_TARGET";
          EventPhase[EventPhase["BUBBLING_PHASE"] = 3] = "BUBBLING_PHASE";
      })(EventPhase || (EventPhase = {}));
      var EventType;
      (function (EventType) {
          EventType["touchstart"] = "touchstart";
          EventType["touchmove"] = "touchmove";
          EventType["touchcancel"] = "touchcancel";
          EventType["touchend"] = "touchend";
          EventType["tap"] = "tap";
          EventType["longpress"] = "longpress";
          EventType["longtap"] = "longtap";
          EventType["transitionend"] = "transitionend";
          EventType["touchforcechange"] = "touchforcechange";
          EventType["updateProps"] = "lite.updateProps";
      })(EventType || (EventType = {}));

      function isViewMappingRuntimeDecisionNode(node) {
          return 'decisionViewMapping' in node;
      }

      var NodeType;
      (function (NodeType) {
          NodeType[NodeType["element"] = 1] = "element";
          NodeType[NodeType["text"] = 3] = "text";
          NodeType[NodeType["comment"] = 8] = "comment";
      })(NodeType || (NodeType = {}));
      class Node {
          constructor(nodeType, option) {
              this.childNodes = [];
              this.parentNode = null;
              this.nextSibling = null;
              this.previousSibling = null;
              this.hasViewMapping = false;
              this.destroyed = false;
              this.nodeId = option.nodeId;
              this.nodeType = nodeType;
              this.ownerDocument = option.ownerDocument;
              this.domModule = this.ownerDocument.instance.requireModule('dom');
              this.ref = option.ref || option.nodeId;
              this.hasViewMapping = option.hasViewMapping;
          }
          get textContent() {
              let result = '';
              result += this.childNodes
                  .map((node) => {
                  return node.textContent;
              })
                  .join('');
              return result;
          }
          set textContent(val) {
              this.removeAllChild();
              this.appendChild(this.ownerDocument.createTextNode(val));
          }
          get firstChild() {
              return this.childNodes[0] || null;
          }
          hasChildNodes() {
              return !!this.childNodes.length;
          }
          appendChild(node) {
              if (!this.couldHasChildNodes())
                  return;
              this.transferRelationship(node, this);
              this.insertIndex(node, this.childNodes, this.childNodes.length);
              if (isViewMappingRuntimeDecisionNode(node)) {
                  node.decisionViewMapping(this);
              }
              if (node.hasViewMapping) {
                  this.domModule.appendChild(this.nodeId, node.nodeId);
              }
          }
          insertBefore(node, before) {
              if (!this.couldHasChildNodes())
                  return;
              if (node === before || (node.nextSibling && node.nextSibling === before)) {
                  return;
              }
              this.transferRelationship(node, this);
              let indexInfo;
              if (before) {
                  indexInfo = this.findIndex(before, this.childNodes);
              }
              else {
                  indexInfo = this.findLastIndex(this.childNodes);
              }
              this.insertIndex(node, this.childNodes, indexInfo ? indexInfo.nodeIndex : 0);
              if (isViewMappingRuntimeDecisionNode(node)) {
                  node.decisionViewMapping(this);
              }
              if (node.hasViewMapping) {
                  this.domModule.insertChild(this.nodeId, node.nodeId, (indexInfo === null || indexInfo === void 0 ? void 0 : indexInfo.elementIndex) || 0);
              }
          }
          insertAfter(node, after) {
              if (!this.couldHasChildNodes())
                  return;
              if (node === after || (node.previousSibling && node.previousSibling === after)) {
                  return;
              }
              this.transferRelationship(node, this);
              const indexInfo = this.findIndex(after, this.childNodes);
              this.insertIndex(node, this.childNodes, indexInfo ? indexInfo.nodeIndex + 1 : 0);
              if (isViewMappingRuntimeDecisionNode(node)) {
                  node.decisionViewMapping(this);
              }
              if (node.hasViewMapping) {
                  this.domModule.insertChild(this.nodeId, node.nodeId, (indexInfo === null || indexInfo === void 0 ? void 0 : indexInfo.elementIndex) || 0);
              }
          }
          removeChild(node) {
              let indexInfo = this.removeChildNode(node, this.childNodes);
              if (indexInfo && node.hasViewMapping) {
                  this.domModule.removeChild(this.nodeId, indexInfo.elementIndex);
              }
          }
          removeAllChild(destroy = false) {
              for (const node of this.childNodes) {
                  if (node.hasViewMapping) {
                      this.domModule.removeChild(this.nodeId, 0);
                  }
                  if (destroy) {
                      node.destroy(false, false);
                  }
              }
              this.childNodes = [];
          }
          destroy(wasAncestorsDestroy = false, removeFromParent = true) {
              if (!this.destroyed) {
                  if (this.hasViewMapping && !wasAncestorsDestroy) {
                      this.domModule.release(this.nodeId);
                  }
                  if (this.parentNode && removeFromParent) {
                      this.parentNode.vdomRemoveChild(this);
                  }
                  for (let currentChild = this.childNodes[0]; currentChild; currentChild = this.childNodes[0]) {
                      currentChild.destroy(true);
                  }
                  this.destroyed = true;
                  delete this.ownerDocument.nodeMap[this.nodeId];
              }
          }
          toDebugXML() {
              return `[node ${this.nodeId}]`;
          }
          findLastIndex(list) {
              let nodeIndex = 0;
              let elementIndex = 0;
              for (const item of list) {
                  if (item.hasViewMapping) {
                      elementIndex++;
                  }
                  nodeIndex++;
              }
              return {
                  nodeIndex,
                  elementIndex
              };
          }
          vdomRemoveChild(node) {
              return this.removeChildNode(node, this.childNodes);
          }
          findIndex(node, list) {
              let nodeIndex = 0;
              let elementIndex = 0;
              for (const item of list) {
                  if (item === node) {
                      return {
                          nodeIndex,
                          elementIndex
                      };
                  }
                  if (item.hasViewMapping) {
                      elementIndex++;
                  }
                  nodeIndex++;
              }
              return null;
          }
          removeChildNode(node, list) {
              const indexInfo = this.findIndex(node, list);
              if (!indexInfo)
                  return indexInfo;
              const nodeIndex = indexInfo.nodeIndex;
              const before = list[nodeIndex - 1];
              const after = list[nodeIndex + 1];
              if (before) {
                  before.nextSibling = after;
              }
              if (after) {
                  after.previousSibling = before;
              }
              node.nextSibling = null;
              node.previousSibling = null;
              list.splice(nodeIndex, 1);
              return indexInfo;
          }
          transferRelationship(node, newParent) {
              if (node.parentNode) {
                  node.parentNode.vdomRemoveChild(node);
              }
              if (newParent) {
                  node.parentNode = newParent;
              }
              else {
                  delete node.parentNode;
              }
          }
          couldHasChildNodes() {
              return this.nodeType === NodeType.element;
          }
          insertIndex(node, list, newIndex) {
              const index = newIndex < 0 ? 0 : newIndex;
              const before = list[index - 1];
              const after = list[index];
              list.splice(newIndex, 0, node);
              if (before) {
                  before.nextSibling = node;
              }
              if (after) {
                  after.previousSibling = node;
              }
              node.previousSibling = before;
              node.nextSibling = after;
              return index;
          }
      }

      class ChildNode extends Node {
          remove() {
              if (this.parentNode) {
                  this.parentNode.removeChild(this);
              }
              else {
                  this.destroy();
              }
          }
      }

      const nonDocumentTypeChildNodeMethods = {
          nextElementSibling(currentNode) {
              let node = currentNode.nextSibling;
              while (node) {
                  if (node.nodeType === NodeType.element) {
                      return node;
                  }
                  node = node.nextSibling;
              }
              return null;
          },
          previousElementSibling(currentNode) {
              let node = currentNode.previousSibling;
              while (node) {
                  if (node.nodeType === NodeType.element) {
                      return node;
                  }
                  node = node.previousSibling;
              }
              return null;
          }
      };

      class CharacterData extends ChildNode {
          constructor() {
              super(...arguments);
              this._data = '';
          }
          get data() {
              return this._data;
          }
          set data(val) {
              this._data = val;
          }
          get length() {
              return this.data.length;
          }
          get nextElementSibling() {
              return nonDocumentTypeChildNodeMethods.nextElementSibling(this);
          }
          get previousElementSibling() {
              return nonDocumentTypeChildNodeMethods.previousElementSibling(this);
          }
          appendData(data) {
              this.data += data;
          }
          deleteData(offset, count) {
              if (isUndefined(offset) || isUndefined(count)) {
                  throw new Error('2 arguments required');
              }
              this.data = this.data.slice(0, offset) + this.data.slice(offset + count);
          }
          replaceData(offset, count, data = '') {
              if (isUndefined(offset) || isUndefined(count)) {
                  throw new Error('2 arguments required');
              }
              this.data = this.data.slice(0, offset) + data + this.data.slice(offset + count);
          }
          substringData(offset, count) {
              if (isUndefined(offset) || isUndefined(count)) {
                  throw new Error('2 arguments required');
              }
              return this.data.slice(offset, offset + count);
          }
          insertData(offset, data) {
              if (isUndefined(offset)) {
                  throw new Error('2 arguments required');
              }
              if (!data) {
                  return;
              }
              this.data = this.data.slice(0, offset) + data + this.data.slice(offset);
          }
      }

      class Comment extends CharacterData {
          constructor(text, option) {
              super(NodeType.comment, option);
              this.data = text;
          }
          toDebugXML() {
              return `<!--${this.data} (node-id:${this.nodeId})-->`;
          }
          get textContent() {
              return this.data;
          }
          set textContent(text) {
              this.data = text;
          }
          destroy() {
              super.destroy();
          }
      }

      function isPrivateProp(name) {
          return name !== '__cssTextDirty' && name !== '__cssPropsDirty' && name !== '__associatedElement' && name !== '__dataSource';
      }
      class CSSStyleDeclaration {
          constructor(associatedElement, dataSource) {
              this.__cssTextDirty = true;
              this.__cssPropsDirty = true;
              this.__associatedElement = associatedElement;
              this.__dataSource = dataSource;
              return new Proxy(this, {
                  ownKeys(target) {
                      target.updateCssProps();
                      const keys = Reflect.ownKeys(target).filter((name) => {
                          return name !== 'cssText' && isPrivateProp(name);
                      });
                      return keys;
                  },
                  get(target, prop) {
                      if (target.__cssPropsDirty) {
                          target.updateCssProps();
                          target.__cssPropsDirty = false;
                      }
                      let targetValue = Reflect.get(target, prop);
                      if (isUndefined(targetValue)) {
                          targetValue = Reflect.get(target, toCamelCase(prop.toString()));
                      }
                      return targetValue;
                  },
                  set(target, prop, value) {
                      if (!associatedElement)
                          throw new Error(`${prop.toString()} is read-only`);
                      const formattedValue = isUndefined(value) ? '' : value.toString();
                      if (isString(prop)) {
                          if (prop === 'cssText') {
                              target.cssText = formattedValue;
                              associatedElement.attr.style = formattedValue;
                              associatedElement.domModule.setStyle(associatedElement.nodeId, formattedValue);
                          }
                          else {
                              const attrName = toCamelCase(prop);
                              target[attrName] = formattedValue;
                              target.__cssTextDirty = true;
                              const cssText = Reflect.get(target, 'cssText');
                              associatedElement.attr.style = cssText;
                              associatedElement.domModule.setStyle(associatedElement.nodeId, cssText);
                          }
                          return true;
                      }
                      else {
                          return false;
                      }
                  },
              });
          }
          get cssText() {
              if (this.__associatedElement) {
                  if (this.__cssTextDirty) {
                      let styleText = '';
                      for (let name of Object.keys(this)) {
                          if (isPrivateProp(name) && !isUndefined(this[name]) && this[name] !== '') {
                              styleText += `${toDashStyle(name)}:${this[name]};`;
                          }
                      }
                      this.__associatedElement.attr.style = styleText;
                      this.__cssTextDirty = false;
                  }
                  return this.__associatedElement.attr.style;
              }
              else {
                  let styleText = '';
                  for (let name of Object.keys(this)) {
                      if (isPrivateProp(name) && !isUndefined(this[name])) {
                          styleText += `${toDashStyle(name)}:${this[name]};`;
                      }
                  }
                  return styleText;
              }
          }
          set cssText(css) {
              if (!this.__associatedElement)
                  throw new Error('cssText is read-only');
              this.__associatedElement.attr.style = css;
              this.__cssPropsDirty = true;
          }
          updateCssProps() {
              if (this.__associatedElement && this.__associatedElement.attr.style) {
                  let pairs = this.__associatedElement.attr.style.split(';');
                  pairs.forEach((pair) => {
                      if (!pair.trim())
                          return;
                      let result = pair.split(':');
                      const cssKey = result[0];
                      let val = result[1];
                      if (cssKey === 'cssText')
                          return;
                      if (val)
                          val = val.trim();
                      this[toCamelCase(cssKey)] = val;
                  });
              }
              else if (this.__dataSource) {
                  const dataSource = this.__dataSource;
                  for (const key in dataSource) {
                      if (dataSource.hasOwnProperty(key)) {
                          let val = dataSource[key];
                          if (val)
                              val = val.trim();
                          this[toCamelCase(key)] = val;
                      }
                  }
              }
          }
      }

      class DOMStringMap {
          constructor(associatedElement) {
              return new Proxy(this, {
                  deleteProperty(target, prop) {
                      associatedElement.removeAttribute(`data-${toDashStyle(prop.toString())}`);
                      if (prop in target) {
                          return Reflect.deleteProperty(target, prop);
                      }
                      return true;
                  },
                  ownKeys(target) {
                      const resultKeys = [];
                      const keys = Object.keys(associatedElement.attr);
                      for (const key of keys) {
                          if (key.indexOf('data-') === 0) {
                              Reflect.set(target, toCamelCase(key.slice(5)), associatedElement.getAttribute(key));
                              resultKeys.push(toCamelCase(key.slice(5)));
                          }
                      }
                      return resultKeys;
                  },
                  get(target, prop) {
                      const key = prop.toString();
                      const targetValue = Reflect.get(target, prop);
                      if (isUndefined(targetValue)) {
                          const attrName = `data-${toDashStyle(key)}`;
                          const attrValue = associatedElement.getAttribute(attrName);
                          Reflect.set(target, prop, attrValue);
                          return attrValue;
                      }
                      else {
                          return targetValue;
                      }
                  },
                  set(target, prop, value) {
                      const key = prop.toString();
                      const attrName = `data-${toDashStyle(key)}`;
                      const attrValue = value.toString();
                      Reflect.set(target, prop, attrValue);
                      associatedElement.setAttribute(attrName, attrValue);
                      return true;
                  }
              });
          }
      }

      const stringToHtml = {
          '"': '&quot;',
      };
      const htmlToString = {
          '&quot;': '"',
      };
      function encode(str) {
          return str.replace(/"/g, stringToHtml['"']);
      }
      function decode(str) {
          return str.replace(/&quot;/g, htmlToString['&quot;']);
      }
      const htmlEncoder = {
          encode,
          decode,
      };

      const attrRegx = /([^<>=\s]+(=("[^"]+)")?)/g;
      const unitRegx = /<([A-Za-z0-9_-]+)((\s+([^<>='"\/\s]+(="[^"]*")?))*)\s*(\/)?>|<\/([A-Za-z0-9_-]+)\s*>|<!--([^<>]*)-->|([^<>]+)/g;
      function parseHTML(html) {
          unitRegx.lastIndex = 0;
          let currentUnit = unitRegx.exec(html);
          let nextUnit = unitRegx.exec(html);
          let currentNode = new ElementNode('#root');
          while (currentUnit) {
              const unitData = getUnitData(currentUnit);
              if (unitData.type === UnitType.open) {
                  let childNode = new ElementNode(unitData.value, unitData);
                  currentNode.addChild(childNode);
                  currentNode = childNode;
              }
              else if (unitData.type === UnitType.end) {
                  if (currentNode.parent) {
                      currentNode = currentNode.parent;
                  }
              }
              else if (unitData.type === UnitType.self) {
                  let childNode = new ElementNode(unitData.value, unitData);
                  currentNode.addChild(childNode);
              }
              else if (unitData.type === UnitType.comment) {
                  let childNode = new CommentNode(unitData.value);
                  currentNode.addChild(childNode);
              }
              else {
                  let childNode = new TextNode(unitData.value);
                  currentNode.addChild(childNode);
              }
              currentUnit = nextUnit;
              nextUnit = unitRegx.exec(html);
          }
          return currentNode.child;
      }
      var UnitType;
      (function (UnitType) {
          UnitType[UnitType["open"] = 0] = "open";
          UnitType[UnitType["self"] = 1] = "self";
          UnitType[UnitType["end"] = 2] = "end";
          UnitType[UnitType["text"] = 3] = "text";
          UnitType[UnitType["comment"] = 4] = "comment";
      })(UnitType || (UnitType = {}));
      class ElementNode {
          constructor(tagName, unitData) {
              this.child = [];
              this.attrs = {};
              this.isSelfClose = false;
              this.tagName = tagName;
              if (unitData) {
                  if (unitData.attrStr) {
                      this.setAttrs(unitData.attrStr);
                  }
                  this.isSelfClose = !!unitData.isSelfClose;
              }
          }
          static is(node) {
              return !!node.tagName;
          }
          addChild(child) {
              this.child.push(child);
              child.parent = this;
          }
          setAttrs(attrStr) {
              let execResult = attrRegx.exec(attrStr);
              while (execResult) {
                  const attr = execResult[0];
                  const equalSignIndex = attr.indexOf('=');
                  let key = '';
                  let value;
                  if (equalSignIndex > -1) {
                      key = attr.slice(0, equalSignIndex);
                      value = attr.slice(equalSignIndex + 2, attr.length - 1);
                  }
                  else {
                      key = attr;
                      value = '';
                  }
                  this.attrs[key] = htmlEncoder.decode(value);
                  execResult = attrRegx.exec(attrStr);
              }
          }
      }
      class CommentNode {
          constructor(value) {
              this.value = value;
          }
      }
      class TextNode {
          constructor(value) {
              this.value = value;
          }
      }
      function getUnitData(matchResult) {
          if (matchResult[1]) {
              if (!isUndefined(matchResult[6])) {
                  return {
                      value: matchResult[1],
                      type: UnitType.self,
                      attrStr: matchResult[2],
                      isSelfClose: true,
                  };
              }
              else {
                  return {
                      value: matchResult[1],
                      type: UnitType.open,
                      attrStr: matchResult[2],
                  };
              }
          }
          else if (!isUndefined(matchResult[7])) {
              return {
                  value: matchResult[7],
                  type: UnitType.end,
              };
          }
          else if (!isUndefined(matchResult[8])) {
              return {
                  value: matchResult[8],
                  type: UnitType.comment,
              };
          }
          else {
              return {
                  value: matchResult[9],
                  type: UnitType.text,
              };
          }
      }

      class DOMRectReadOnly {
          constructor(x = 0, y = 0, width = 0, height = 0) {
              this.x = x;
              this.y = y;
              this.width = width;
              this.height = height;
          }
          get top() {
              return Math.min(this.y, this.y + this.height);
          }
          get right() {
              return Math.max(this.x, this.x + this.width);
          }
          get bottom() {
              return Math.max(this.y, this.y + this.height);
          }
          get left() {
              return Math.min(this.x, this.x + this.width);
          }
          static fromRect(other) {
              return new DOMRectReadOnly(other.x, other.y, other.width, other.height);
          }
      }

      function isAttrValueFalse(value) {
          return value === false || value === 'false';
      }

      var TagName;
      (function (TagName) {
          TagName["div"] = "div";
          TagName["body"] = "body";
          TagName["head"] = "head";
          TagName["style"] = "style";
          TagName["document"] = "document";
      })(TagName || (TagName = {}));
      const DEFAULT_SCROLL_SMOOTH_DURATION = 300;
      class Element extends ChildNode {
          constructor(tagName = TagName.div, option) {
              super(NodeType.element, assignDefaultValue(option, {
                  hasViewMapping: true,
              }));
              this.nodeType = NodeType.element;
              this.event = {};
              this.scopedClass = [];
              this.isSelfClose = false;
              this.tagName = tagName;
              this.attr = {};
              if (this.hasViewMapping) {
                  this.classList = new DOMTokenList((newClassName) => {
                      this.updateClass(this.scopedClass, newClassName);
                  });
                  this.domModule.createElement(this.nodeId, tagName);
              }
              else {
                  this.classList = new DOMTokenList(() => { });
              }
              if (option.attr) {
                  this.setAttrObject(option.attr, option.isSnapshot);
              }
          }
          get clientHeight() {
              return this.domModule.getClientHeight(this.nodeId);
          }
          get clientWidth() {
              return this.domModule.getClientWidth(this.nodeId);
          }
          get clientTop() {
              return this.domModule.getClientTop(this.nodeId);
          }
          get clientLeft() {
              return this.domModule.getClientLeft(this.nodeId);
          }
          get offsetHeight() {
              return this.domModule.getOffsetHeight(this.nodeId);
          }
          get offsetWidth() {
              return this.domModule.getOffsetWidth(this.nodeId);
          }
          get offsetTop() {
              return this.domModule.getOffsetTop(this.nodeId);
          }
          get offsetLeft() {
              return this.domModule.getOffsetLeft(this.nodeId);
          }
          get snapshotInnerHTML() {
              return this._getInnerHTML(true, true);
          }
          set snapshotInnerHTML(html) {
              this._setInnerHTML(html, true);
          }
          get innerHTML() {
              return this._getInnerHTML(false);
          }
          set innerHTML(html) {
              this._setInnerHTML(html, false);
          }
          get id() {
              return this.getAttribute('id');
          }
          set id(val) {
              this.setAttribute('id', val);
          }
          get children() {
              return this.childNodes.filter((node) => {
                  return node.nodeType === NodeType.element;
              });
          }
          get className() {
              return this.classList.toClassName();
          }
          set className(val) {
              this.classList.fromClassName(val);
          }
          get nextElementSibling() {
              return nonDocumentTypeChildNodeMethods.nextElementSibling(this);
          }
          get previousElementSibling() {
              return nonDocumentTypeChildNodeMethods.previousElementSibling(this);
          }
          get scrollHeight() {
              return this.domModule.getScrollPosition(this.nodeId).scrollHeight;
          }
          get scrollWidth() {
              return this.domModule.getScrollPosition(this.nodeId).scrollWidth;
          }
          get scrollTop() {
              return this.domModule.getScrollPosition(this.nodeId).scrollTop;
          }
          set scrollTop(val) {
              this.scroll({ top: val });
          }
          get scrollLeft() {
              return this.domModule.getScrollPosition(this.nodeId).scrollLeft;
          }
          set scrollLeft(val) {
              this.scroll({ left: val });
          }
          get style() {
              if (!this._style) {
                  this._style = new CSSStyleDeclaration(this);
              }
              return this._style;
          }
          set style(css) {
              if (isString(css)) {
                  this.style.cssText = css;
              }
          }
          get dataset() {
              if (!this._dataset) {
                  this._dataset = new DOMStringMap(this);
              }
              return this._dataset;
          }
          static is(node) {
              return node.nodeType === NodeType.element;
          }
          toJSON() {
              return {};
          }
          addScopedClass(val) {
              if (this.scopedClass.indexOf(val) >= 0) {
                  return;
              }
              this.scopedClass.push(val);
              if (this.hasViewMapping) {
                  let className = this.classList.toClassName();
                  this.updateClass(this.scopedClass, className);
              }
          }
          toDebugXML() {
              let domAttr = ` node-id="${this.nodeId}"`;
              if (this.id) {
                  domAttr += ` id="${this.id}"`;
              }
              if (this.className) {
                  domAttr += ` class="${this.className}"`;
              }
              const attrString = this.getDebugAttrString();
              if (attrString) {
                  domAttr += ` ${attrString}`;
              }
              const eventString = this.getDebugEventString();
              if (eventString) {
                  domAttr += ` ${eventString}`;
              }
              if (this.scopedClass.length) {
                  domAttr += ` scoped`;
              }
              let result = `<${this.tagName}${domAttr}>`;
              let end = `</${this.tagName}>`;
              if (!this.childNodes.length) {
                  result = `<${this.tagName}${domAttr}/>`;
                  end = ``;
              }
              this.childNodes.forEach((child) => {
                  result = result += `${child.toDebugXML()}`;
              });
              result = result + end;
              return result;
          }
          querySelector(selector) {
              const nodeId = this.domModule.querySelector(this.nodeId, selector);
              if (nodeId >= 0) {
                  return this.ownerDocument.getRef(nodeId.toString());
              }
              return null;
          }
          querySelectorAll(selector) {
              const nodeIds = this.domModule.querySelectorAll(this.nodeId, selector);
              return nodeIds.map((nodeId) => {
                  return this.ownerDocument.getRef(nodeId.toString());
              });
          }
          getBoundingClientRect() {
              let result = this.domModule.getBoundingClientRect(this.nodeId);
              return DOMRectReadOnly.fromRect({
                  x: result[0],
                  y: result[1],
                  width: result[4],
                  height: result[5],
              });
          }
          scrollTo(option, optionY) {
              this.scroll(option, optionY);
          }
          scroll(option, optionY) {
              let x;
              let y;
              let duration = 0;
              if (isObject$1(option)) {
                  x = option.left;
                  y = option.top;
                  if (option.behavior === 'smooth') {
                      duration = DEFAULT_SCROLL_SMOOTH_DURATION;
                  }
                  if (!isUndefined(option.duration)) {
                      duration = option.duration;
                  }
              }
              else {
                  x = option;
                  y = optionY;
              }
              this.domModule.setScrollPosition(this.nodeId, JSON.stringify({ scrollLeft: x, scrollTop: y, duration }));
          }
          scrollBy(option, optionY) {
              let targetOption = {
                  top: undefined,
                  left: undefined,
                  duration: 0,
              };
              if (isObject$1(option)) {
                  targetOption = option;
              }
              else {
                  targetOption.left = option;
                  targetOption.top = optionY;
              }
              let result = this.domModule.getScrollPosition(this.nodeId);
              if (!isUndefined(targetOption.left)) {
                  targetOption.left = result.scrollLeft + targetOption.left;
              }
              if (!isUndefined(targetOption.top)) {
                  targetOption.top = result.scrollTop + targetOption.top;
              }
              this.scroll(targetOption);
          }
          addEventListener(type, listener, options = { once: false }) {
              const isNeedAddNativeEvent = this.pushEventListener(type, listener, options);
              if (isNeedAddNativeEvent) {
                  this.domModule.eventListenerChange(this.nodeId, true, type);
              }
          }
          removeEventListener(type, listener) {
              const eventList = this.event[type];
              if (!eventList || !eventList.length) {
                  return;
              }
              const foundIndex = eventList.findIndex((eventInfo) => {
                  return eventInfo.listener === listener;
              });
              if (foundIndex >= 0) {
                  eventList.splice(foundIndex, 1);
              }
              if (eventList.length === 0) {
                  this.domModule.eventListenerChange(this.nodeId, false, type);
              }
          }
          dispatchEvent(event) {
              if (event.eventPhase === EventPhase.NONE) {
                  const deepPath = [this];
                  let current = this.parentNode;
                  while (current && current instanceof Element) {
                      deepPath.push(current);
                      current = current.parentNode;
                  }
                  event.eventPhase = EventPhase.CAPTURING_PHASE;
                  for (let i = deepPath.length - 1; i >= 0 && !event.cancelBubble; i--) {
                      if (i === 0) {
                          event.eventPhase = EventPhase.AT_TARGET;
                      }
                      deepPath[i].dispatchEvent(event);
                  }
                  event.eventPhase = EventPhase.BUBBLING_PHASE;
                  for (let i = 1; i < deepPath.length && !event.cancelBubble; i++) {
                      deepPath[i].dispatchEvent(event);
                  }
              }
              else {
                  const eventList = this.event[event.type];
                  if (eventList) {
                      event.currentTarget = this;
                      for (let i = 0; i < eventList.length; i++) {
                          let info = eventList[i];
                          if (event.isStopImmediatePropagation) {
                              break;
                          }
                          if ((info.options.capture && event.eventPhase === EventPhase.CAPTURING_PHASE) ||
                              (!info.options.capture && event.eventPhase === EventPhase.BUBBLING_PHASE) ||
                              event.eventPhase === EventPhase.AT_TARGET) {
                              info.listener(event, info.options);
                              if (info.options.once) {
                                  eventList.splice(i, 1);
                                  i--;
                              }
                          }
                      }
                  }
              }
              return !event.defaultPrevented;
          }
          hasAttribute(key) {
              return !!this.attr[key];
          }
          getAttribute(key) {
              if (key === 'style') {
                  return this.style.cssText;
              }
              else if (key === 'class') {
                  return this.className;
              }
              else {
                  return isUndefined(this.attr[key]) ? undefined : this.attr[key].toString();
              }
          }
          setAttribute(key, value) {
              if (value instanceof Object) {
                  this.attr[key] = JSON.stringify(value);
              }
              else {
                  this.attr[key] = String(value);
              }
              if (!this.hasViewMapping) {
                  return;
              }
              const strValue = value;
              if (key === 'id') {
                  this.domModule.setId(this.nodeId, strValue);
              }
              else if (key === 'style') {
                  this.style.cssText = strValue;
              }
              else if (key === 'class') {
                  this.className = strValue;
              }
              else {
                  if (key.indexOf('data-') !== 0 && key.indexOf('snapshot-') !== 0) {
                      this.domModule.setAttr(this.nodeId, key, strValue);
                  }
              }
          }
          removeAttribute(key) {
              if (key.indexOf('data-') !== 0) {
                  this.attr[key] = '';
                  if (key === 'id') {
                      this.domModule.setId(this.nodeId, '');
                  }
                  else if (key === 'class') {
                      this.className = '';
                  }
                  else if (key === 'style') {
                      this.style.cssText = '';
                  }
                  else {
                      this.domModule.setAttr(this.nodeId, key, '');
                  }
              }
              else {
                  delete this.attr[key];
              }
          }
          setStyle(key, value) {
              this.style[key] = value;
          }
          _setInnerHTML(html, isSnapshot) {
              const nodes = parseHTML(html);
              this.removeAllChild(true);
              this.getChildFromParser(nodes, isSnapshot);
          }
          _getInnerHTML(withScope = false, isSnapshot = false) {
              let result = '';
              this.childNodes.forEach((child) => {
                  if (Element.is(child)) {
                      if (isSnapshot) {
                          if (child.attr.hasOwnProperty('snapshot-skip')) {
                              if (!isAttrValueFalse(child.attr['snapshot-skip'])) {
                                  return;
                              }
                          }
                      }
                      const selfHtml = child.selfHtml(withScope);
                      result = result += `${selfHtml.start}${child._getInnerHTML(withScope, isSnapshot)}${selfHtml.end}`;
                  }
                  else if (child.nodeType === NodeType.comment) {
                      result = result += `<!--${child.textContent}-->`;
                  }
                  else {
                      result = result += `${child.textContent}`;
                  }
              });
              return result;
          }
          selfHtml(withScope = false) {
              let domAttr = ``;
              if (this.className) {
                  domAttr += ` class="${this.className}"`;
              }
              if (withScope && this.scopedClass.length) {
                  domAttr += ` __scope__="${this.scopedClass.join(' ')}"`;
              }
              const attrString = this.getAttrString();
              if (attrString) {
                  domAttr += `${attrString}`;
              }
              let start = `<${this.tagName}${domAttr}>`;
              let end = `</${this.tagName}>`;
              if (!this.childNodes.length && this.isSelfClose) {
                  start = `<${this.tagName}${domAttr}/>`;
                  end = ``;
              }
              return {
                  start,
                  end,
              };
          }
          setAttrObject(attr, isSnapshot = false) {
              let overRideMap = {};
              if (isSnapshot) {
                  for (let attrName in attr) {
                      if (attrName.indexOf('snapshot-override:') > -1) {
                          attr[attrName.slice(18)] = attr[attrName];
                      }
                  }
              }
              for (let attrName in attr) {
                  if (attrName === '__scope__') {
                      this.addScopedClass(attr[attrName]);
                      delete attr[attrName];
                  }
                  else {
                      this.setAttribute(attrName, attr[attrName]);
                  }
              }
              if (isSnapshot) {
                  for (let overRideKey in overRideMap) {
                      this.setAttribute(overRideKey, overRideMap[overRideKey]);
                  }
              }
          }
          getChildFromParser(nodes, isSnapshot = false) {
              for (let node of nodes) {
                  if (ElementNode.is(node)) {
                      const currentNode = this.ownerDocument.createElement(node.tagName, {
                          isSnapshot,
                          attr: node.attrs,
                      });
                      if (node.child.length) {
                          currentNode.getChildFromParser(node.child, isSnapshot);
                      }
                      currentNode.isSelfClose = node.isSelfClose;
                      this.appendChild(currentNode);
                  }
                  else if (node instanceof CommentNode) {
                      this.appendChild(this.ownerDocument.createComment(node.value));
                  }
                  else {
                      this.appendChild(this.ownerDocument.createTextNode(node.value));
                  }
              }
          }
          updateClass(scopedClass, className) {
              const updateList = [];
              if (className) {
                  updateList.push(className);
              }
              if (scopedClass) {
                  updateList.push(...scopedClass);
              }
              this.domModule.setClass(this.nodeId, updateList.join(' '));
          }
          getDebugAttrString() {
              let attrString = '';
              for (const key in this.attr) {
                  if (key !== 'id' && key !== 'class') {
                      attrString = attrString + `${key}="${this.getAttribute(key)}"`;
                  }
              }
              return attrString;
          }
          getAttrString() {
              let attrString = '';
              for (const key in this.attr) {
                  if (key !== 'class') {
                      if (this.attr[key] === '') {
                          attrString = attrString + ` ${key}`;
                      }
                      else {
                          attrString = attrString + ` ${key}="${htmlEncoder.encode(this.attr[key])}"`;
                      }
                  }
              }
              return attrString;
          }
          getDebugEventString() {
              var _a;
              let eventString = '';
              for (const eventName in this.event) {
                  eventString += `@${eventName}="${(_a = this.event[eventName]) === null || _a === void 0 ? void 0 : _a.length}(listener)"`;
              }
              return eventString;
          }
          pushEventListener(type, listener, options) {
              let eventList = this.event[type];
              let isNeedAddNativeEvent = !eventList || eventList.length === 0;
              if (!eventList) {
                  this.event[type] = eventList = [];
              }
              else {
                  const index = eventList.findIndex((info) => {
                      if (info.listener === listener) {
                          return true;
                      }
                      else {
                          return false;
                      }
                  });
                  if (index >= 0) {
                      eventList.splice(index, 1);
                  }
              }
              eventList.push({
                  options,
                  listener,
              });
              return isNeedAddNativeEvent;
          }
      }

      class CustomerElement extends Element {
      }
      class CustomerElementManager {
          constructor() {
              this.elementMap = {};
              this.infos = {};
          }
          getCustomerClass(tagName) {
              return this.elementMap[tagName];
          }
          buildComponent(componentBuilder) {
              for (const key in this.infos) {
                  if (this.infos.hasOwnProperty(key)) {
                      componentBuilder(key, this.infos[key]);
                  }
              }
          }
          initCustomerElement(infos) {
              const self = this;
              this.infos = infos;
              for (const key in infos) {
                  if (infos.hasOwnProperty(key)) {
                      const info = infos[key];
                      info.properties = info.properties || [];
                      let propsKeys = info.properties.map((info) => {
                          return info.name;
                      });
                      let dashPropsKeys = propsKeys.map((key) => toDashStyle(key));
                      const newClass = class NewClass extends CustomerElement {
                          constructor(option) {
                              super(key, option);
                              this.propsCache = {};
                              return self.wrapCustomerElement(this, this.propsCache, propsKeys);
                          }
                          setAttribute(key, value) {
                              let targetIndex = dashPropsKeys.indexOf(key);
                              if (targetIndex > -1) {
                                  let targetKey = propsKeys[targetIndex];
                                  this[targetKey] = value;
                                  this.attr[key] = value;
                              }
                              else {
                                  super.setAttribute(key, value);
                              }
                          }
                          updateProps(props) {
                              for (let key in props) {
                                  this.propsCache[key] = props[key];
                              }
                          }
                      };
                      for (const method of info.methods) {
                          newClass.prototype[method.name] = function (...sourceArgs) {
                              return this.domModule.callMethod(this.nodeId, method.name, method, sourceArgs);
                          };
                      }
                      this.elementMap[key] = newClass;
                  }
              }
          }
          wrapCustomerElement(element, cache, propsKeys) {
              let handler = {
                  get(target, key) {
                      if (propsKeys.indexOf(key) > -1) {
                          return cache[key];
                      }
                      else {
                          return Reflect.get(target, key);
                      }
                  },
                  set(target, key, value) {
                      if (propsKeys.indexOf(key) > -1) {
                          if (cache[key] !== value) {
                              cache[key] = value;
                              target.domModule.setAttr(target.nodeId, key, value);
                          }
                          return true;
                      }
                      else {
                          return Reflect.set(target, key, value);
                      }
                  },
              };
              let proxy = new Proxy(element, handler);
              return proxy;
          }
      }

      const tagsAllowedInsideHead = [TagName.style];
      class HTMLHeadElement extends Element {
          constructor(option) {
              super(TagName.head, assignDefaultValue(option, {
                  hasViewMapping: false
              }));
              this.stylesheetMap = {};
          }
          appendChild(node) {
              if (!this.checkAllowedInside(node))
                  return;
              super.appendChild(node);
              this.refreshStyleSheet(node);
          }
          insertBefore(node, before) {
              if (!this.checkAllowedInside(node))
                  return;
              super.insertBefore(node, before);
              this.refreshStyleSheet(node);
          }
          removeChild(node) {
              if (!this.checkAllowedInside(node))
                  return;
              super.removeChild(node);
              this.refreshStyleSheet(node, true);
          }
          refreshStyleSheet(styleNode, isClear = false) {
              let index = isUndefined(this.stylesheetMap[styleNode.nodeId])
                  ? -1
                  : this.stylesheetMap[styleNode.nodeId];
              if (index > -1) {
                  if (isClear) {
                      this.ownerDocument.replaceStyleSheet(index, '');
                      delete this.stylesheetMap[styleNode.nodeId];
                  }
                  else {
                      this.ownerDocument.replaceStyleSheet(index, styleNode.textContent);
                  }
              }
              else {
                  if (isClear) {
                      return;
                  }
                  index = this.ownerDocument.addStyleSheet(styleNode.textContent);
                  this.stylesheetMap[styleNode.nodeId] = index;
              }
          }
          checkAllowedInside(node) {
              if (node.nodeType === NodeType.element &&
                  tagsAllowedInsideHead.indexOf(node.tagName) > -1) {
                  return true;
              }
              else {
                  return false;
              }
          }
      }

      class HTMLHtmlElement extends Element {
          get clientHeight() {
              return this.domModule.getWindowHeight();
          }
          get clientWidth() {
              return this.domModule.getWindowWidth();
          }
          get offsetHeight() {
              return this.domModule.getWindowHeight();
          }
          get offsetWidth() {
              return this.domModule.getWindowWidth();
          }
          get offsetTop() {
              return 0;
          }
          get offsetLeft() {
              return 0;
          }
      }

      class HTMLStyleElement extends Element {
          constructor(option) {
              super(TagName.style, assignDefaultValue(option, {
                  hasViewMapping: false
              }));
          }
          appendChild(node) {
              super.appendChild(node);
              this.handlerStyleSheet();
          }
          insertBefore(node, before) {
              super.insertBefore(node, before);
              this.handlerStyleSheet();
          }
          removeChild(node) {
              super.removeChild(node);
              this.handlerStyleSheet();
          }
          insertAfter(node, after) {
              super.insertAfter(node, after);
              this.handlerStyleSheet();
          }
          handlerStyleSheet() {
              let parentNode = this.parentNode;
              if (parentNode) {
                  if (parentNode instanceof HTMLHeadElement) {
                      parentNode.refreshStyleSheet(this);
                  }
              }
          }
      }

      class Text extends CharacterData {
          get textContent() {
              return this.data;
          }
          set textContent(text) {
              this.data = text;
          }
          get data() {
              return super.data;
          }
          set data(val) {
              super.data = val;
              this.setText();
          }
          constructor(text, option) {
              super(NodeType.text, option);
              this.data = text;
          }
          decisionViewMapping(parent) {
              if (parent instanceof HTMLStyleElement) {
                  this.hasViewMapping = false;
              }
              else {
                  this.hasViewMapping = true;
                  this.domModule.createElement(this.nodeId, 'string');
                  this.setText();
              }
          }
          appendData(data) {
              super.appendData(data);
              this.setText();
          }
          deleteData(offset, count) {
              super.deleteData(offset, count);
              this.setText();
          }
          replaceData(offset, count, data = '') {
              super.replaceData(offset, count, data);
              this.setText();
          }
          insertData(offset, data) {
              super.insertData(offset, data);
              this.setText();
          }
          toDebugXML() {
              return this.data;
          }
          setText() {
              if (this.hasViewMapping) {
                  this.domModule.setText(this.nodeId, this.data);
              }
          }
      }

      function getIntersectionObserverClass(document) {
          class IntersectionObserver {
              constructor(callback, options) {
                  this.domModule = document.domModule;
                  const realOptions = isUndefined(options) ? {} : options;
                  this.root = realOptions.root ? realOptions.root : document.documentElement;
                  this.rootMargin = realOptions.rootMargin || '0px';
                  if (realOptions.threshold) {
                      this.thresholds = isArray$1(realOptions.threshold) ? realOptions.threshold : [realOptions.threshold];
                  }
                  else {
                      this.thresholds = [0];
                  }
                  this.createObserverCallback = (data) => {
                      const entries = data.entries.map((entry) => {
                          return {
                              time: entry.time,
                              target: document.getRef(entry.target.toString()),
                              rootBounds: DOMRectReadOnly.fromRect(entry.rootBounds),
                              isIntersecting: entry.isIntersecting,
                              intersectionRatio: entry.intersectionRatio,
                              boundingClientRect: DOMRectReadOnly.fromRect(entry.boundingClientRect),
                              intersectionRect: DOMRectReadOnly.fromRect(entry.intersectionRect),
                          };
                      });
                      callback(entries, this);
                  };
                  this.id = this.domModule.createIntersectionObserver(this.root.nodeId, JSON.stringify({
                      rootMargin: this.rootMargin,
                      threshold: this.thresholds,
                  }), this.createObserverCallback);
              }
              disconnect() {
                  this.domModule.deleteIntersectionObserver(this.id);
                  if (this.createObserverCallback && this.createObserverCallback.__dispose) {
                      this.createObserverCallback.__dispose();
                  }
                  delete this.createObserverCallback;
              }
              observe(target) {
                  this.domModule.addIntersectionObserver(this.id, JSON.stringify([target.nodeId]));
              }
              unobserve(target) {
                  this.domModule.removeIntersectionObserver(this.id, JSON.stringify([target.nodeId]));
              }
          }
          return IntersectionObserver;
      }

      class Document {
          constructor(instance) {
              this.nodeMap = {};
              this.styleSheets = [];
              this.customerElementManager = new CustomerElementManager();
              this.id = instance.localId.toString();
              this.instance = instance;
              this.apiCenter = instance.apiCenter;
              this.domModule = instance.requireModule('dom');
              this.documentElement = this.createDocumentElement();
              this.body = this.createBody();
              this.head = this.createHeadElement();
              this.documentElement.appendChild(this.head);
              this.documentElement.appendChild(this.body);
          }
          querySelector(selector) {
              this.domModule.batch();
              const nodeId = this.domModule.querySelector(this.documentElement.nodeId, selector);
              if (nodeId >= 0) {
                  return this.getRef(nodeId);
              }
              return null;
          }
          querySelectorAll(selector) {
              this.domModule.batch();
              const nodeIds = this.domModule.querySelectorAll(this.documentElement.nodeId, selector);
              return nodeIds.map((nodeId) => {
                  return this.getRef(nodeId);
              });
          }
          getRef(ref) {
              return this.nodeMap[ref];
          }
          fireEvent(innerId, eventName, detail) {
              const targetNode = this.nodeMap[innerId];
              if (targetNode) {
                  if (eventName === 'lite.updateProps') {
                      targetNode.updateProps(detail);
                  }
                  else {
                      targetNode.dispatchEvent(createEvent(eventName, targetNode, detail));
                  }
              }
          }
          addStyleSheet(styleSheet) {
              this.styleSheets.push(styleSheet);
              this.domModule.appendStyle(styleSheet);
              return this.styleSheets.length - 1;
          }
          replaceStyleSheet(index, styleSheet) {
              this.styleSheets.splice(index, 1, styleSheet);
              this.domModule.replaceStyle(index, styleSheet);
          }
          clearStyleSheet() {
              this.styleSheets = [];
              this.domModule.clearStyle();
          }
          destroy() {
              this.documentElement.destroy();
              for (const key in this.nodeMap) {
                  this.nodeMap[key].destroy();
              }
              this.domModule.batch();
          }
          layout(callback) {
              if (this.domModule) {
                  this.domModule.requestLayout(callback);
              }
          }
          initCustomerElement(infos) {
              this.customerElementManager.initCustomerElement(infos);
          }
          createElement(tagName, option = {}) {
              if (tagName === TagName.document || tagName === TagName.body) {
                  throw new Error('document 和 body 不允许 createElement');
              }
              let el;
              const customerClass = this.customerElementManager.getCustomerClass(tagName);
              option.ownerDocument = this;
              option.docId = this.id;
              option.nodeId = this.instance.uniqueId();
              if (customerClass) {
                  el = new customerClass(option);
              }
              else if (tagName === 'style') {
                  el = new HTMLStyleElement(option);
              }
              else {
                  el = new Element(tagName, option);
              }
              this.nodeMap[el.nodeId] = el;
              return el;
          }
          createComment(text) {
              let el = new Comment(text, {
                  ownerDocument: this,
                  docId: this.id,
                  nodeId: this.instance.uniqueId(),
              });
              this.nodeMap[el.nodeId] = el;
              return el;
          }
          createTextNode(text) {
              let el = new Text(text, {
                  ownerDocument: this,
                  docId: this.id,
                  nodeId: this.instance.uniqueId(),
              });
              this.nodeMap[el.nodeId] = el;
              return el;
          }
          getWebContext() {
              return {
                  getComputedStyle: this.getComputedStyle.bind(this),
                  IntersectionObserver: getIntersectionObserverClass(this),
              };
          }
          getComputedStyle(element) {
              return new CSSStyleDeclaration(undefined, this.domModule.getComputedStyle(element.nodeId));
          }
          createBody() {
              const body = new Element(TagName.body, {
                  ownerDocument: this,
                  docId: this.id,
                  nodeId: this.instance.uniqueId(),
              });
              this.nodeMap[body.nodeId] = body;
              return body;
          }
          createDocumentElement() {
              const el = new HTMLHtmlElement(TagName.document, {
                  ownerDocument: this,
                  docId: this.id,
                  nodeId: this.instance.uniqueId(),
              });
              this.nodeMap[el.nodeId] = el;
              this.domModule.setRootNode(el.nodeId);
              return el;
          }
          createHeadElement() {
              const head = new HTMLHeadElement({
                  ownerDocument: this,
                  docId: this.id,
                  nodeId: this.instance.uniqueId(),
              });
              this.nodeMap[head.nodeId] = head;
              return head;
          }
      }

      class LiteProxyForFlutterPage extends LiteProxy {
          constructor(instance) {
              super(instance, []);
          }
      }

      var PerformanceMark;
      (function (PerformanceMark) {
          PerformanceMark["liteSnapshotReadStart"] = "liteSnapshotReadStart";
          PerformanceMark["liteSnapshotReadEnd"] = "liteSnapshotReadEnd";
          PerformanceMark["liteSnapshotApplyStart"] = "liteSnapshotApplyStart";
          PerformanceMark["liteSnapshotApplyEnd"] = "liteSnapshotApplyEnd";
      })(PerformanceMark || (PerformanceMark = {}));

      const SNAPSHOT_KV_KEY_PREFIX = 'liteapp_snap';
      class SnapshotManager {
          constructor(instance) {
              this.snapshotMode = false;
              this.needAutoSaveSnapshot = true;
              this.instance = instance;
          }
          get pageSnapshotKey() {
              const routerModule = this.instance.requireModule('router');
              return `${SNAPSHOT_KV_KEY_PREFIX}:${routerModule.currentRoute}?${qs.stringify(routerModule.currentQuery)}`;
          }
          save() {
              let store = this.instance.requireModule('store');
              developLogger.info(`[instance] save snapshot to ${this.pageSnapshotKey}`);
              let records = this.getModuleRecords();
              this.instance.baseLibApi.saveSnapshot(this.pageSnapshotKey, JSON.stringify({
                  moduleRecords: records,
                  store: store.storeShadow,
                  html: this.instance.document.body.snapshotInnerHTML,
                  envInfo: {
                      timestamp: Date.now(),
                      baseLibVersion: this.instance.runtimeConfig.baseLibInfo.version,
                      appVersion: this.instance.instanceConfig.version
                  }
              }));
              this.needAutoSaveSnapshot = false;
          }
          autoSave() {
              if (this.needAutoSaveSnapshot) {
                  developLogger.info('[instance] save snapshot before destroy');
                  this.save();
              }
          }
          remove() {
              this.instance.baseLibApi.removeSnapshot(this.pageSnapshotKey);
          }
          cancelAutoSave() {
              this.needAutoSaveSnapshot = false;
          }
          load() {
              return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                  const document = this.instance.document;
                  const storeModule = this.instance.requireModule('store');
                  let performance = this.instance.requireModule('performance');
                  let mark = (performance && performance.mark) ||
                      ((name) => {
                          runtimeLogger.info('[instance] performance.mark not found', name);
                      });
                  runtimeLogger.info('[instance] set routeEnter run task', this.instance.id);
                  this.instance.routeEnterProcessController.run(() => __awaiter(this, void 0, void 0, function* () {
                      runtimeLogger.info('[instance] routeEnter task flush');
                      try {
                          mark(PerformanceMark.liteSnapshotReadStart);
                          let res = yield this.instance.baseLibApi.loadSnapshot(this.pageSnapshotKey);
                          mark(PerformanceMark.liteSnapshotReadEnd);
                          if (res) {
                              let snap = JSON.parse(res);
                              let store = snap.store;
                              let moduleRecords = snap.moduleRecords;
                              developLogger.info('[instance] load snapshot start play module call', JSON.stringify(moduleRecords));
                              developLogger.info('[instance] load snapshot html', snap.html);
                              mark(PerformanceMark.liteSnapshotApplyStart);
                              if (moduleRecords) {
                                  this.replayModuleRecords(moduleRecords);
                              }
                              document.body.snapshotInnerHTML = snap.html;
                              const firstChild = document.body.children[0];
                              const childNodes = document.body.childNodes;
                              if (childNodes.length > 1) {
                                  for (let index = childNodes.length - 1; index >= 0; index--) {
                                      if (childNodes[index] !== firstChild) {
                                          document.body.removeChild(childNodes[index]);
                                          developLogger.info('[instance][view] unnecessary root node found: nodeType=', childNodes[index].nodeType);
                                      }
                                  }
                              }
                              firstChild.setAttribute('data-server-rendered', 'true');
                              storeModule.init(store);
                              mark(PerformanceMark.liteSnapshotApplyEnd);
                              this.snapshotMode = true;
                              resolve(true);
                          }
                          else {
                              this.snapshotMode = false;
                              resolve(false);
                          }
                      }
                      catch (e) {
                          this.snapshotMode = false;
                          this.instance.baseLibApi.removeSnapshot(this.pageSnapshotKey);
                          reject(e);
                      }
                  }));
              }));
          }
          replayModuleRecords(moduleRecords) {
              for (let key in moduleRecords) {
                  let module = this.instance.requireModule(key);
                  if (module.__lite__) {
                      module.__lite__.replay(moduleRecords[key]);
                  }
                  else {
                      runtimeLogger.error('[view] module record with nonexistent module', key);
                  }
              }
          }
          getModuleRecords() {
              let recordMap = {};
              for (let key in this.instance.moduleCache) {
                  let module = this.instance.moduleCache[key];
                  if (module.__lite__) {
                      recordMap[key] = [];
                      let callMap = module.__lite__.snapshotCallLastCallMap;
                      for (let methodName in callMap) {
                          recordMap[key].push(callMap[methodName]);
                      }
                  }
              }
              return recordMap;
          }
      }

      class FlutterPageInstanceConfig {
          constructor(config) {
              this.snapshot = false;
              this.syncCall = true;
              this.version = '0.0.0';
              let instanceInfo = config.instanceInfo;
              if (instanceInfo) {
                  if (instanceInfo.runtime) {
                      for (let key in instanceInfo.runtime) {
                          if (instanceInfo.runtime.hasOwnProperty(key)) {
                              let item = instanceInfo.runtime[key];
                              if (!isUndefined(item)) {
                                  this[key] = item;
                              }
                          }
                      }
                  }
                  if (instanceInfo.hostOverride) {
                      for (let key in instanceInfo.hostOverride) {
                          if (instanceInfo.hostOverride.hasOwnProperty(key)) {
                              let item = instanceInfo.hostOverride[key];
                              if (!isUndefined(item)) {
                                  this[key] = item;
                              }
                          }
                      }
                  }
                  if (instanceInfo.version) {
                      this.version = instanceInfo.version;
                  }
              }
          }
      }
      class FlutterPageInstanceContext extends InstanceContext {
          constructor(instance) {
              super(instance);
              this.setTimeout = instance.wrapTimer('setTimeout');
              this.setInterval = instance.wrapTimer('setInterval');
              this.lite = new LiteProxyForFlutterPage(instance);
              this.document = instance.document;
              const webContext = this.document.getWebContext();
              this.getComputedStyle = webContext.getComputedStyle;
              this.IntersectionObserver = webContext.IntersectionObserver;
          }
          get devicePixelRatio() {
              return this.document.domModule.getDevicePixelRatio();
          }
      }
      class FlutterPageInstance extends PageInstance {
          constructor(props) {
              super(props);
              this.register = Register.getInstance();
              this.componentsRegisterInfo = this.register.componentsInfo;
              this.reportInfo.type = 'flutter-view';
              this.apiCenter = new ApiCenterFlutterView({
                  callbackManager: this.callbackManager,
                  instance: this
              });
              this.receiver = new Receiver(this, [FireDomEventHandler, CallbackHandler, GlobalEventHandler], {
                  afterReceiveHook: () => {
                      this.document.layout();
                  }
              });
              this.instanceConfig = new FlutterPageInstanceConfig(this.config);
              this.moduleManager = FlutterPageViewModuleManager.getInstance();
              this.document = new Document(this);
              this.globalEventManager = new EventManagerClass(this, {
                  defer: this.instanceConfig.snapshot
              });
              this.routeEnterProcessController = new RouteEnterProcessController(this);
              this.baseLibApi = this.requirePrivateModule('baseLibApi');
              this.snapshotManager = new SnapshotManager(this);
              this.injectContext = new FlutterPageInstanceContext(this);
          }
          loadSnapShot() {
              return this.snapshotManager.load();
          }
          startUp(instanceId, setupParams) {
              super.startUp(instanceId, setupParams);
              runtimeLogger.info('start up');
              this.instanceConfig = new FlutterPageInstanceConfig(setupParams.config);
              this.document.initCustomerElement(this.register.componentsInfo);
              ReportTimer.start(`FlutterPage startUp${this.id}`);
          }
          afterRunCode() {
              super.afterRunCode();
              this.reportInfo.nodeNumAtFirstRun = Object.keys(this.document.nodeMap).length;
          }
          wrapTimer(timerName) {
              return super.wrapTimer(timerName, () => {
                  this.document.layout();
              });
          }
          getContext() {
              return this.injectContext;
          }
          destroy() {
              if (this.instanceConfig.snapshot) {
                  this.snapshotManager.autoSave();
              }
              this.reportInfo.nodeNumAtDestroy = Object.keys(this.document.nodeMap).length;
              this.document.destroy();
              this.requireModule('store').destroy();
              super.destroy();
          }
      }

      class AsyncErrorDetector {
          constructor(instanceManager) {
              this.instanceManager = instanceManager;
              this.listen();
          }
          setUp(runnerConfig) {
              this.matcher = new RegExp(`${codeTemplatePrefix}(\\w+)_${runnerConfig.uuid}__`);
          }
          dispatchError(tasks, parseResult) {
              if (parseResult) {
                  this.instanceManager.receive(parseResult.instanceId, tasks);
              }
          }
          reportError(type, error, parseResult) {
              if (parseResult) {
                  getGlobal().baseLibApi.reportError(parseResult.instanceId, type, error.message, error.stack);
              }
              else {
                  getGlobal().baseLibApi.reportError(0, type, error.message, error.stack);
              }
          }
          stackParse(error) {
              if (!this.matcher)
                  throw new Error('need setUp');
              if (!error || !error.stack)
                  return undefined;
              let matchResult = error.stack.match(this.matcher);
              if (!matchResult)
                  return undefined;
              let instanceId = matchResult[1];
              return {
                  instanceId: parseInt(instanceId, 10)
              };
          }
          errorHandle(type, promise, reason) {
              let tasks = [
                  {
                      name: ReceiverType.globalEvent,
                      args: ['error', [reason, 'unhandledRejection', promise]]
                  }
              ];
              if (promise && !isUndefined(promise.id)) {
                  try {
                      this.instanceManager.receive(promise.id, tasks);
                  }
                  finally {
                      if (reason) {
                          getGlobal().baseLibApi.reportError(promise.id, type, reason.message || reason.toString(), reason.stack);
                      }
                      else {
                          getGlobal().baseLibApi.reportError(promise.id, type, 'no reason', '');
                      }
                  }
              }
              else {
                  let parseResult = this.stackParse(reason);
                  this.dispatchError(tasks, parseResult);
                  this.reportError(type, reason, parseResult);
              }
          }
          listen() {
              getGlobal().onunhandledrejection = ({ promise, reason }) => {
                  this.errorHandle('promise', promise, reason);
              };
              getGlobal().wxajs.setPromiseRejectCallback((type, promise, reason) => {
                  try {
                      this.errorHandle(type || 'promise', promise, reason);
                  }
                  catch (e) {
                      getGlobal().baseLibApi.reportError(0, 'system', e.message, e.stack);
                  }
              });
          }
      }
      class FlutterViewAsyncErrorDetector extends AsyncErrorDetector {
          bypassReceive(instanceId, tasks) {
              for (let task of tasks) {
                  if (task.name === ReceiverType.globalEvent && task.args && task.args[0] === 'show') {
                      this.stackTopInstanceId = instanceId;
                      return;
                  }
              }
          }
          dispatchError(tasks, parseResult) {
              if (parseResult) {
                  super.dispatchError(tasks, parseResult);
              }
              else {
                  if (this.stackTopInstanceId) {
                      this.instanceManager.receive(this.stackTopInstanceId, tasks);
                  }
              }
          }
      }

      const PREPARE_DELAY = 50;
      class InstanceManager {
          constructor(option) {
              this.runtimeConfig = {
                  baseLibInfo: {
                      version: '1.5.1',
                      buildTarget: 'undefined',
                      buildType: 'development',
                  },
              };
              this.preCreateInstanceNum = 0;
              this.instanceMap = {};
              this.preCreateInstanceCache = {};
              this.currentLocalInstanceId = 10000;
              this.InstanceType = option.InstanceType;
              this.contextTransform = option.contextTransform;
              if (option.AsyncErrorDetector) {
                  this.asyncErrorDetector = new option.AsyncErrorDetector(this);
              }
              else {
                  this.asyncErrorDetector = new AsyncErrorDetector(this);
              }
          }
          get uniqLocalId() {
              return this.currentLocalInstanceId++;
          }
          setUp(setUpConfig) {
              if (!setUpConfig.runnerConfig)
                  throw new Error('初始化缺少参数： runnerConfig');
              this.asyncErrorDetector.setUp(setUpConfig.runnerConfig);
              this.runtimeConfig.hostInfo = setUpConfig.hostInfo;
              this.runtimeConfig.runnerConfig = setUpConfig.runnerConfig;
          }
          receive(id, tasks) {
              let runtimeInstance = this.findRuntimeInstance(id);
              if (runtimeInstance) {
                  return runtimeInstance.instance.receiver.receive(tasks);
              }
          }
          findRuntimeInstance(id) {
              return this.instanceMap[id];
          }
          destroyInstance(id) {
              const runtimeInstance = this.instanceMap[id];
              if (runtimeInstance) {
                  runtimeInstance.framework.destroyInstance(id);
                  runtimeInstance.instance.destroy();
                  Reporter.reportRuntimeInfo(runtimeInstance.instance.reportInfo);
                  delete this.instanceMap[id];
              }
          }
          createInstance(info) {
              if (this.instanceMap[info.id]) {
                  throw new Error(`The instance id "${info.id}" has already been used!`);
              }
              let runtimeInstance = this.getPreCreateInstance(info);
              runtimeInstance.instance.startUp(info.id, {
                  name: info.resource.name,
                  config: info.config,
              });
              this.instanceMap[info.id] = runtimeInstance;
              this.runInContext(info.resource, runtimeInstance);
              runtimeInstance.instance.afterRunCode();
              setTimeout(() => {
                  this.preparePreCreateInstance(info);
              }, PREPARE_DELAY);
              return runtimeInstance;
          }
          runCodeInInstance(info) {
              const runtimeInstance = this.findRuntimeInstance(info.id);
              if (isUndefined(runtimeInstance)) {
                  throw new Error('请先创建实例');
              }
              this.runInContext(info.resource, runtimeInstance);
          }
          preparePreCreateInstance(info) {
              let cacheList = this.preCreateInstanceCache[info.config.frameworkType];
              if (!cacheList) {
                  cacheList = this.preCreateInstanceCache[info.config.frameworkType] = [];
              }
              while (cacheList.length < this.preCreateInstanceNum) {
                  cacheList.push(this.preCreateInstance(info));
              }
          }
          runCodeInContext(func, runtimeInstance) {
              func.call(runtimeInstance.context, runtimeInstance.context);
          }
          getPreCreateInstance(info) {
              let cacheList = this.preCreateInstanceCache[info.config.frameworkType];
              if (cacheList && isNonEmptyArray(cacheList)) {
                  return cacheList.pop();
              }
              else {
                  return this.preCreateInstance(info);
              }
          }
          preCreateInstance(info) {
              let instance = new this.InstanceType({
                  localId: this.uniqLocalId,
                  config: info.config,
                  runtimeConfig: this.runtimeConfig,
                  execLib: (libInfo) => {
                      this.runLibInContext(libInfo, runtimeInstance);
                  },
              });
              const context = this.createInstanceContext(info.framework, instance);
              const runtimeInstance = {
                  instance,
                  framework: info.framework,
                  context,
              };
              return runtimeInstance;
          }
          runLibInContext(info, runtimeInstance) {
              let module = {
                  exports: {},
              };
              info.code.call(runtimeInstance.context, module, runtimeInstance.context);
              return (runtimeInstance.instance.libsMap[info.name] = module.exports);
          }
          runInContext(resource, runtimeInstance) {
              if (resource.libs) {
                  for (const libInfo of resource.libs) {
                      this.runLibInContext(libInfo, runtimeInstance);
                  }
              }
              Object.seal(runtimeInstance.instance);
              Object.seal(runtimeInstance);
              if (resource.code) {
                  this.runCodeInContext(resource.code, runtimeInstance);
              }
          }
          createInstanceContext(framework, liteInstance) {
              let runtimeContext = liteInstance.getContext();
              let instanceContext = runtimeContext;
              if (this.contextTransform) {
                  instanceContext = this.contextTransform(liteInstance, instanceContext);
              }
              Object.assign(instanceContext, framework.createInstanceContext(liteInstance.localId, runtimeContext, liteInstance), {
                  globalThis: instanceContext,
                  global: instanceContext,
                  self: instanceContext,
              });
              return instanceContext;
          }
      }

      class FlutterPageViewInstanceManager extends InstanceManager {
          constructor(option) {
              if (!option.AsyncErrorDetector) {
                  option.AsyncErrorDetector = FlutterViewAsyncErrorDetector;
              }
              super(option);
          }
          receive(id, tasks) {
              super.receive(id, tasks);
              this.asyncErrorDetector.bypassReceive(id, tasks);
          }
          runCodeInContext(func, runtimeInstance) {
              if (runtimeInstance.instance.instanceConfig.snapshot) {
                  developLogger.info('snapshot mode on');
                  runtimeInstance.instance
                      .loadSnapShot()
                      .then(isSuccess => {
                      if (isSuccess) {
                          developLogger.info('[instance] snapshot success');
                      }
                      else {
                          developLogger.info('[instance] snapshot not found');
                      }
                  })
                      .catch(() => {
                      developLogger.error('[instance] snapshot fail');
                  })
                      .finally(() => {
                      super.runCodeInContext(func, runtimeInstance);
                      runtimeInstance.instance.globalEventManager.flushDeferEvent();
                  });
              }
              else {
                  developLogger.info('snapshot mode off');
                  super.runCodeInContext(func, runtimeInstance);
              }
          }
      }

      const NotFramework = {
          createInstanceContext() {
              return {};
          },
          destroyInstance() { },
          refreshInstance() { }
      };

      const registerInstance = Register.getInstance();
      function bootstrap (manager, frameworks) {
          const targetGlobal = getGlobal();
          frameworks.NotFramework = NotFramework;
          Object.assign(targetGlobal, {
              runInInstance(id, resource) {
                  return manager.runCodeInInstance({
                      id,
                      resource
                  });
              },
              createInstance: (id, resource, instanceConfig) => {
                  return manager.createInstance({
                      id,
                      resource,
                      config: instanceConfig,
                      framework: frameworks[instanceConfig.frameworkType]
                  });
              },
              destroyInstance: (id) => {
                  manager.destroyInstance(id);
              },
              callJS(id, tasks) {
                  return manager.receive(id, tasks);
              },
              register(packets) {
                  registerInstance.register(packets);
              },
              loadFramework(frameworkType) {
                  return getGlobal().System.import(frameworkType);
              },
              setUp(config) {
                  manager.setUp(config);
                  for (const key in frameworks) {
                      if (key !== FrameworkType.NotFramework) {
                          manager.preparePreCreateInstance({
                              framework: frameworks[key],
                              config: { frameworkType: key }
                          });
                      }
                  }
              }
          });
      }

      const manager = new FlutterPageViewInstanceManager({ InstanceType: FlutterPageInstance });
      bootstrap(manager, getGlobal().frameworks);

    }
  };
});

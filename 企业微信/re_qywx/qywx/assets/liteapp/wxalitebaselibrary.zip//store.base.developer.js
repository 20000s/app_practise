System.register([], function (exports) {
	'use strict';
	return {
		execute: function () {

			exports({
				R: getGlobalThis,
				a2: getGlobal,
				a3: isNumber,
				a4: isArray,
				a6: baseLibModuleBuilder,
				a8: isUndefined,
				a9: getPromise,
				aa: getFetch,
				af: isString,
				ao: isNonEmptyArray,
				au: isFunction$1,
				l: createCommonjsModule,
				m: unwrapExports
			});

			var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

			function unwrapExports (x) {
				return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
			}

			function createCommonjsModule(fn, module) {
				return module = { exports: {} }, fn(module, module.exports), module.exports;
			}

			var check = function (it) {
			  return it && it.Math == Math && it;
			};

			// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
			var global_1 =
			  exports('g', // eslint-disable-next-line es/no-global-this -- safe
			  check(typeof globalThis == 'object' && globalThis) ||
			  check(typeof window == 'object' && window) ||
			  // eslint-disable-next-line no-restricted-globals -- safe
			  check(typeof self == 'object' && self) ||
			  check(typeof commonjsGlobal == 'object' && commonjsGlobal) ||
			  // eslint-disable-next-line no-new-func -- fallback
			  (function () { return this; })() || Function('return this')());

			var fails = exports('I', function (exec) {
			  try {
			    return !!exec();
			  } catch (error) {
			    return true;
			  }
			});

			// Detect IE8's incomplete defineProperty implementation
			var descriptors = exports('i', !fails(function () {
			  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
			  return Object.defineProperty({}, 1, { get: function () { return 7; } })[1] != 7;
			}));

			var $propertyIsEnumerable = {}.propertyIsEnumerable;
			// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
			var getOwnPropertyDescriptor$2 = Object.getOwnPropertyDescriptor;

			// Nashorn ~ JDK8 bug
			var NASHORN_BUG = getOwnPropertyDescriptor$2 && !$propertyIsEnumerable.call({ 1: 2 }, 1);

			// `Object.prototype.propertyIsEnumerable` method implementation
			// https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
			var f$5 = NASHORN_BUG ? function propertyIsEnumerable(V) {
			  var descriptor = getOwnPropertyDescriptor$2(this, V);
			  return !!descriptor && descriptor.enumerable;
			} : $propertyIsEnumerable;

			var objectPropertyIsEnumerable = exports('p', {
				f: f$5
			});

			var createPropertyDescriptor = exports('v', function (bitmap, value) {
			  return {
			    enumerable: !(bitmap & 1),
			    configurable: !(bitmap & 2),
			    writable: !(bitmap & 4),
			    value: value
			  };
			});

			var toString = {}.toString;

			var classofRaw = exports('E', function (it) {
			  return toString.call(it).slice(8, -1);
			});

			var split = ''.split;

			// fallback for non-array-like ES3 and non-enumerable old V8 strings
			var indexedObject = exports('S', fails(function () {
			  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
			  // eslint-disable-next-line no-prototype-builtins -- safe
			  return !Object('z').propertyIsEnumerable(0);
			}) ? function (it) {
			  return classofRaw(it) == 'String' ? split.call(it, '') : Object(it);
			} : Object);

			// `RequireObjectCoercible` abstract operation
			// https://tc39.es/ecma262/#sec-requireobjectcoercible
			var requireObjectCoercible = exports('A', function (it) {
			  if (it == undefined) throw TypeError("Can't call method on " + it);
			  return it;
			});

			// toObject with fallback for non-array-like ES3 strings



			var toIndexedObject = exports('t', function (it) {
			  return indexedObject(requireObjectCoercible(it));
			});

			var isObject$2 = exports('k', function (it) {
			  return typeof it === 'object' ? it !== null : typeof it === 'function';
			});

			var aFunction$1 = function (variable) {
			  return typeof variable == 'function' ? variable : undefined;
			};

			var getBuiltIn = exports('X', function (namespace, method) {
			  return arguments.length < 2 ? aFunction$1(global_1[namespace]) : global_1[namespace] && global_1[namespace][method];
			});

			var engineUserAgent = exports('D', getBuiltIn('navigator', 'userAgent') || '');

			var process$3 = global_1.process;
			var Deno = global_1.Deno;
			var versions = process$3 && process$3.versions || Deno && Deno.version;
			var v8 = versions && versions.v8;
			var match, version;

			if (v8) {
			  match = v8.split('.');
			  version = match[0] < 4 ? 1 : match[0] + match[1];
			} else if (engineUserAgent) {
			  match = engineUserAgent.match(/Edge\/(\d+)/);
			  if (!match || match[1] >= 74) {
			    match = engineUserAgent.match(/Chrome\/(\d+)/);
			    if (match) version = match[1];
			  }
			}

			var engineV8Version = version && +version;

			/* eslint-disable es/no-symbol -- required for testing */



			// eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
			var nativeSymbol = !!Object.getOwnPropertySymbols && !fails(function () {
			  var symbol = Symbol();
			  // Chrome 38 Symbol has incorrect toString conversion
			  // `get-own-property-symbols` polyfill symbols converted to object are not Symbol instances
			  return !String(symbol) || !(Object(symbol) instanceof Symbol) ||
			    // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
			    !Symbol.sham && engineV8Version && engineV8Version < 41;
			});

			/* eslint-disable es/no-symbol -- required for testing */


			var useSymbolAsUid = nativeSymbol
			  && !Symbol.sham
			  && typeof Symbol.iterator == 'symbol';

			var isSymbol = useSymbolAsUid ? function (it) {
			  return typeof it == 'symbol';
			} : function (it) {
			  var $Symbol = getBuiltIn('Symbol');
			  return typeof $Symbol == 'function' && Object(it) instanceof $Symbol;
			};

			// `OrdinaryToPrimitive` abstract operation
			// https://tc39.es/ecma262/#sec-ordinarytoprimitive
			var ordinaryToPrimitive = function (input, pref) {
			  var fn, val;
			  if (pref === 'string' && typeof (fn = input.toString) == 'function' && !isObject$2(val = fn.call(input))) return val;
			  if (typeof (fn = input.valueOf) == 'function' && !isObject$2(val = fn.call(input))) return val;
			  if (pref !== 'string' && typeof (fn = input.toString) == 'function' && !isObject$2(val = fn.call(input))) return val;
			  throw TypeError("Can't convert object to primitive value");
			};

			var setGlobal = function (key, value) {
			  try {
			    // eslint-disable-next-line es/no-object-defineproperty -- safe
			    Object.defineProperty(global_1, key, { value: value, configurable: true, writable: true });
			  } catch (error) {
			    global_1[key] = value;
			  } return value;
			};

			var SHARED = '__core-js_shared__';
			var store$1 = global_1[SHARED] || setGlobal(SHARED, {});

			var sharedStore = store$1;

			var shared = exports('L', createCommonjsModule(function (module) {
			(module.exports = function (key, value) {
			  return sharedStore[key] || (sharedStore[key] = value !== undefined ? value : {});
			})('versions', []).push({
			  version: '3.16.1',
			  mode: 'global',
			  copyright: '© 2021 Denis Pushkarev (zloirock.ru)'
			});
			}));

			// `ToObject` abstract operation
			// https://tc39.es/ecma262/#sec-toobject
			var toObject = exports('F', function (argument) {
			  return Object(requireObjectCoercible(argument));
			});

			var hasOwnProperty$3 = {}.hasOwnProperty;

			var has$2 = exports('j', Object.hasOwn || function hasOwn(it, key) {
			  return hasOwnProperty$3.call(toObject(it), key);
			});

			var id = 0;
			var postfix = Math.random();

			var uid = exports('u', function (key) {
			  return 'Symbol(' + String(key === undefined ? '' : key) + ')_' + (++id + postfix).toString(36);
			});

			var WellKnownSymbolsStore = shared('wks');
			var Symbol$2 = global_1.Symbol;
			var createWellKnownSymbol = useSymbolAsUid ? Symbol$2 : Symbol$2 && Symbol$2.withoutSetter || uid;

			var wellKnownSymbol = exports('w', function (name) {
			  if (!has$2(WellKnownSymbolsStore, name) || !(nativeSymbol || typeof WellKnownSymbolsStore[name] == 'string')) {
			    if (nativeSymbol && has$2(Symbol$2, name)) {
			      WellKnownSymbolsStore[name] = Symbol$2[name];
			    } else {
			      WellKnownSymbolsStore[name] = createWellKnownSymbol('Symbol.' + name);
			    }
			  } return WellKnownSymbolsStore[name];
			});

			var TO_PRIMITIVE = wellKnownSymbol('toPrimitive');

			// `ToPrimitive` abstract operation
			// https://tc39.es/ecma262/#sec-toprimitive
			var toPrimitive = function (input, pref) {
			  if (!isObject$2(input) || isSymbol(input)) return input;
			  var exoticToPrim = input[TO_PRIMITIVE];
			  var result;
			  if (exoticToPrim !== undefined) {
			    if (pref === undefined) pref = 'default';
			    result = exoticToPrim.call(input, pref);
			    if (!isObject$2(result) || isSymbol(result)) return result;
			    throw TypeError("Can't convert object to primitive value");
			  }
			  if (pref === undefined) pref = 'number';
			  return ordinaryToPrimitive(input, pref);
			};

			// `ToPropertyKey` abstract operation
			// https://tc39.es/ecma262/#sec-topropertykey
			var toPropertyKey = exports('s', function (argument) {
			  var key = toPrimitive(argument, 'string');
			  return isSymbol(key) ? key : String(key);
			});

			var document$3 = global_1.document;
			// typeof document.createElement is 'object' in old IE
			var EXISTS = isObject$2(document$3) && isObject$2(document$3.createElement);

			var documentCreateElement = function (it) {
			  return EXISTS ? document$3.createElement(it) : {};
			};

			// Thank's IE8 for his funny defineProperty
			var ie8DomDefine = !descriptors && !fails(function () {
			  // eslint-disable-next-line es/no-object-defineproperty -- requied for testing
			  return Object.defineProperty(documentCreateElement('div'), 'a', {
			    get: function () { return 7; }
			  }).a != 7;
			});

			// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
			var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

			// `Object.getOwnPropertyDescriptor` method
			// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
			var f$4 = descriptors ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
			  O = toIndexedObject(O);
			  P = toPropertyKey(P);
			  if (ie8DomDefine) try {
			    return $getOwnPropertyDescriptor(O, P);
			  } catch (error) { /* empty */ }
			  if (has$2(O, P)) return createPropertyDescriptor(!objectPropertyIsEnumerable.f.call(O, P), O[P]);
			};

			var objectGetOwnPropertyDescriptor = exports('y', {
				f: f$4
			});

			var anObject = exports('K', function (it) {
			  if (!isObject$2(it)) {
			    throw TypeError(String(it) + ' is not an object');
			  } return it;
			});

			// eslint-disable-next-line es/no-object-defineproperty -- safe
			var $defineProperty = Object.defineProperty;

			// `Object.defineProperty` method
			// https://tc39.es/ecma262/#sec-object.defineproperty
			var f$3 = descriptors ? $defineProperty : function defineProperty(O, P, Attributes) {
			  anObject(O);
			  P = toPropertyKey(P);
			  anObject(Attributes);
			  if (ie8DomDefine) try {
			    return $defineProperty(O, P, Attributes);
			  } catch (error) { /* empty */ }
			  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported');
			  if ('value' in Attributes) O[P] = Attributes.value;
			  return O;
			};

			var objectDefineProperty = exports('o', {
				f: f$3
			});

			var createNonEnumerableProperty = exports('h', descriptors ? function (object, key, value) {
			  return objectDefineProperty.f(object, key, createPropertyDescriptor(1, value));
			} : function (object, key, value) {
			  object[key] = value;
			  return object;
			});

			var functionToString = Function.toString;

			// this helper broken in `core-js@3.4.1-3.4.4`, so we can't use `shared` helper
			if (typeof sharedStore.inspectSource != 'function') {
			  sharedStore.inspectSource = function (it) {
			    return functionToString.call(it);
			  };
			}

			var inspectSource = sharedStore.inspectSource;

			var WeakMap$2 = global_1.WeakMap;

			var nativeWeakMap = typeof WeakMap$2 === 'function' && /native code/.test(inspectSource(WeakMap$2));

			var keys = shared('keys');

			var sharedKey = function (key) {
			  return keys[key] || (keys[key] = uid(key));
			};

			var hiddenKeys$1 = {};

			var OBJECT_ALREADY_INITIALIZED = 'Object already initialized';
			var WeakMap$1 = global_1.WeakMap;
			var set$1, get, has$1;

			var enforce = function (it) {
			  return has$1(it) ? get(it) : set$1(it, {});
			};

			var getterFor = function (TYPE) {
			  return function (it) {
			    var state;
			    if (!isObject$2(it) || (state = get(it)).type !== TYPE) {
			      throw TypeError('Incompatible receiver, ' + TYPE + ' required');
			    } return state;
			  };
			};

			if (nativeWeakMap || sharedStore.state) {
			  var store = sharedStore.state || (sharedStore.state = new WeakMap$1());
			  var wmget = store.get;
			  var wmhas = store.has;
			  var wmset = store.set;
			  set$1 = function (it, metadata) {
			    if (wmhas.call(store, it)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
			    metadata.facade = it;
			    wmset.call(store, it, metadata);
			    return metadata;
			  };
			  get = function (it) {
			    return wmget.call(store, it) || {};
			  };
			  has$1 = function (it) {
			    return wmhas.call(store, it);
			  };
			} else {
			  var STATE = sharedKey('state');
			  hiddenKeys$1[STATE] = true;
			  set$1 = function (it, metadata) {
			    if (has$2(it, STATE)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
			    metadata.facade = it;
			    createNonEnumerableProperty(it, STATE, metadata);
			    return metadata;
			  };
			  get = function (it) {
			    return has$2(it, STATE) ? it[STATE] : {};
			  };
			  has$1 = function (it) {
			    return has$2(it, STATE);
			  };
			}

			var internalState = exports('N', {
			  set: set$1,
			  get: get,
			  has: has$1,
			  enforce: enforce,
			  getterFor: getterFor
			});

			var redefine = exports('r', createCommonjsModule(function (module) {
			var getInternalState = internalState.get;
			var enforceInternalState = internalState.enforce;
			var TEMPLATE = String(String).split('String');

			(module.exports = function (O, key, value, options) {
			  var unsafe = options ? !!options.unsafe : false;
			  var simple = options ? !!options.enumerable : false;
			  var noTargetGet = options ? !!options.noTargetGet : false;
			  var state;
			  if (typeof value == 'function') {
			    if (typeof key == 'string' && !has$2(value, 'name')) {
			      createNonEnumerableProperty(value, 'name', key);
			    }
			    state = enforceInternalState(value);
			    if (!state.source) {
			      state.source = TEMPLATE.join(typeof key == 'string' ? key : '');
			    }
			  }
			  if (O === global_1) {
			    if (simple) O[key] = value;
			    else setGlobal(key, value);
			    return;
			  } else if (!unsafe) {
			    delete O[key];
			  } else if (!noTargetGet && O[key]) {
			    simple = true;
			  }
			  if (simple) O[key] = value;
			  else createNonEnumerableProperty(O, key, value);
			// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
			})(Function.prototype, 'toString', function toString() {
			  return typeof this == 'function' && getInternalState(this).source || inspectSource(this);
			});
			}));

			var ceil = Math.ceil;
			var floor = Math.floor;

			// `ToInteger` abstract operation
			// https://tc39.es/ecma262/#sec-tointeger
			var toInteger = exports('B', function (argument) {
			  return isNaN(argument = +argument) ? 0 : (argument > 0 ? floor : ceil)(argument);
			});

			var min$1 = Math.min;

			// `ToLength` abstract operation
			// https://tc39.es/ecma262/#sec-tolength
			var toLength = exports('C', function (argument) {
			  return argument > 0 ? min$1(toInteger(argument), 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
			});

			var max = Math.max;
			var min = Math.min;

			// Helper for a popular repeating case of the spec:
			// Let integer be ? ToInteger(index).
			// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
			var toAbsoluteIndex = function (index, length) {
			  var integer = toInteger(index);
			  return integer < 0 ? max(integer + length, 0) : min(integer, length);
			};

			// `Array.prototype.{ indexOf, includes }` methods implementation
			var createMethod$1 = function (IS_INCLUDES) {
			  return function ($this, el, fromIndex) {
			    var O = toIndexedObject($this);
			    var length = toLength(O.length);
			    var index = toAbsoluteIndex(fromIndex, length);
			    var value;
			    // Array#includes uses SameValueZero equality algorithm
			    // eslint-disable-next-line no-self-compare -- NaN check
			    if (IS_INCLUDES && el != el) while (length > index) {
			      value = O[index++];
			      // eslint-disable-next-line no-self-compare -- NaN check
			      if (value != value) return true;
			    // Array#indexOf ignores holes, Array#includes - not
			    } else for (;length > index; index++) {
			      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
			    } return !IS_INCLUDES && -1;
			  };
			};

			var arrayIncludes = exports('b', {
			  // `Array.prototype.includes` method
			  // https://tc39.es/ecma262/#sec-array.prototype.includes
			  includes: createMethod$1(true),
			  // `Array.prototype.indexOf` method
			  // https://tc39.es/ecma262/#sec-array.prototype.indexof
			  indexOf: createMethod$1(false)
			});

			var indexOf = arrayIncludes.indexOf;


			var objectKeysInternal = function (object, names) {
			  var O = toIndexedObject(object);
			  var i = 0;
			  var result = [];
			  var key;
			  for (key in O) !has$2(hiddenKeys$1, key) && has$2(O, key) && result.push(key);
			  // Don't enum bug & hidden keys
			  while (names.length > i) if (has$2(O, key = names[i++])) {
			    ~indexOf(result, key) || result.push(key);
			  }
			  return result;
			};

			// IE8- don't enum bug keys
			var enumBugKeys = [
			  'constructor',
			  'hasOwnProperty',
			  'isPrototypeOf',
			  'propertyIsEnumerable',
			  'toLocaleString',
			  'toString',
			  'valueOf'
			];

			var hiddenKeys = enumBugKeys.concat('length', 'prototype');

			// `Object.getOwnPropertyNames` method
			// https://tc39.es/ecma262/#sec-object.getownpropertynames
			// eslint-disable-next-line es/no-object-getownpropertynames -- safe
			var f$2 = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
			  return objectKeysInternal(O, hiddenKeys);
			};

			var objectGetOwnPropertyNames = {
				f: f$2
			};

			// eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
			var f$1 = Object.getOwnPropertySymbols;

			var objectGetOwnPropertySymbols = exports('T', {
				f: f$1
			});

			// all object keys, includes non-enumerable and symbols
			var ownKeys = exports('x', getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
			  var keys = objectGetOwnPropertyNames.f(anObject(it));
			  var getOwnPropertySymbols = objectGetOwnPropertySymbols.f;
			  return getOwnPropertySymbols ? keys.concat(getOwnPropertySymbols(it)) : keys;
			});

			var copyConstructorProperties = exports('J', function (target, source) {
			  var keys = ownKeys(source);
			  var defineProperty = objectDefineProperty.f;
			  var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
			  for (var i = 0; i < keys.length; i++) {
			    var key = keys[i];
			    if (!has$2(target, key)) defineProperty(target, key, getOwnPropertyDescriptor(source, key));
			  }
			});

			var replacement = /#|\.prototype\./;

			var isForced = function (feature, detection) {
			  var value = data[normalize(feature)];
			  return value == POLYFILL ? true
			    : value == NATIVE ? false
			    : typeof detection == 'function' ? fails(detection)
			    : !!detection;
			};

			var normalize = isForced.normalize = function (string) {
			  return String(string).replace(replacement, '.').toLowerCase();
			};

			var data = isForced.data = {};
			var NATIVE = isForced.NATIVE = 'N';
			var POLYFILL = isForced.POLYFILL = 'P';

			var isForced_1 = isForced;

			var getOwnPropertyDescriptor$1 = objectGetOwnPropertyDescriptor.f;






			/*
			  options.target      - name of the target object
			  options.global      - target is the global object
			  options.stat        - export as static methods of target
			  options.proto       - export as prototype methods of target
			  options.real        - real prototype method for the `pure` version
			  options.forced      - export even if the native feature is available
			  options.bind        - bind methods to the target, required for the `pure` version
			  options.wrap        - wrap constructors to preventing global pollution, required for the `pure` version
			  options.unsafe      - use the simple assignment of property instead of delete + defineProperty
			  options.sham        - add a flag to not completely full polyfills
			  options.enumerable  - export as enumerable property
			  options.noTargetGet - prevent calling a getter on target
			*/
			var _export = exports('_', function (options, source) {
			  var TARGET = options.target;
			  var GLOBAL = options.global;
			  var STATIC = options.stat;
			  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
			  if (GLOBAL) {
			    target = global_1;
			  } else if (STATIC) {
			    target = global_1[TARGET] || setGlobal(TARGET, {});
			  } else {
			    target = (global_1[TARGET] || {}).prototype;
			  }
			  if (target) for (key in source) {
			    sourceProperty = source[key];
			    if (options.noTargetGet) {
			      descriptor = getOwnPropertyDescriptor$1(target, key);
			      targetProperty = descriptor && descriptor.value;
			    } else targetProperty = target[key];
			    FORCED = isForced_1(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
			    // contained in target
			    if (!FORCED && targetProperty !== undefined) {
			      if (typeof sourceProperty === typeof targetProperty) continue;
			      copyConstructorProperties(sourceProperty, targetProperty);
			    }
			    // add a flag to not completely full polyfills
			    if (options.sham || (targetProperty && targetProperty.sham)) {
			      createNonEnumerableProperty(sourceProperty, 'sham', true);
			    }
			    // extend global
			    redefine(target, key, sourceProperty, options);
			  }
			});

			// `Object.keys` method
			// https://tc39.es/ecma262/#sec-object.keys
			// eslint-disable-next-line es/no-object-keys -- safe
			var objectKeys$1 = exports('n', Object.keys || function keys(O) {
			  return objectKeysInternal(O, enumBugKeys);
			});

			// `Object.defineProperties` method
			// https://tc39.es/ecma262/#sec-object.defineproperties
			// eslint-disable-next-line es/no-object-defineproperties -- safe
			var objectDefineProperties = exports('a0', descriptors ? Object.defineProperties : function defineProperties(O, Properties) {
			  anObject(O);
			  var keys = objectKeys$1(Properties);
			  var length = keys.length;
			  var index = 0;
			  var key;
			  while (length > index) objectDefineProperty.f(O, key = keys[index++], Properties[key]);
			  return O;
			});

			var html = getBuiltIn('document', 'documentElement');

			/* global ActiveXObject -- old IE, WSH */








			var GT = '>';
			var LT = '<';
			var PROTOTYPE = 'prototype';
			var SCRIPT = 'script';
			var IE_PROTO$1 = sharedKey('IE_PROTO');

			var EmptyConstructor = function () { /* empty */ };

			var scriptTag = function (content) {
			  return LT + SCRIPT + GT + content + LT + '/' + SCRIPT + GT;
			};

			// Create object with fake `null` prototype: use ActiveX Object with cleared prototype
			var NullProtoObjectViaActiveX = function (activeXDocument) {
			  activeXDocument.write(scriptTag(''));
			  activeXDocument.close();
			  var temp = activeXDocument.parentWindow.Object;
			  activeXDocument = null; // avoid memory leak
			  return temp;
			};

			// Create object with fake `null` prototype: use iframe Object with cleared prototype
			var NullProtoObjectViaIFrame = function () {
			  // Thrash, waste and sodomy: IE GC bug
			  var iframe = documentCreateElement('iframe');
			  var JS = 'java' + SCRIPT + ':';
			  var iframeDocument;
			  if (iframe.style) {
			    iframe.style.display = 'none';
			    html.appendChild(iframe);
			    // https://github.com/zloirock/core-js/issues/475
			    iframe.src = String(JS);
			    iframeDocument = iframe.contentWindow.document;
			    iframeDocument.open();
			    iframeDocument.write(scriptTag('document.F=Object'));
			    iframeDocument.close();
			    return iframeDocument.F;
			  }
			};

			// Check for document.domain and active x support
			// No need to use active x approach when document.domain is not set
			// see https://github.com/es-shims/es5-shim/issues/150
			// variation of https://github.com/kitcambridge/es5-shim/commit/4f738ac066346
			// avoid IE GC bug
			var activeXDocument;
			var NullProtoObject = function () {
			  try {
			    activeXDocument = new ActiveXObject('htmlfile');
			  } catch (error) { /* ignore */ }
			  NullProtoObject = document.domain && activeXDocument ?
			    NullProtoObjectViaActiveX(activeXDocument) : // old IE
			    NullProtoObjectViaIFrame() ||
			    NullProtoObjectViaActiveX(activeXDocument); // WSH
			  var length = enumBugKeys.length;
			  while (length--) delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
			  return NullProtoObject();
			};

			hiddenKeys$1[IE_PROTO$1] = true;

			// `Object.create` method
			// https://tc39.es/ecma262/#sec-object.create
			var objectCreate = exports('M', Object.create || function create(O, Properties) {
			  var result;
			  if (O !== null) {
			    EmptyConstructor[PROTOTYPE] = anObject(O);
			    result = new EmptyConstructor();
			    EmptyConstructor[PROTOTYPE] = null;
			    // add "__proto__" for Object.getPrototypeOf polyfill
			    result[IE_PROTO$1] = O;
			  } else result = NullProtoObject();
			  return Properties === undefined ? result : objectDefineProperties(result, Properties);
			});

			var UNSCOPABLES = wellKnownSymbol('unscopables');
			var ArrayPrototype$1 = Array.prototype;

			// Array.prototype[@@unscopables]
			// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
			if (ArrayPrototype$1[UNSCOPABLES] == undefined) {
			  objectDefineProperty.f(ArrayPrototype$1, UNSCOPABLES, {
			    configurable: true,
			    value: objectCreate(null)
			  });
			}

			// add a key to Array.prototype[@@unscopables]
			var addToUnscopables = exports('a', function (key) {
			  ArrayPrototype$1[UNSCOPABLES][key] = true;
			});

			var aFunction = exports('G', function (it) {
			  if (typeof it != 'function') {
			    throw TypeError(String(it) + ' is not a function');
			  } return it;
			});

			// optional / simple context binding
			var functionBindContext = exports('f', function (fn, that, length) {
			  aFunction(fn);
			  if (that === undefined) return fn;
			  switch (length) {
			    case 0: return function () {
			      return fn.call(that);
			    };
			    case 1: return function (a) {
			      return fn.call(that, a);
			    };
			    case 2: return function (a, b) {
			      return fn.call(that, a, b);
			    };
			    case 3: return function (a, b, c) {
			      return fn.call(that, a, b, c);
			    };
			  }
			  return function (/* ...args */) {
			    return fn.apply(that, arguments);
			  };
			});

			var TO_STRING_TAG$3 = wellKnownSymbol('toStringTag');
			var test = {};

			test[TO_STRING_TAG$3] = 'z';

			var toStringTagSupport = String(test) === '[object z]';

			var TO_STRING_TAG$2 = wellKnownSymbol('toStringTag');
			// ES3 wrong here
			var CORRECT_ARGUMENTS = classofRaw(function () { return arguments; }()) == 'Arguments';

			// fallback for IE11 Script Access Denied error
			var tryGet = function (it, key) {
			  try {
			    return it[key];
			  } catch (error) { /* empty */ }
			};

			// getting tag from ES6+ `Object.prototype.toString`
			var classof = exports('e', toStringTagSupport ? classofRaw : function (it) {
			  var O, tag, result;
			  return it === undefined ? 'Undefined' : it === null ? 'Null'
			    // @@toStringTag case
			    : typeof (tag = tryGet(O = Object(it), TO_STRING_TAG$2)) == 'string' ? tag
			    // builtinTag case
			    : CORRECT_ARGUMENTS ? classofRaw(O)
			    // ES3 arguments fallback
			    : (result = classofRaw(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : result;
			});

			var correctPrototypeGetter = !fails(function () {
			  function F() { /* empty */ }
			  F.prototype.constructor = null;
			  // eslint-disable-next-line es/no-object-getprototypeof -- required for testing
			  return Object.getPrototypeOf(new F()) !== F.prototype;
			});

			var IE_PROTO = sharedKey('IE_PROTO');
			var ObjectPrototype = Object.prototype;

			// `Object.getPrototypeOf` method
			// https://tc39.es/ecma262/#sec-object.getprototypeof
			// eslint-disable-next-line es/no-object-getprototypeof -- safe
			var objectGetPrototypeOf = exports('c', correctPrototypeGetter ? Object.getPrototypeOf : function (O) {
			  O = toObject(O);
			  if (has$2(O, IE_PROTO)) return O[IE_PROTO];
			  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
			    return O.constructor.prototype;
			  } return O instanceof Object ? ObjectPrototype : null;
			});

			var aPossiblePrototype = function (it) {
			  if (!isObject$2(it) && it !== null) {
			    throw TypeError("Can't set " + String(it) + ' as a prototype');
			  } return it;
			};

			/* eslint-disable no-proto -- safe */



			// `Object.setPrototypeOf` method
			// https://tc39.es/ecma262/#sec-object.setprototypeof
			// Works with __proto__ only. Old v8 can't work with null proto objects.
			// eslint-disable-next-line es/no-object-setprototypeof -- safe
			var objectSetPrototypeOf = exports('d', Object.setPrototypeOf || ('__proto__' in {} ? function () {
			  var CORRECT_SETTER = false;
			  var test = {};
			  var setter;
			  try {
			    // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
			    setter = Object.getOwnPropertyDescriptor(Object.prototype, '__proto__').set;
			    setter.call(test, []);
			    CORRECT_SETTER = test instanceof Array;
			  } catch (error) { /* empty */ }
			  return function setPrototypeOf(O, proto) {
			    anObject(O);
			    aPossiblePrototype(proto);
			    if (CORRECT_SETTER) setter.call(O, proto);
			    else O.__proto__ = proto;
			    return O;
			  };
			}() : undefined));

			var path = exports('q', global_1);

			var toString_1 = exports('z', function (argument) {
			  if (isSymbol(argument)) throw TypeError('Cannot convert a Symbol value to a string');
			  return String(argument);
			});

			var iterators = {};

			var ITERATOR$5 = wellKnownSymbol('iterator');
			var BUGGY_SAFARI_ITERATORS$1 = false;

			var returnThis$2 = function () { return this; };

			// `%IteratorPrototype%` object
			// https://tc39.es/ecma262/#sec-%iteratorprototype%-object
			var IteratorPrototype$2, PrototypeOfArrayIteratorPrototype, arrayIterator;

			/* eslint-disable es/no-array-prototype-keys -- safe */
			if ([].keys) {
			  arrayIterator = [].keys();
			  // Safari 8 has buggy iterators w/o `next`
			  if (!('next' in arrayIterator)) BUGGY_SAFARI_ITERATORS$1 = true;
			  else {
			    PrototypeOfArrayIteratorPrototype = objectGetPrototypeOf(objectGetPrototypeOf(arrayIterator));
			    if (PrototypeOfArrayIteratorPrototype !== Object.prototype) IteratorPrototype$2 = PrototypeOfArrayIteratorPrototype;
			  }
			}

			var NEW_ITERATOR_PROTOTYPE = IteratorPrototype$2 == undefined || fails(function () {
			  var test = {};
			  // FF44- legacy iterators case
			  return IteratorPrototype$2[ITERATOR$5].call(test) !== test;
			});

			if (NEW_ITERATOR_PROTOTYPE) IteratorPrototype$2 = {};

			// `%IteratorPrototype%[@@iterator]()` method
			// https://tc39.es/ecma262/#sec-%iteratorprototype%-@@iterator
			if (!has$2(IteratorPrototype$2, ITERATOR$5)) {
			  createNonEnumerableProperty(IteratorPrototype$2, ITERATOR$5, returnThis$2);
			}

			var iteratorsCore = {
			  IteratorPrototype: IteratorPrototype$2,
			  BUGGY_SAFARI_ITERATORS: BUGGY_SAFARI_ITERATORS$1
			};

			var defineProperty$1 = objectDefineProperty.f;



			var TO_STRING_TAG$1 = wellKnownSymbol('toStringTag');

			var setToStringTag = exports('Z', function (it, TAG, STATIC) {
			  if (it && !has$2(it = STATIC ? it : it.prototype, TO_STRING_TAG$1)) {
			    defineProperty$1(it, TO_STRING_TAG$1, { configurable: true, value: TAG });
			  }
			});

			var IteratorPrototype$1 = iteratorsCore.IteratorPrototype;





			var returnThis$1 = function () { return this; };

			var createIteratorConstructor = exports('P', function (IteratorConstructor, NAME, next) {
			  var TO_STRING_TAG = NAME + ' Iterator';
			  IteratorConstructor.prototype = objectCreate(IteratorPrototype$1, { next: createPropertyDescriptor(1, next) });
			  setToStringTag(IteratorConstructor, TO_STRING_TAG, false);
			  iterators[TO_STRING_TAG] = returnThis$1;
			  return IteratorConstructor;
			});

			var IteratorPrototype = iteratorsCore.IteratorPrototype;
			var BUGGY_SAFARI_ITERATORS = iteratorsCore.BUGGY_SAFARI_ITERATORS;
			var ITERATOR$4 = wellKnownSymbol('iterator');
			var KEYS = 'keys';
			var VALUES = 'values';
			var ENTRIES = 'entries';

			var returnThis = function () { return this; };

			var defineIterator = function (Iterable, NAME, IteratorConstructor, next, DEFAULT, IS_SET, FORCED) {
			  createIteratorConstructor(IteratorConstructor, NAME, next);

			  var getIterationMethod = function (KIND) {
			    if (KIND === DEFAULT && defaultIterator) return defaultIterator;
			    if (!BUGGY_SAFARI_ITERATORS && KIND in IterablePrototype) return IterablePrototype[KIND];
			    switch (KIND) {
			      case KEYS: return function keys() { return new IteratorConstructor(this, KIND); };
			      case VALUES: return function values() { return new IteratorConstructor(this, KIND); };
			      case ENTRIES: return function entries() { return new IteratorConstructor(this, KIND); };
			    } return function () { return new IteratorConstructor(this); };
			  };

			  var TO_STRING_TAG = NAME + ' Iterator';
			  var INCORRECT_VALUES_NAME = false;
			  var IterablePrototype = Iterable.prototype;
			  var nativeIterator = IterablePrototype[ITERATOR$4]
			    || IterablePrototype['@@iterator']
			    || DEFAULT && IterablePrototype[DEFAULT];
			  var defaultIterator = !BUGGY_SAFARI_ITERATORS && nativeIterator || getIterationMethod(DEFAULT);
			  var anyNativeIterator = NAME == 'Array' ? IterablePrototype.entries || nativeIterator : nativeIterator;
			  var CurrentIteratorPrototype, methods, KEY;

			  // fix native
			  if (anyNativeIterator) {
			    CurrentIteratorPrototype = objectGetPrototypeOf(anyNativeIterator.call(new Iterable()));
			    if (IteratorPrototype !== Object.prototype && CurrentIteratorPrototype.next) {
			      if (objectGetPrototypeOf(CurrentIteratorPrototype) !== IteratorPrototype) {
			        if (objectSetPrototypeOf) {
			          objectSetPrototypeOf(CurrentIteratorPrototype, IteratorPrototype);
			        } else if (typeof CurrentIteratorPrototype[ITERATOR$4] != 'function') {
			          createNonEnumerableProperty(CurrentIteratorPrototype, ITERATOR$4, returnThis);
			        }
			      }
			      // Set @@toStringTag to native iterators
			      setToStringTag(CurrentIteratorPrototype, TO_STRING_TAG, true);
			    }
			  }

			  // fix Array.prototype.{ values, @@iterator }.name in V8 / FF
			  if (DEFAULT == VALUES && nativeIterator && nativeIterator.name !== VALUES) {
			    INCORRECT_VALUES_NAME = true;
			    defaultIterator = function values() { return nativeIterator.call(this); };
			  }

			  // define iterator
			  if (IterablePrototype[ITERATOR$4] !== defaultIterator) {
			    createNonEnumerableProperty(IterablePrototype, ITERATOR$4, defaultIterator);
			  }
			  iterators[NAME] = defaultIterator;

			  // export additional methods
			  if (DEFAULT) {
			    methods = {
			      values: getIterationMethod(VALUES),
			      keys: IS_SET ? defaultIterator : getIterationMethod(KEYS),
			      entries: getIterationMethod(ENTRIES)
			    };
			    if (FORCED) for (KEY in methods) {
			      if (BUGGY_SAFARI_ITERATORS || INCORRECT_VALUES_NAME || !(KEY in IterablePrototype)) {
			        redefine(IterablePrototype, KEY, methods[KEY]);
			      }
			    } else _export({ target: NAME, proto: true, forced: BUGGY_SAFARI_ITERATORS || INCORRECT_VALUES_NAME }, methods);
			  }

			  return methods;
			};

			var ARRAY_ITERATOR = 'Array Iterator';
			var setInternalState$2 = internalState.set;
			var getInternalState$2 = internalState.getterFor(ARRAY_ITERATOR);

			// `Array.prototype.entries` method
			// https://tc39.es/ecma262/#sec-array.prototype.entries
			// `Array.prototype.keys` method
			// https://tc39.es/ecma262/#sec-array.prototype.keys
			// `Array.prototype.values` method
			// https://tc39.es/ecma262/#sec-array.prototype.values
			// `Array.prototype[@@iterator]` method
			// https://tc39.es/ecma262/#sec-array.prototype-@@iterator
			// `CreateArrayIterator` internal method
			// https://tc39.es/ecma262/#sec-createarrayiterator
			var es_array_iterator = defineIterator(Array, 'Array', function (iterated, kind) {
			  setInternalState$2(this, {
			    type: ARRAY_ITERATOR,
			    target: toIndexedObject(iterated), // target
			    index: 0,                          // next index
			    kind: kind                         // kind
			  });
			// `%ArrayIteratorPrototype%.next` method
			// https://tc39.es/ecma262/#sec-%arrayiteratorprototype%.next
			}, function () {
			  var state = getInternalState$2(this);
			  var target = state.target;
			  var kind = state.kind;
			  var index = state.index++;
			  if (!target || index >= target.length) {
			    state.target = undefined;
			    return { value: undefined, done: true };
			  }
			  if (kind == 'keys') return { value: index, done: false };
			  if (kind == 'values') return { value: target[index], done: false };
			  return { value: [index, target[index]], done: false };
			}, 'values');

			// argumentsList[@@iterator] is %ArrayProto_values%
			// https://tc39.es/ecma262/#sec-createunmappedargumentsobject
			// https://tc39.es/ecma262/#sec-createmappedargumentsobject
			iterators.Arguments = iterators.Array;

			// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
			addToUnscopables('keys');
			addToUnscopables('values');
			addToUnscopables('entries');

			var ITERATOR$3 = wellKnownSymbol('iterator');
			var ArrayPrototype = Array.prototype;

			// check on default Array iterator
			var isArrayIteratorMethod = exports('W', function (it) {
			  return it !== undefined && (iterators.Array === it || ArrayPrototype[ITERATOR$3] === it);
			});

			var ITERATOR$2 = wellKnownSymbol('iterator');

			var getIteratorMethod = exports('V', function (it) {
			  if (it != undefined) return it[ITERATOR$2]
			    || it['@@iterator']
			    || iterators[classof(it)];
			});

			var iteratorClose = exports('U', function (iterator) {
			  var returnMethod = iterator['return'];
			  if (returnMethod !== undefined) {
			    return anObject(returnMethod.call(iterator)).value;
			  }
			});

			var Result = function (stopped, result) {
			  this.stopped = stopped;
			  this.result = result;
			};

			var iterate = exports('H', function (iterable, unboundFunction, options) {
			  var that = options && options.that;
			  var AS_ENTRIES = !!(options && options.AS_ENTRIES);
			  var IS_ITERATOR = !!(options && options.IS_ITERATOR);
			  var INTERRUPTED = !!(options && options.INTERRUPTED);
			  var fn = functionBindContext(unboundFunction, that, 1 + AS_ENTRIES + INTERRUPTED);
			  var iterator, iterFn, index, length, result, next, step;

			  var stop = function (condition) {
			    if (iterator) iteratorClose(iterator);
			    return new Result(true, condition);
			  };

			  var callFn = function (value) {
			    if (AS_ENTRIES) {
			      anObject(value);
			      return INTERRUPTED ? fn(value[0], value[1], stop) : fn(value[0], value[1]);
			    } return INTERRUPTED ? fn(value, stop) : fn(value);
			  };

			  if (IS_ITERATOR) {
			    iterator = iterable;
			  } else {
			    iterFn = getIteratorMethod(iterable);
			    if (typeof iterFn != 'function') throw TypeError('Target is not iterable');
			    // optimisation for array iterators
			    if (isArrayIteratorMethod(iterFn)) {
			      for (index = 0, length = toLength(iterable.length); length > index; index++) {
			        result = callFn(iterable[index]);
			        if (result && result instanceof Result) return result;
			      } return new Result(false);
			    }
			    iterator = iterFn.call(iterable);
			  }

			  next = iterator.next;
			  while (!(step = next.call(iterator)).done) {
			    try {
			      result = callFn(step.value);
			    } catch (error) {
			      iteratorClose(iterator);
			      throw error;
			    }
			    if (typeof result == 'object' && result && result instanceof Result) return result;
			  } return new Result(false);
			});

			// `Object.prototype.toString` method implementation
			// https://tc39.es/ecma262/#sec-object.prototype.tostring
			var objectToString$1 = toStringTagSupport ? {}.toString : function toString() {
			  return '[object ' + classof(this) + ']';
			};

			// `Object.prototype.toString` method
			// https://tc39.es/ecma262/#sec-object.prototype.tostring
			if (!toStringTagSupport) {
			  redefine(Object.prototype, 'toString', objectToString$1, { unsafe: true });
			}

			var SPECIES$2 = wellKnownSymbol('species');

			// `SpeciesConstructor` abstract operation
			// https://tc39.es/ecma262/#sec-speciesconstructor
			var speciesConstructor = exports('Q', function (O, defaultConstructor) {
			  var C = anObject(O).constructor;
			  var S;
			  return C === undefined || (S = anObject(C)[SPECIES$2]) == undefined ? defaultConstructor : aFunction(S);
			});

			// `String.prototype.codePointAt` methods implementation
			var createMethod = function (CONVERT_TO_STRING) {
			  return function ($this, pos) {
			    var S = toString_1(requireObjectCoercible($this));
			    var position = toInteger(pos);
			    var size = S.length;
			    var first, second;
			    if (position < 0 || position >= size) return CONVERT_TO_STRING ? '' : undefined;
			    first = S.charCodeAt(position);
			    return first < 0xD800 || first > 0xDBFF || position + 1 === size
			      || (second = S.charCodeAt(position + 1)) < 0xDC00 || second > 0xDFFF
			        ? CONVERT_TO_STRING ? S.charAt(position) : first
			        : CONVERT_TO_STRING ? S.slice(position, position + 2) : (first - 0xD800 << 10) + (second - 0xDC00) + 0x10000;
			  };
			};

			var stringMultibyte = exports('O', {
			  // `String.prototype.codePointAt` method
			  // https://tc39.es/ecma262/#sec-string.prototype.codepointat
			  codeAt: createMethod(false),
			  // `String.prototype.at` method
			  // https://github.com/mathiasbynens/String.prototype.at
			  charAt: createMethod(true)
			});

			var toStr$2 = Object.prototype.toString;

			var isArguments = function isArguments(value) {
				var str = toStr$2.call(value);
				var isArgs = str === '[object Arguments]';
				if (!isArgs) {
					isArgs = str !== '[object Array]' &&
						value !== null &&
						typeof value === 'object' &&
						typeof value.length === 'number' &&
						value.length >= 0 &&
						toStr$2.call(value.callee) === '[object Function]';
				}
				return isArgs;
			};

			var keysShim$1;
			if (!Object.keys) {
				// modified from https://github.com/es-shims/es5-shim
				var has = Object.prototype.hasOwnProperty;
				var toStr$1 = Object.prototype.toString;
				var isArgs = isArguments; // eslint-disable-line global-require
				var isEnumerable = Object.prototype.propertyIsEnumerable;
				var hasDontEnumBug = !isEnumerable.call({ toString: null }, 'toString');
				var hasProtoEnumBug = isEnumerable.call(function () {}, 'prototype');
				var dontEnums = [
					'toString',
					'toLocaleString',
					'valueOf',
					'hasOwnProperty',
					'isPrototypeOf',
					'propertyIsEnumerable',
					'constructor'
				];
				var equalsConstructorPrototype = function (o) {
					var ctor = o.constructor;
					return ctor && ctor.prototype === o;
				};
				var excludedKeys = {
					$applicationCache: true,
					$console: true,
					$external: true,
					$frame: true,
					$frameElement: true,
					$frames: true,
					$innerHeight: true,
					$innerWidth: true,
					$onmozfullscreenchange: true,
					$onmozfullscreenerror: true,
					$outerHeight: true,
					$outerWidth: true,
					$pageXOffset: true,
					$pageYOffset: true,
					$parent: true,
					$scrollLeft: true,
					$scrollTop: true,
					$scrollX: true,
					$scrollY: true,
					$self: true,
					$webkitIndexedDB: true,
					$webkitStorageInfo: true,
					$window: true
				};
				var hasAutomationEqualityBug = (function () {
					/* global window */
					if (typeof window === 'undefined') { return false; }
					for (var k in window) {
						try {
							if (!excludedKeys['$' + k] && has.call(window, k) && window[k] !== null && typeof window[k] === 'object') {
								try {
									equalsConstructorPrototype(window[k]);
								} catch (e) {
									return true;
								}
							}
						} catch (e) {
							return true;
						}
					}
					return false;
				}());
				var equalsConstructorPrototypeIfNotBuggy = function (o) {
					/* global window */
					if (typeof window === 'undefined' || !hasAutomationEqualityBug) {
						return equalsConstructorPrototype(o);
					}
					try {
						return equalsConstructorPrototype(o);
					} catch (e) {
						return false;
					}
				};

				keysShim$1 = function keys(object) {
					var isObject = object !== null && typeof object === 'object';
					var isFunction = toStr$1.call(object) === '[object Function]';
					var isArguments = isArgs(object);
					var isString = isObject && toStr$1.call(object) === '[object String]';
					var theKeys = [];

					if (!isObject && !isFunction && !isArguments) {
						throw new TypeError('Object.keys called on a non-object');
					}

					var skipProto = hasProtoEnumBug && isFunction;
					if (isString && object.length > 0 && !has.call(object, 0)) {
						for (var i = 0; i < object.length; ++i) {
							theKeys.push(String(i));
						}
					}

					if (isArguments && object.length > 0) {
						for (var j = 0; j < object.length; ++j) {
							theKeys.push(String(j));
						}
					} else {
						for (var name in object) {
							if (!(skipProto && name === 'prototype') && has.call(object, name)) {
								theKeys.push(String(name));
							}
						}
					}

					if (hasDontEnumBug) {
						var skipConstructor = equalsConstructorPrototypeIfNotBuggy(object);

						for (var k = 0; k < dontEnums.length; ++k) {
							if (!(skipConstructor && dontEnums[k] === 'constructor') && has.call(object, dontEnums[k])) {
								theKeys.push(dontEnums[k]);
							}
						}
					}
					return theKeys;
				};
			}
			var implementation = keysShim$1;

			var slice = Array.prototype.slice;


			var origKeys = Object.keys;
			var keysShim = origKeys ? function keys(o) { return origKeys(o); } : implementation;

			var originalKeys = Object.keys;

			keysShim.shim = function shimObjectKeys() {
				if (Object.keys) {
					var keysWorksWithArguments = (function () {
						// Safari 5.0 bug
						var args = Object.keys(arguments);
						return args && args.length === arguments.length;
					}(1, 2));
					if (!keysWorksWithArguments) {
						Object.keys = function keys(object) { // eslint-disable-line func-name-matching
							if (isArguments(object)) {
								return originalKeys(slice.call(object));
							}
							return originalKeys(object);
						};
					}
				} else {
					Object.keys = keysShim;
				}
				return Object.keys || keysShim;
			};

			var objectKeys = keysShim;

			var hasSymbols = typeof Symbol === 'function' && typeof Symbol('foo') === 'symbol';

			var toStr = Object.prototype.toString;
			var concat = Array.prototype.concat;
			var origDefineProperty = Object.defineProperty;

			var isFunction$2 = function (fn) {
				return typeof fn === 'function' && toStr.call(fn) === '[object Function]';
			};

			var arePropertyDescriptorsSupported = function () {
				var obj = {};
				try {
					origDefineProperty(obj, 'x', { enumerable: false, value: obj });
					// eslint-disable-next-line no-unused-vars, no-restricted-syntax
					for (var _ in obj) { // jscs:ignore disallowUnusedVariables
						return false;
					}
					return obj.x === obj;
				} catch (e) { /* this is IE 8. */
					return false;
				}
			};
			var supportsDescriptors = origDefineProperty && arePropertyDescriptorsSupported();

			var defineProperty = function (object, name, value, predicate) {
				if (name in object && (!isFunction$2(predicate) || !predicate())) {
					return;
				}
				if (supportsDescriptors) {
					origDefineProperty(object, name, {
						configurable: true,
						enumerable: false,
						value: value,
						writable: true
					});
				} else {
					object[name] = value;
				}
			};

			var defineProperties = function (object, map) {
				var predicates = arguments.length > 2 ? arguments[2] : {};
				var props = objectKeys(map);
				if (hasSymbols) {
					props = concat.call(props, Object.getOwnPropertySymbols(map));
				}
				for (var i = 0; i < props.length; i += 1) {
					defineProperty(object, props[i], map[props[i]], predicates[props[i]]);
				}
			};

			defineProperties.supportsDescriptors = !!supportsDescriptors;

			var defineProperties_1 = defineProperties;

			var implementation_browser = createCommonjsModule(function (module) {

			if (typeof self !== 'undefined') {
				module.exports = self;
			} else if (typeof window !== 'undefined') {
				module.exports = window;
			} else {
				module.exports = Function('return this')();
			}
			});

			var polyfill$1 = function getPolyfill() {
				if (typeof commonjsGlobal !== 'object' || !commonjsGlobal || commonjsGlobal.Math !== Math || commonjsGlobal.Array !== Array) {
					return implementation_browser;
				}
				return commonjsGlobal;
			};

			var shim = function shimGlobal() {
				var polyfill = polyfill$1();
				if (defineProperties_1.supportsDescriptors) {
					var descriptor = Object.getOwnPropertyDescriptor(polyfill, 'globalThis');
					if (!descriptor || (descriptor.configurable && (descriptor.enumerable || descriptor.writable || globalThis !== polyfill))) { // eslint-disable-line max-len
						Object.defineProperty(polyfill, 'globalThis', {
							configurable: true,
							enumerable: false,
							value: polyfill,
							writable: false
						});
					}
				} else if (typeof globalThis !== 'object' || globalThis !== polyfill) {
					polyfill.globalThis = polyfill;
				}
				return polyfill;
			};

			var polyfill = polyfill$1();

			var getGlobal$1 = function () { return polyfill; };

			defineProperties_1(getGlobal$1, {
				getPolyfill: polyfill$1,
				implementation: implementation_browser,
				shim: shim
			});

			var globalthis = getGlobal$1;

			const theGlobalThis = globalthis();
			function getGlobalThis() {
			    return theGlobalThis;
			}
			let _global = getGlobalThis();
			if (!_global.process) {
			    _global.process = {
			        env: {}
			    };
			}
			if (!_global.frameworks) {
			    _global.frameworks = {};
			}
			Object.assign(_global.process.env, {
			    NODE_ENV: 'production'
			});
			function getGlobal() {
			    return _global;
			}

			var charAt = stringMultibyte.charAt;




			var STRING_ITERATOR = 'String Iterator';
			var setInternalState$1 = internalState.set;
			var getInternalState$1 = internalState.getterFor(STRING_ITERATOR);

			// `String.prototype[@@iterator]` method
			// https://tc39.es/ecma262/#sec-string.prototype-@@iterator
			defineIterator(String, 'String', function (iterated) {
			  setInternalState$1(this, {
			    type: STRING_ITERATOR,
			    string: toString_1(iterated),
			    index: 0
			  });
			// `%StringIteratorPrototype%.next` method
			// https://tc39.es/ecma262/#sec-%stringiteratorprototype%.next
			}, function next() {
			  var state = getInternalState$1(this);
			  var string = state.string;
			  var index = state.index;
			  var point;
			  if (index >= string.length) return { value: undefined, done: true };
			  point = charAt(string, index);
			  state.index += point.length;
			  return { value: point, done: false };
			});

			var anInstance = exports('$', function (it, Constructor, name) {
			  if (!(it instanceof Constructor)) {
			    throw TypeError('Incorrect ' + (name ? name + ' ' : '') + 'invocation');
			  } return it;
			});

			var redefineAll = exports('Y', function (target, src, options) {
			  for (var key in src) redefine(target, key, src[key], options);
			  return target;
			});

			function isUndefined(val) {
			    return typeof val === 'undefined';
			}
			function isObject$1(val) {
			    return Object.prototype.toString.call(val) === '[object Object]';
			}
			function isArray(val) {
			    return Object.prototype.toString.call(val) === '[object Array]';
			}
			function isString(val) {
			    return Object.prototype.toString.call(val) === '[object String]';
			}
			function isNumber(val) {
			    return Object.prototype.toString.call(val) === '[object Number]';
			}
			function isFunction$1(val) {
			    return Object.prototype.toString.call(val) === '[object Function]';
			}
			function isNonEmptyArray(arr) {
			    return arr.length > 0;
			}

			function logParams(method, ...args) {
			    console[method](args
			        .map((arg) => {
			        if (isObject$1(arg) || isArray(arg)) {
			            return JSON.stringify(arg);
			        }
			        else {
			            return arg;
			        }
			    })
			        .join(' '));
			}
			class BaseLogger {
			    constructor(tag) {
			        this.tag = 'base';
			        this.tag = tag;
			    }
			    log(...args) {
			        logParams('log', [this.tag], args);
			    }
			    info(...args) {
			        logParams('info', [this.tag], args);
			    }
			    warn(...args) {
			        logParams('warn', [this.tag], args);
			    }
			    error(...args) {
			        logParams('error', [this.tag], args);
			    }
			    debug(...args) {
			        logParams('debug', [this.tag], args);
			    }
			    timeoutInfo(timeout, ...args) {
			        setTimeout(() => {
			            logParams('info', [this.tag], args);
			        }, timeout);
			    }
			}
			const runtimeLogger = exports('a1', new BaseLogger('runtime'));
			new BaseLogger('bridge');
			const developLogger = exports('ac', new BaseLogger('develop'));

			const userGlobalBlackList = ['runInInstance', 'createInstance', 'destroyInstance', 'callJS', 'register', 'setUp', 'liteAppVDom', 'reporter', 'setRuntimeConfig', 'baseLibApi'];
			const codeTemplatePrefix = exports('am', '__runner_');

			var ParamType;
			(function (ParamType) {
			    ParamType["string"] = "string";
			    ParamType["number"] = "number";
			    ParamType["boolean"] = "boolean";
			    ParamType["json"] = "json";
			    ParamType["object"] = "object";
			    ParamType["callback"] = "callback";
			    ParamType["raw"] = "raw";
			})(ParamType || (ParamType = {}));
			var ReturnType;
			(function (ReturnType) {
			    ReturnType["raw"] = "raw";
			    ReturnType["json"] = "json";
			    ReturnType["promise"] = "promise";
			    ReturnType["string"] = "string";
			})(ReturnType || (ReturnType = {}));
			const ParamDefaultValueMap = {
			    [ParamType.string]: '',
			    [ParamType.number]: 0,
			    [ParamType.boolean]: false,
			    [ParamType.object]: undefined,
			    [ParamType.callback]: -1,
			    [ParamType.json]: '{}',
			    [ParamType.raw]: undefined,
			};
			function isObjectMethodParam(paramDefinition) {
			    return paramDefinition.type === ParamType.object;
			}
			var RegisterType;
			(function (RegisterType) {
			    RegisterType["module"] = "module";
			    RegisterType["component"] = "component";
			})(RegisterType || (RegisterType = {}));
			class Register {
			    constructor() {
			        this.modulesInfo = {};
			        this.componentsInfo = {};
			    }
			    static getInstance() {
			        if (!Register.instance) {
			            Register.instance = new Register();
			        }
			        return Register.instance;
			    }
			    get publicModuleNames() {
			        let result = [];
			        for (const [key, module] of Object.entries(this.modulesInfo)) {
			            if (!module.private) {
			                result.push(key);
			            }
			        }
			        return result;
			    }
			    register(packets) {
			        for (const packet of packets) {
			            switch (packet.type) {
			                case RegisterType.module:
			                    this.registerModules(packet.info);
			                    break;
			                case RegisterType.component:
			                    this.registerComponents(packet.info);
			                    break;
			            }
			        }
			    }
			    registerComponents(componentsInfo) {
			        for (let key in componentsInfo) {
			            if (componentsInfo.hasOwnProperty(key)) {
			                this.componentsInfo[key] = componentsInfo[key];
			            }
			        }
			    }
			    registerModules(modulesInfo) {
			        for (let key in modulesInfo) {
			            if (modulesInfo.hasOwnProperty(key)) {
			                const moduleInfo = modulesInfo[key];
			                const moduleBridge = moduleInfo.bridge;
			                this.modulesInfo[key] = moduleInfo;
			                if (moduleBridge.type === 'global') {
			                    if (userGlobalBlackList.indexOf(moduleBridge.name) < 0) {
			                        userGlobalBlackList.push(moduleBridge.name);
			                    }
			                }
			            }
			        }
			    }
			} exports('ab', Register);

			var ApiType; exports('ad', ApiType);
			(function (ApiType) {
			    ApiType["dom"] = "dom";
			    ApiType["domMethod"] = "domMethod";
			    ApiType["global"] = "global";
			    ApiType["dynamic"] = "dynamic";
			    ApiType["component"] = "component";
			})(ApiType || (exports('ad', ApiType = {})));
			class ApiCenter {
			    constructor(config) {
			        this.callBuffer = [];
			        this.isReady = false;
			        this.isDestroy = false;
			        this.callbackManager = config.callbackManager;
			        this.instance = config.instance;
			        this.startUp();
			    }
			    startUp() {
			        if (this.instance.isReady) {
			            this.isReady = true;
			            this.Promise = this.instance.injectContext.Promise;
			            this.callBuffer.forEach((task) => {
			                this.callApi(task.apiType, task.params);
			            });
			        }
			    }
			    destroy() {
			        this.isDestroy = true;
			    }
			    callApi(apiType, params) {
			        if (this.isDestroy)
			            return;
			        if (!this.isReady) {
			            this.callBuffer.push({
			                apiType,
			                params,
			            });
			            return;
			        }
			        return this.taskExecution(apiType, params);
			    }
			    taskExecution(apiType, params) {
			        if (apiType === ApiType.dynamic) {
			            let callParams = params;
			            let globalObj = getGlobal();
			            return this.commonCallMethod(globalObj, globalObj.callDynamicModule, callParams, [callParams.moduleName, callParams.method], true);
			        }
			        else if (apiType === ApiType.global) {
			            let callParams = params;
			            return this.callGlobalMethod(callParams);
			        }
			        else ;
			    }
			    serializeArgument(arg) {
			        switch (typeof arg) {
			            case 'object':
			                if (arg instanceof Array) {
			                    return this.serializeArgumentArray(arg);
			                }
			                else {
			                    let newObj = {};
			                    for (let key in arg) {
			                        if (typeof arg[key] !== 'undefined') {
			                            newObj[key] = this.serializeArgument(arg[key]);
			                        }
			                    }
			                    return newObj;
			                }
			            case 'function':
			                return this.callbackManager.add(arg);
			            default:
			                return arg;
			        }
			    }
			    serializeArgumentArray(args) {
			        const result = [];
			        for (let item of args) {
			            result.push(this.serializeArgument(item));
			        }
			        return result;
			    }
			    serializeArgumentArrayWithDefinition(args, paramsDefinitions) {
			        const result = [];
			        paramsDefinitions.forEach((definition, index) => {
			            const argItem = args[index];
			            result.push(this.serializeArgumentWithDefinition(argItem, definition, index.toString()));
			        });
			        return result;
			    }
			    serializeArgumentWithDefinition(arg, definition, debugInfo) {
			        if (isUndefined(arg)) {
			            if (!isUndefined(definition.defaultValue)) {
			                return definition.defaultValue;
			            }
			            if (definition.optional) {
			                return ParamDefaultValueMap[definition.type];
			            }
			            throw new Error(`缺少参数 ${debugInfo}`);
			        }
			        else {
			            if (isObjectMethodParam(definition)) {
			                if (definition.props) {
			                    return this.serializeArgumentObjectWithDefinition(arg, definition.props);
			                }
			                else {
			                    return arg;
			                }
			            }
			            else {
			                switch (definition.type) {
			                    case ParamType.callback:
			                        return this.callbackManager.add(arg);
			                    case ParamType.json:
			                        return JSON.stringify(arg);
			                    default:
			                        return arg;
			                }
			            }
			        }
			    }
			    serializeArgumentObjectWithDefinition(argMap, paramsDefinitionMap) {
			        const result = {};
			        for (const key in paramsDefinitionMap) {
			            let arg = argMap[key];
			            result[key] = this.serializeArgumentWithDefinition(arg, paramsDefinitionMap[key], key);
			        }
			        return result;
			    }
			    argumentToStringArray(args) {
			        for (let i = 0; i < args.length; i++) {
			            let item = args[i];
			            if (!item) {
			                args[i] = '';
			            }
			            else if (isObject$1(item)) {
			                args[i] = JSON.stringify(item);
			            }
			            else {
			                args[i] = item.toString();
			            }
			        }
			        return args;
			    }
			    commonCallMethod(methodHost, methodInstance, params, prefixArgs = [], stringProtocol = false) {
			        var _a, _b;
			        let sourceArgs = params.args || [];
			        let args = sourceArgs;
			        const paramsDefinitions = ((_a = params.methodInfo) === null || _a === void 0 ? void 0 : _a.params) || [];
			        if (params.methodInfo) {
			            if (args.length > paramsDefinitions.length) ;
			            args = this.serializeArgumentArrayWithDefinition(sourceArgs, paramsDefinitions);
			        }
			        if (stringProtocol) {
			            args = [this.argumentToStringArray(args)];
			        }
			        args = prefixArgs === null || prefixArgs === void 0 ? void 0 : prefixArgs.concat(args);
			        let resultDefinition = (_b = params.methodInfo) === null || _b === void 0 ? void 0 : _b.result;
			        if (resultDefinition && resultDefinition.type === ReturnType.promise) {
			            let callback;
			            if (sourceArgs.length > paramsDefinitions.length && isFunction$1(sourceArgs[paramsDefinitions.length])) {
			                callback = sourceArgs[paramsDefinitions.length];
			            }
			            if (callback) {
			                let callbackId = this.callbackManager.add(callback);
			                args.push(callbackId);
			                args.unshift(this.instance.id);
			                return methodInstance.apply(methodHost, args);
			            }
			            else {
			                return new this.Promise((resolve, reject) => {
			                    let callbackId = this.callbackManager.add((err, result) => {
			                        if (err) {
			                            reject(err);
			                        }
			                        else {
			                            resolve(result);
			                        }
			                    });
			                    args.push(callbackId);
			                    args.unshift(this.instance.id);
			                    return methodInstance.apply(methodHost, args);
			                });
			            }
			        }
			        else {
			            args.unshift(this.instance.id);
			            let methodResult = methodInstance.apply(methodHost, args);
			            if (resultDefinition) {
			                if (resultDefinition.type === ReturnType.json) {
			                    methodResult = JSON.parse(methodResult);
			                }
			            }
			            return methodResult;
			        }
			    }
			    callGlobalMethod(params) {
			        const globalBridge = getGlobal()[params.globalKey];
			        if (!globalBridge)
			            throw new Error(`全局对象 ${params.globalKey} 不存在`);
			        if (!globalBridge[params.method]) {
			            throw new Error(`全局对象 ${params.globalKey} 的方法 ${params.method} 不存在`);
			        }
			        return this.commonCallMethod(globalBridge, globalBridge[params.method], params);
			    }
			} exports('ag', ApiCenter);

			function isInObject(target, value) {
			    return (Object.keys(target)
			        .map((key) => {
			        return target[key];
			    })
			        .findIndex((item) => {
			        return item === value;
			    }) >= 0);
			}
			const qs = exports('av', {
			    stringify(obj) {
			        let result = '';
			        for (const key in obj) {
			            result = result + '&' + key + '=' + (isUndefined(obj[key]) ? '' : obj[key].toString());
			        }
			        return result.slice(1);
			    },
			    parse(str) {
			        if (!str) {
			            return {};
			        }
			        const pairs = str.split('&');
			        const result = {};
			        for (const pair of pairs) {
			            let [key, value] = pair.split('=');
			            result[key] = value;
			        }
			        return result;
			    },
			});

			var PageViewEventType;
			(function (PageViewEventType) {
			    PageViewEventType["routeEnter"] = "routeEnter";
			    PageViewEventType["load"] = "load";
			    PageViewEventType["ready"] = "ready";
			    PageViewEventType["show"] = "show";
			    PageViewEventType["hide"] = "hide";
			    PageViewEventType["unload"] = "unload";
			    PageViewEventType["reachBottom"] = "reachBottom";
			    PageViewEventType["error"] = "error";
			})(PageViewEventType || (PageViewEventType = {}));
			var StoreEventType;
			(function (StoreEventType) {
			    StoreEventType["load"] = "load";
			    StoreEventType["unload"] = "unload";
			    StoreEventType["viewVisibilityChange"] = "viewVisibilityChange";
			    StoreEventType["viewEnter"] = "viewEnter";
			    StoreEventType["viewLeave"] = "viewLeave";
			    StoreEventType["pageEnter"] = "pageEnter";
			    StoreEventType["pageLeave"] = "pageLeave";
			    StoreEventType["pagePreload"] = "pagePreload";
			})(StoreEventType || (StoreEventType = {}));
			var ConnectEventType; exports('aw', ConnectEventType);
			(function (ConnectEventType) {
			    ConnectEventType["dispatch"] = "connect.dispatch";
			    ConnectEventType["subscribe"] = "connect.subscribe";
			    ConnectEventType["unsubscribe"] = "connect.unsubscribe";
			    ConnectEventType["data"] = "connect.data";
			})(ConnectEventType || (exports('aw', ConnectEventType = {})));
			var AppShareEventType;
			(function (AppShareEventType) {
			    AppShareEventType["share"] = "app.shareMessage";
			})(AppShareEventType || (AppShareEventType = {}));
			class EventManagerClass {
			    constructor(instance, option) {
			        this.event = {};
			        this.skipDeferEvent = {};
			        this.deferDispatchList = [];
			        this.defer = false;
			        this.dispatchBacktrackingHistory = [];
			        this.baseLibApi = instance.requirePrivateModule('baseLibApi');
			        if (option) {
			            this.defer = option.defer;
			        }
			    }
			    addEventListener(type, listener, skipDefer = false) {
			        if (this.actionInject) {
			            this.actionInject(type);
			        }
			        let eventList = this.event[type];
			        if (!eventList) {
			            eventList = this.event[type] = [];
			        }
			        listener.skipDefer = skipDefer;
			        eventList.push(listener);
			        if (eventList.length === 1) {
			            this.baseLibApi.subscribeEvent(type);
			        }
			        this.flushBacktrackingEvent(type, listener);
			    }
			    removeEventListener(type, listener) {
			        const eventList = this.event[type];
			        if (!eventList || !eventList.length) {
			            return;
			        }
			        if (listener) {
			            const foundIndex = eventList.findIndex((item) => {
			                return item === listener;
			            });
			            if (foundIndex >= 0) {
			                eventList.splice(foundIndex, 1);
			            }
			        }
			        else {
			            eventList.splice(0, eventList.length);
			        }
			        if (eventList.length === 0) {
			            this.baseLibApi.unSubscribeEvent(type);
			        }
			    }
			    flushDeferEvent() {
			        this.defer = false;
			        for (const event of this.deferDispatchList) {
			            this.dispatchEvent(event.type, event.args);
			        }
			    }
			    dispatchEvent(type, args, options = {}) {
			        if (this.defer) {
			            this.deferDispatchList.push({
			                type,
			                args,
			            });
			        }
			        if (!isKnowEvent(type)) ;
			        const eventList = this.event[type];
			        if (!this.defer && options.backtracking) {
			            this.dispatchBacktrackingHistory.push({
			                type,
			                args,
			                backtracking: true,
			            });
			        }
			        if (eventList) {
			            const cloneList = [...eventList];
			            for (const listener of cloneList) {
			                if (!this.defer) {
			                    listener(...args);
			                }
			                else {
			                    if (listener.skipDefer) {
			                        listener(...args);
			                        this.removeEventListener(type, listener);
			                    }
			                }
			            }
			        }
			    }
			    destroy() {
			        this.event = {};
			    }
			    flushBacktrackingEvent(type, listener) {
			        setTimeout(() => {
			            this.dispatchBacktrackingHistory.forEach((item) => {
			                if (item.type === type) {
			                    listener(...item.args);
			                }
			            });
			        }, 1);
			    }
			} exports('ak', EventManagerClass);
			function isKnowEvent(eventType) {
			    return eventType in PageViewEventType || eventType in StoreEventType || isInObject(ConnectEventType, eventType);
			}

			const loadLibDefind = {
			    globalKey: 'base',
			    method: 'loadLib',
			    methodInfo: {
			        name: 'loadLib',
			        params: [
			            {
			                type: ParamType.string
			            },
			            {
			                type: ParamType.callback
			            }
			        ]
			    }
			};
			class BaseLibModuleClass {
			    constructor(instance) {
			        this.instance = instance;
			    }
			    loadLib(moduleName, callback) {
			        return this.instance.apiCenter.callApi(ApiType.global, Object.assign(Object.assign({}, loadLibDefind), { args: [moduleName, callback] }));
			    }
			}
			function baseLibModuleBuilder(instance) {
			    return new BaseLibModuleClass(instance);
			}

			getGlobalThis().Promise;
			getGlobalThis().Promise = {};

			var $AggregateError = function AggregateError(errors, message) {
			  var that = this;
			  if (!(that instanceof $AggregateError)) return new $AggregateError(errors, message);
			  if (objectSetPrototypeOf) {
			    // eslint-disable-next-line unicorn/error-message -- expected
			    that = objectSetPrototypeOf(new Error(undefined), objectGetPrototypeOf(that));
			  }
			  if (message !== undefined) createNonEnumerableProperty(that, 'message', toString_1(message));
			  var errorsArray = [];
			  iterate(errors, errorsArray.push, { that: errorsArray });
			  createNonEnumerableProperty(that, 'errors', errorsArray);
			  return that;
			};

			$AggregateError.prototype = objectCreate(Error.prototype, {
			  constructor: createPropertyDescriptor(5, $AggregateError),
			  message: createPropertyDescriptor(5, ''),
			  name: createPropertyDescriptor(5, 'AggregateError')
			});

			// `AggregateError` constructor
			// https://tc39.es/ecma262/#sec-aggregate-error-constructor
			_export({ global: true }, {
			  AggregateError: $AggregateError
			});

			var nativePromiseConstructor = global_1.Promise;

			var SPECIES$1 = wellKnownSymbol('species');

			var setSpecies = function (CONSTRUCTOR_NAME) {
			  var Constructor = getBuiltIn(CONSTRUCTOR_NAME);
			  var defineProperty = objectDefineProperty.f;

			  if (descriptors && Constructor && !Constructor[SPECIES$1]) {
			    defineProperty(Constructor, SPECIES$1, {
			      configurable: true,
			      get: function () { return this; }
			    });
			  }
			};

			var ITERATOR$1 = wellKnownSymbol('iterator');
			var SAFE_CLOSING = false;

			try {
			  var called = 0;
			  var iteratorWithReturn = {
			    next: function () {
			      return { done: !!called++ };
			    },
			    'return': function () {
			      SAFE_CLOSING = true;
			    }
			  };
			  iteratorWithReturn[ITERATOR$1] = function () {
			    return this;
			  };
			  // eslint-disable-next-line es/no-array-from, no-throw-literal -- required for testing
			  Array.from(iteratorWithReturn, function () { throw 2; });
			} catch (error) { /* empty */ }

			var checkCorrectnessOfIteration = function (exec, SKIP_CLOSING) {
			  if (!SKIP_CLOSING && !SAFE_CLOSING) return false;
			  var ITERATION_SUPPORT = false;
			  try {
			    var object = {};
			    object[ITERATOR$1] = function () {
			      return {
			        next: function () {
			          return { done: ITERATION_SUPPORT = true };
			        }
			      };
			    };
			    exec(object);
			  } catch (error) { /* empty */ }
			  return ITERATION_SUPPORT;
			};

			var engineIsIos = /(?:iphone|ipod|ipad).*applewebkit/i.test(engineUserAgent);

			var engineIsNode = classofRaw(global_1.process) == 'process';

			var set = global_1.setImmediate;
			var clear = global_1.clearImmediate;
			var process$2 = global_1.process;
			var MessageChannel = global_1.MessageChannel;
			var Dispatch = global_1.Dispatch;
			var counter = 0;
			var queue = {};
			var ONREADYSTATECHANGE = 'onreadystatechange';
			var location, defer, channel, port;

			try {
			  // Deno throws a ReferenceError on `location` access without `--location` flag
			  location = global_1.location;
			} catch (error) { /* empty */ }

			var run = function (id) {
			  // eslint-disable-next-line no-prototype-builtins -- safe
			  if (queue.hasOwnProperty(id)) {
			    var fn = queue[id];
			    delete queue[id];
			    fn();
			  }
			};

			var runner = function (id) {
			  return function () {
			    run(id);
			  };
			};

			var listener = function (event) {
			  run(event.data);
			};

			var post = function (id) {
			  // old engines have not location.origin
			  global_1.postMessage(String(id), location.protocol + '//' + location.host);
			};

			// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
			if (!set || !clear) {
			  set = function setImmediate(fn) {
			    var args = [];
			    var argumentsLength = arguments.length;
			    var i = 1;
			    while (argumentsLength > i) args.push(arguments[i++]);
			    queue[++counter] = function () {
			      // eslint-disable-next-line no-new-func -- spec requirement
			      (typeof fn == 'function' ? fn : Function(fn)).apply(undefined, args);
			    };
			    defer(counter);
			    return counter;
			  };
			  clear = function clearImmediate(id) {
			    delete queue[id];
			  };
			  // Node.js 0.8-
			  if (engineIsNode) {
			    defer = function (id) {
			      process$2.nextTick(runner(id));
			    };
			  // Sphere (JS game engine) Dispatch API
			  } else if (Dispatch && Dispatch.now) {
			    defer = function (id) {
			      Dispatch.now(runner(id));
			    };
			  // Browsers with MessageChannel, includes WebWorkers
			  // except iOS - https://github.com/zloirock/core-js/issues/624
			  } else if (MessageChannel && !engineIsIos) {
			    channel = new MessageChannel();
			    port = channel.port2;
			    channel.port1.onmessage = listener;
			    defer = functionBindContext(port.postMessage, port, 1);
			  // Browsers with postMessage, skip WebWorkers
			  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
			  } else if (
			    global_1.addEventListener &&
			    typeof postMessage == 'function' &&
			    !global_1.importScripts &&
			    location && location.protocol !== 'file:' &&
			    !fails(post)
			  ) {
			    defer = post;
			    global_1.addEventListener('message', listener, false);
			  // IE8-
			  } else if (ONREADYSTATECHANGE in documentCreateElement('script')) {
			    defer = function (id) {
			      html.appendChild(documentCreateElement('script'))[ONREADYSTATECHANGE] = function () {
			        html.removeChild(this);
			        run(id);
			      };
			    };
			  // Rest old browsers
			  } else {
			    defer = function (id) {
			      setTimeout(runner(id), 0);
			    };
			  }
			}

			var task$1 = {
			  set: set,
			  clear: clear
			};

			var engineIsIosPebble = /iphone|ipod|ipad/i.test(engineUserAgent) && global_1.Pebble !== undefined;

			var engineIsWebosWebkit = /web0s(?!.*chrome)/i.test(engineUserAgent);

			var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
			var macrotask = task$1.set;





			var MutationObserver = global_1.MutationObserver || global_1.WebKitMutationObserver;
			var document$2 = global_1.document;
			var process$1 = global_1.process;
			var Promise$2 = global_1.Promise;
			// Node.js 11 shows ExperimentalWarning on getting `queueMicrotask`
			var queueMicrotaskDescriptor = getOwnPropertyDescriptor(global_1, 'queueMicrotask');
			var queueMicrotask = queueMicrotaskDescriptor && queueMicrotaskDescriptor.value;

			var flush, head, last, notify$1, toggle, node, promise, then;

			// modern engines have queueMicrotask method
			if (!queueMicrotask) {
			  flush = function () {
			    var parent, fn;
			    if (engineIsNode && (parent = process$1.domain)) parent.exit();
			    while (head) {
			      fn = head.fn;
			      head = head.next;
			      try {
			        fn();
			      } catch (error) {
			        if (head) notify$1();
			        else last = undefined;
			        throw error;
			      }
			    } last = undefined;
			    if (parent) parent.enter();
			  };

			  // browsers with MutationObserver, except iOS - https://github.com/zloirock/core-js/issues/339
			  // also except WebOS Webkit https://github.com/zloirock/core-js/issues/898
			  if (!engineIsIos && !engineIsNode && !engineIsWebosWebkit && MutationObserver && document$2) {
			    toggle = true;
			    node = document$2.createTextNode('');
			    new MutationObserver(flush).observe(node, { characterData: true });
			    notify$1 = function () {
			      node.data = toggle = !toggle;
			    };
			  // environments with maybe non-completely correct, but existent Promise
			  } else if (!engineIsIosPebble && Promise$2 && Promise$2.resolve) {
			    // Promise.resolve without an argument throws an error in LG WebOS 2
			    promise = Promise$2.resolve(undefined);
			    // workaround of WebKit ~ iOS Safari 10.1 bug
			    promise.constructor = Promise$2;
			    then = promise.then;
			    notify$1 = function () {
			      then.call(promise, flush);
			    };
			  // Node.js without promises
			  } else if (engineIsNode) {
			    notify$1 = function () {
			      process$1.nextTick(flush);
			    };
			  // for other environments - macrotask based on:
			  // - setImmediate
			  // - MessageChannel
			  // - window.postMessag
			  // - onreadystatechange
			  // - setTimeout
			  } else {
			    notify$1 = function () {
			      // strange IE + webpack dev server bug - use .call(global)
			      macrotask.call(global_1, flush);
			    };
			  }
			}

			var microtask = queueMicrotask || function (fn) {
			  var task = { fn: fn, next: undefined };
			  if (last) last.next = task;
			  if (!head) {
			    head = task;
			    notify$1();
			  } last = task;
			};

			var PromiseCapability = function (C) {
			  var resolve, reject;
			  this.promise = new C(function ($$resolve, $$reject) {
			    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
			    resolve = $$resolve;
			    reject = $$reject;
			  });
			  this.resolve = aFunction(resolve);
			  this.reject = aFunction(reject);
			};

			// `NewPromiseCapability` abstract operation
			// https://tc39.es/ecma262/#sec-newpromisecapability
			var f = function (C) {
			  return new PromiseCapability(C);
			};

			var newPromiseCapability$1 = {
				f: f
			};

			var promiseResolve = function (C, x) {
			  anObject(C);
			  if (isObject$2(x) && x.constructor === C) return x;
			  var promiseCapability = newPromiseCapability$1.f(C);
			  var resolve = promiseCapability.resolve;
			  resolve(x);
			  return promiseCapability.promise;
			};

			var hostReportErrors = function (a, b) {
			  var console = global_1.console;
			  if (console && console.error) {
			    arguments.length === 1 ? console.error(a) : console.error(a, b);
			  }
			};

			var perform = function (exec) {
			  try {
			    return { error: false, value: exec() };
			  } catch (error) {
			    return { error: true, value: error };
			  }
			};

			var engineIsBrowser = typeof window == 'object';

			var task = task$1.set;












			var SPECIES = wellKnownSymbol('species');
			var PROMISE = 'Promise';
			var getInternalState = internalState.get;
			var setInternalState = internalState.set;
			var getInternalPromiseState = internalState.getterFor(PROMISE);
			var NativePromisePrototype = nativePromiseConstructor && nativePromiseConstructor.prototype;
			var PromiseConstructor = nativePromiseConstructor;
			var PromiseConstructorPrototype = NativePromisePrototype;
			var TypeError$1 = global_1.TypeError;
			var document$1 = global_1.document;
			var process = global_1.process;
			var newPromiseCapability = newPromiseCapability$1.f;
			var newGenericPromiseCapability = newPromiseCapability;
			var DISPATCH_EVENT = !!(document$1 && document$1.createEvent && global_1.dispatchEvent);
			var NATIVE_REJECTION_EVENT = typeof PromiseRejectionEvent == 'function';
			var UNHANDLED_REJECTION = 'unhandledrejection';
			var REJECTION_HANDLED = 'rejectionhandled';
			var PENDING = 0;
			var FULFILLED = 1;
			var REJECTED = 2;
			var HANDLED = 1;
			var UNHANDLED = 2;
			var SUBCLASSING = false;
			var Internal, OwnPromiseCapability, PromiseWrapper, nativeThen;

			var FORCED = isForced_1(PROMISE, function () {
			  var PROMISE_CONSTRUCTOR_SOURCE = inspectSource(PromiseConstructor);
			  var GLOBAL_CORE_JS_PROMISE = PROMISE_CONSTRUCTOR_SOURCE !== String(PromiseConstructor);
			  // V8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
			  // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
			  // We can't detect it synchronously, so just check versions
			  if (!GLOBAL_CORE_JS_PROMISE && engineV8Version === 66) return true;
			  // We can't use @@species feature detection in V8 since it causes
			  // deoptimization and performance degradation
			  // https://github.com/zloirock/core-js/issues/679
			  if (engineV8Version >= 51 && /native code/.test(PROMISE_CONSTRUCTOR_SOURCE)) return false;
			  // Detect correctness of subclassing with @@species support
			  var promise = new PromiseConstructor(function (resolve) { resolve(1); });
			  var FakePromise = function (exec) {
			    exec(function () { /* empty */ }, function () { /* empty */ });
			  };
			  var constructor = promise.constructor = {};
			  constructor[SPECIES] = FakePromise;
			  SUBCLASSING = promise.then(function () { /* empty */ }) instanceof FakePromise;
			  if (!SUBCLASSING) return true;
			  // Unhandled rejections tracking support, NodeJS Promise without it fails @@species test
			  return !GLOBAL_CORE_JS_PROMISE && engineIsBrowser && !NATIVE_REJECTION_EVENT;
			});

			var INCORRECT_ITERATION = FORCED || !checkCorrectnessOfIteration(function (iterable) {
			  PromiseConstructor.all(iterable)['catch'](function () { /* empty */ });
			});

			// helpers
			var isThenable = function (it) {
			  var then;
			  return isObject$2(it) && typeof (then = it.then) == 'function' ? then : false;
			};

			var notify = function (state, isReject) {
			  if (state.notified) return;
			  state.notified = true;
			  var chain = state.reactions;
			  microtask(function () {
			    var value = state.value;
			    var ok = state.state == FULFILLED;
			    var index = 0;
			    // variable length - can't use forEach
			    while (chain.length > index) {
			      var reaction = chain[index++];
			      var handler = ok ? reaction.ok : reaction.fail;
			      var resolve = reaction.resolve;
			      var reject = reaction.reject;
			      var domain = reaction.domain;
			      var result, then, exited;
			      try {
			        if (handler) {
			          if (!ok) {
			            if (state.rejection === UNHANDLED) onHandleUnhandled(state);
			            state.rejection = HANDLED;
			          }
			          if (handler === true) result = value;
			          else {
			            if (domain) domain.enter();
			            result = handler(value); // can throw
			            if (domain) {
			              domain.exit();
			              exited = true;
			            }
			          }
			          if (result === reaction.promise) {
			            reject(TypeError$1('Promise-chain cycle'));
			          } else if (then = isThenable(result)) {
			            then.call(result, resolve, reject);
			          } else resolve(result);
			        } else reject(value);
			      } catch (error) {
			        if (domain && !exited) domain.exit();
			        reject(error);
			      }
			    }
			    state.reactions = [];
			    state.notified = false;
			    if (isReject && !state.rejection) onUnhandled(state);
			  });
			};

			var dispatchEvent = function (name, promise, reason) {
			  var event, handler;
			  if (DISPATCH_EVENT) {
			    event = document$1.createEvent('Event');
			    event.promise = promise;
			    event.reason = reason;
			    event.initEvent(name, false, true);
			    global_1.dispatchEvent(event);
			  } else event = { promise: promise, reason: reason };
			  if (!NATIVE_REJECTION_EVENT && (handler = global_1['on' + name])) handler(event);
			  else if (name === UNHANDLED_REJECTION) hostReportErrors('Unhandled promise rejection', reason);
			};

			var onUnhandled = function (state) {
			  task.call(global_1, function () {
			    var promise = state.facade;
			    var value = state.value;
			    var IS_UNHANDLED = isUnhandled(state);
			    var result;
			    if (IS_UNHANDLED) {
			      result = perform(function () {
			        if (engineIsNode) {
			          process.emit('unhandledRejection', value, promise);
			        } else dispatchEvent(UNHANDLED_REJECTION, promise, value);
			      });
			      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
			      state.rejection = engineIsNode || isUnhandled(state) ? UNHANDLED : HANDLED;
			      if (result.error) throw result.value;
			    }
			  });
			};

			var isUnhandled = function (state) {
			  return state.rejection !== HANDLED && !state.parent;
			};

			var onHandleUnhandled = function (state) {
			  task.call(global_1, function () {
			    var promise = state.facade;
			    if (engineIsNode) {
			      process.emit('rejectionHandled', promise);
			    } else dispatchEvent(REJECTION_HANDLED, promise, state.value);
			  });
			};

			var bind = function (fn, state, unwrap) {
			  return function (value) {
			    fn(state, value, unwrap);
			  };
			};

			var internalReject = function (state, value, unwrap) {
			  if (state.done) return;
			  state.done = true;
			  if (unwrap) state = unwrap;
			  state.value = value;
			  state.state = REJECTED;
			  notify(state, true);
			};

			var internalResolve = function (state, value, unwrap) {
			  if (state.done) return;
			  state.done = true;
			  if (unwrap) state = unwrap;
			  try {
			    if (state.facade === value) throw TypeError$1("Promise can't be resolved itself");
			    var then = isThenable(value);
			    if (then) {
			      microtask(function () {
			        var wrapper = { done: false };
			        try {
			          then.call(value,
			            bind(internalResolve, wrapper, state),
			            bind(internalReject, wrapper, state)
			          );
			        } catch (error) {
			          internalReject(wrapper, error, state);
			        }
			      });
			    } else {
			      state.value = value;
			      state.state = FULFILLED;
			      notify(state, false);
			    }
			  } catch (error) {
			    internalReject({ done: false }, error, state);
			  }
			};

			// constructor polyfill
			if (FORCED) {
			  // 25.4.3.1 Promise(executor)
			  PromiseConstructor = function Promise(executor) {
			    anInstance(this, PromiseConstructor, PROMISE);
			    aFunction(executor);
			    Internal.call(this);
			    var state = getInternalState(this);
			    try {
			      executor(bind(internalResolve, state), bind(internalReject, state));
			    } catch (error) {
			      internalReject(state, error);
			    }
			  };
			  PromiseConstructorPrototype = PromiseConstructor.prototype;
			  // eslint-disable-next-line no-unused-vars -- required for `.length`
			  Internal = function Promise(executor) {
			    setInternalState(this, {
			      type: PROMISE,
			      done: false,
			      notified: false,
			      parent: false,
			      reactions: [],
			      rejection: false,
			      state: PENDING,
			      value: undefined
			    });
			  };
			  Internal.prototype = redefineAll(PromiseConstructorPrototype, {
			    // `Promise.prototype.then` method
			    // https://tc39.es/ecma262/#sec-promise.prototype.then
			    then: function then(onFulfilled, onRejected) {
			      var state = getInternalPromiseState(this);
			      var reaction = newPromiseCapability(speciesConstructor(this, PromiseConstructor));
			      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
			      reaction.fail = typeof onRejected == 'function' && onRejected;
			      reaction.domain = engineIsNode ? process.domain : undefined;
			      state.parent = true;
			      state.reactions.push(reaction);
			      if (state.state != PENDING) notify(state, false);
			      return reaction.promise;
			    },
			    // `Promise.prototype.catch` method
			    // https://tc39.es/ecma262/#sec-promise.prototype.catch
			    'catch': function (onRejected) {
			      return this.then(undefined, onRejected);
			    }
			  });
			  OwnPromiseCapability = function () {
			    var promise = new Internal();
			    var state = getInternalState(promise);
			    this.promise = promise;
			    this.resolve = bind(internalResolve, state);
			    this.reject = bind(internalReject, state);
			  };
			  newPromiseCapability$1.f = newPromiseCapability = function (C) {
			    return C === PromiseConstructor || C === PromiseWrapper
			      ? new OwnPromiseCapability(C)
			      : newGenericPromiseCapability(C);
			  };

			  if (typeof nativePromiseConstructor == 'function' && NativePromisePrototype !== Object.prototype) {
			    nativeThen = NativePromisePrototype.then;

			    if (!SUBCLASSING) {
			      // make `Promise#then` return a polyfilled `Promise` for native promise-based APIs
			      redefine(NativePromisePrototype, 'then', function then(onFulfilled, onRejected) {
			        var that = this;
			        return new PromiseConstructor(function (resolve, reject) {
			          nativeThen.call(that, resolve, reject);
			        }).then(onFulfilled, onRejected);
			      // https://github.com/zloirock/core-js/issues/640
			      }, { unsafe: true });

			      // makes sure that native promise-based APIs `Promise#catch` properly works with patched `Promise#then`
			      redefine(NativePromisePrototype, 'catch', PromiseConstructorPrototype['catch'], { unsafe: true });
			    }

			    // make `.constructor === Promise` work for native promise-based APIs
			    try {
			      delete NativePromisePrototype.constructor;
			    } catch (error) { /* empty */ }

			    // make `instanceof Promise` work for native promise-based APIs
			    if (objectSetPrototypeOf) {
			      objectSetPrototypeOf(NativePromisePrototype, PromiseConstructorPrototype);
			    }
			  }
			}

			_export({ global: true, wrap: true, forced: FORCED }, {
			  Promise: PromiseConstructor
			});

			setToStringTag(PromiseConstructor, PROMISE, false);
			setSpecies(PROMISE);

			PromiseWrapper = getBuiltIn(PROMISE);

			// statics
			_export({ target: PROMISE, stat: true, forced: FORCED }, {
			  // `Promise.reject` method
			  // https://tc39.es/ecma262/#sec-promise.reject
			  reject: function reject(r) {
			    var capability = newPromiseCapability(this);
			    capability.reject.call(undefined, r);
			    return capability.promise;
			  }
			});

			_export({ target: PROMISE, stat: true, forced: FORCED }, {
			  // `Promise.resolve` method
			  // https://tc39.es/ecma262/#sec-promise.resolve
			  resolve: function resolve(x) {
			    return promiseResolve(this, x);
			  }
			});

			_export({ target: PROMISE, stat: true, forced: INCORRECT_ITERATION }, {
			  // `Promise.all` method
			  // https://tc39.es/ecma262/#sec-promise.all
			  all: function all(iterable) {
			    var C = this;
			    var capability = newPromiseCapability(C);
			    var resolve = capability.resolve;
			    var reject = capability.reject;
			    var result = perform(function () {
			      var $promiseResolve = aFunction(C.resolve);
			      var values = [];
			      var counter = 0;
			      var remaining = 1;
			      iterate(iterable, function (promise) {
			        var index = counter++;
			        var alreadyCalled = false;
			        values.push(undefined);
			        remaining++;
			        $promiseResolve.call(C, promise).then(function (value) {
			          if (alreadyCalled) return;
			          alreadyCalled = true;
			          values[index] = value;
			          --remaining || resolve(values);
			        }, reject);
			      });
			      --remaining || resolve(values);
			    });
			    if (result.error) reject(result.value);
			    return capability.promise;
			  },
			  // `Promise.race` method
			  // https://tc39.es/ecma262/#sec-promise.race
			  race: function race(iterable) {
			    var C = this;
			    var capability = newPromiseCapability(C);
			    var reject = capability.reject;
			    var result = perform(function () {
			      var $promiseResolve = aFunction(C.resolve);
			      iterate(iterable, function (promise) {
			        $promiseResolve.call(C, promise).then(capability.resolve, reject);
			      });
			    });
			    if (result.error) reject(result.value);
			    return capability.promise;
			  }
			});

			// `Promise.allSettled` method
			// https://tc39.es/ecma262/#sec-promise.allsettled
			_export({ target: 'Promise', stat: true }, {
			  allSettled: function allSettled(iterable) {
			    var C = this;
			    var capability = newPromiseCapability$1.f(C);
			    var resolve = capability.resolve;
			    var reject = capability.reject;
			    var result = perform(function () {
			      var promiseResolve = aFunction(C.resolve);
			      var values = [];
			      var counter = 0;
			      var remaining = 1;
			      iterate(iterable, function (promise) {
			        var index = counter++;
			        var alreadyCalled = false;
			        values.push(undefined);
			        remaining++;
			        promiseResolve.call(C, promise).then(function (value) {
			          if (alreadyCalled) return;
			          alreadyCalled = true;
			          values[index] = { status: 'fulfilled', value: value };
			          --remaining || resolve(values);
			        }, function (error) {
			          if (alreadyCalled) return;
			          alreadyCalled = true;
			          values[index] = { status: 'rejected', reason: error };
			          --remaining || resolve(values);
			        });
			      });
			      --remaining || resolve(values);
			    });
			    if (result.error) reject(result.value);
			    return capability.promise;
			  }
			});

			var PROMISE_ANY_ERROR = 'No one promise resolved';

			// `Promise.any` method
			// https://tc39.es/ecma262/#sec-promise.any
			_export({ target: 'Promise', stat: true }, {
			  any: function any(iterable) {
			    var C = this;
			    var capability = newPromiseCapability$1.f(C);
			    var resolve = capability.resolve;
			    var reject = capability.reject;
			    var result = perform(function () {
			      var promiseResolve = aFunction(C.resolve);
			      var errors = [];
			      var counter = 0;
			      var remaining = 1;
			      var alreadyResolved = false;
			      iterate(iterable, function (promise) {
			        var index = counter++;
			        var alreadyRejected = false;
			        errors.push(undefined);
			        remaining++;
			        promiseResolve.call(C, promise).then(function (value) {
			          if (alreadyRejected || alreadyResolved) return;
			          alreadyResolved = true;
			          resolve(value);
			        }, function (error) {
			          if (alreadyRejected || alreadyResolved) return;
			          alreadyRejected = true;
			          errors[index] = error;
			          --remaining || reject(new (getBuiltIn('AggregateError'))(errors, PROMISE_ANY_ERROR));
			        });
			      });
			      --remaining || reject(new (getBuiltIn('AggregateError'))(errors, PROMISE_ANY_ERROR));
			    });
			    if (result.error) reject(result.value);
			    return capability.promise;
			  }
			});

			// Safari bug https://bugs.webkit.org/show_bug.cgi?id=200829
			var NON_GENERIC = !!nativePromiseConstructor && fails(function () {
			  nativePromiseConstructor.prototype['finally'].call({ then: function () { /* empty */ } }, function () { /* empty */ });
			});

			// `Promise.prototype.finally` method
			// https://tc39.es/ecma262/#sec-promise.prototype.finally
			_export({ target: 'Promise', proto: true, real: true, forced: NON_GENERIC }, {
			  'finally': function (onFinally) {
			    var C = speciesConstructor(this, getBuiltIn('Promise'));
			    var isFunction = typeof onFinally == 'function';
			    return this.then(
			      isFunction ? function (x) {
			        return promiseResolve(C, onFinally()).then(function () { return x; });
			      } : onFinally,
			      isFunction ? function (e) {
			        return promiseResolve(C, onFinally()).then(function () { throw e; });
			      } : onFinally
			    );
			  }
			});

			// makes sure that native promise-based APIs `Promise#finally` properly works with patched `Promise#then`
			if (typeof nativePromiseConstructor == 'function') {
			  var method = getBuiltIn('Promise').prototype['finally'];
			  if (nativePromiseConstructor.prototype['finally'] !== method) {
			    redefine(nativePromiseConstructor.prototype, 'finally', method, { unsafe: true });
			  }
			}

			path.Promise;

			// iterable DOM collections
			// flag - `iterable` interface - 'entries', 'keys', 'values', 'forEach' methods
			var domIterables = {
			  CSSRuleList: 0,
			  CSSStyleDeclaration: 0,
			  CSSValueList: 0,
			  ClientRectList: 0,
			  DOMRectList: 0,
			  DOMStringList: 0,
			  DOMTokenList: 1,
			  DataTransferItemList: 0,
			  FileList: 0,
			  HTMLAllCollection: 0,
			  HTMLCollection: 0,
			  HTMLFormElement: 0,
			  HTMLSelectElement: 0,
			  MediaList: 0,
			  MimeTypeArray: 0,
			  NamedNodeMap: 0,
			  NodeList: 1,
			  PaintRequestList: 0,
			  Plugin: 0,
			  PluginArray: 0,
			  SVGLengthList: 0,
			  SVGNumberList: 0,
			  SVGPathSegList: 0,
			  SVGPointList: 0,
			  SVGStringList: 0,
			  SVGTransformList: 0,
			  SourceBufferList: 0,
			  StyleSheetList: 0,
			  TextTrackCueList: 0,
			  TextTrackList: 0,
			  TouchList: 0
			};

			var ITERATOR = wellKnownSymbol('iterator');
			var TO_STRING_TAG = wellKnownSymbol('toStringTag');
			var ArrayValues = es_array_iterator.values;

			for (var COLLECTION_NAME in domIterables) {
			  var Collection = global_1[COLLECTION_NAME];
			  var CollectionPrototype = Collection && Collection.prototype;
			  if (CollectionPrototype) {
			    // some Chrome versions have non-configurable methods on DOMTokenList
			    if (CollectionPrototype[ITERATOR] !== ArrayValues) try {
			      createNonEnumerableProperty(CollectionPrototype, ITERATOR, ArrayValues);
			    } catch (error) {
			      CollectionPrototype[ITERATOR] = ArrayValues;
			    }
			    if (!CollectionPrototype[TO_STRING_TAG]) {
			      createNonEnumerableProperty(CollectionPrototype, TO_STRING_TAG, COLLECTION_NAME);
			    }
			    if (domIterables[COLLECTION_NAME]) for (var METHOD_NAME in es_array_iterator) {
			      // some Chrome versions have non-configurable methods on DOMTokenList
			      if (CollectionPrototype[METHOD_NAME] !== es_array_iterator[METHOD_NAME]) try {
			        createNonEnumerableProperty(CollectionPrototype, METHOD_NAME, es_array_iterator[METHOD_NAME]);
			      } catch (error) {
			        CollectionPrototype[METHOD_NAME] = es_array_iterator[METHOD_NAME];
			      }
			    }
			  }
			}

			// `Promise.try` method
			// https://github.com/tc39/proposal-promise-try
			_export({ target: 'Promise', stat: true }, {
			  'try': function (callbackfn) {
			    var promiseCapability = newPromiseCapability$1.f(this);
			    var result = perform(callbackfn);
			    (result.error ? promiseCapability.reject : promiseCapability.resolve)(result.value);
			    return promiseCapability.promise;
			  }
			});

			function getFetch(props) {
			    return (input, init) => {
			        const sourcePromise = fetch(input, init);
			        sourcePromise.id = props.id;
			        return Promise.resolve(sourcePromise);
			    };
			}
			['finally', 'then', 'catch'].forEach((key) => {
			    let old = Promise.prototype[key];
			    Promise.prototype[key] = function (...args) {
			        let wrapArgs = args.map((item) => {
			            if (item instanceof Function && this.id) {
			                return (x) => {
			                    const result = item(x);
			                    getGlobal().callJS(this.id, []);
			                    return result;
			                };
			            }
			            else {
			                return item;
			            }
			        });
			        let result = old.call(this, ...wrapArgs);
			        result.id = this.id;
			        return result;
			    };
			});
			function getPromise(props) {
			    let isDestory = false;
			    class NewPromise extends Promise {
			        constructor(args) {
			            super(args);
			        }
			        then(onfulfilled, onrejected) {
			            return super.then(onfulfilled
			                ? (...args) => {
			                    if (isDestory)
			                        return;
			                    return onfulfilled(...args);
			                }
			                : undefined, onrejected
			                ? (reason) => {
			                    if (isDestory)
			                        return;
			                    return onrejected(reason);
			                }
			                : undefined);
			        }
			        catch(onrejected) {
			            return super.catch(onrejected
			                ? (reason) => {
			                    if (isDestory)
			                        return;
			                    return onrejected(reason);
			                }
			                : undefined);
			        }
			    }
			    let methods = ['all', 'race', 'resolve', 'reject'];
			    let handler = {
			        construct(_, args) {
			            let obj = new NewPromise(args[0]);
			            obj.id = props.id || 0;
			            return obj;
			        },
			        get(_, key) {
			            if (methods.indexOf(key) > -1) {
			                return (...args) => {
			                    let result = NewPromise[key](...args);
			                    result.id = props.id || 0;
			                    return result;
			                };
			            }
			            else if (key === 'destroy') {
			                return () => {
			                    isDestory = true;
			                };
			            }
			            else {
			                return NewPromise[key];
			            }
			        },
			    };
			    let proxy = new Proxy(NewPromise, handler);
			    return proxy;
			}

			var ReceiverType; exports('a7', ReceiverType);
			(function (ReceiverType) {
			    ReceiverType["callback"] = "callback";
			    ReceiverType["fireDomEvent"] = "fireDomEvent";
			    ReceiverType["globalEvent"] = "globalEvent";
			    ReceiverType["syncCall"] = "syncCall";
			})(ReceiverType || (exports('a7', ReceiverType = {})));

			var SyncCallType; exports('ax', SyncCallType);
			(function (SyncCallType) {
			    SyncCallType["connect"] = "connect.syncCall";
			})(SyncCallType || (exports('ax', SyncCallType = {})));
			class SyncCallManager {
			    constructor() {
			        this.callMap = {};
			    }
			    addHandler(type, handler) {
			        if (this.callMap[type]) {
			            throw new Error(`type:${type} 类型的 handler 已存在`);
			        }
			        this.callMap[type] = handler;
			    }
			    removeHandler(type) {
			        delete this.callMap[type];
			    }
			    dispatch(type, args) {
			        if (!this.callMap[type]) {
			            throw new Error(`方法 ${type} 未找到`);
			        }
			        const result = this.callMap[type](...args);
			        return result;
			    }
			    destroy() {
			        this.callMap = {};
			    }
			} exports('a5', SyncCallManager);

			var ModuleSnapshotType; exports('ae', ModuleSnapshotType);
			(function (ModuleSnapshotType) {
			    ModuleSnapshotType[ModuleSnapshotType["lastCall"] = 0] = "lastCall";
			})(ModuleSnapshotType || (exports('ae', ModuleSnapshotType = {})));

			({
			    name: ReceiverType.fireDomEvent,
			    handler: (instance, ...args) => {
			        let [nodeId, eventType, detail] = args;
			        instance.document.fireEvent(nodeId, eventType, detail);
			    }
			});

			const CallbackHandler = exports('ah', {
			    name: ReceiverType.callback,
			    handler: (instance, callbackId, data, keepAlive = false) => {
			        instance.callbackManager.trigger(callbackId, data, keepAlive);
			    }
			});

			const GlobalEventHandler = exports('ai', {
			    name: ReceiverType.globalEvent,
			    handler: (instance, eventType, args) => {
			        instance.globalEventManager.dispatchEvent(eventType, args);
			    }
			});

			const FAKER_INSTANCE_ID = -1;
			const Reporter = exports('an', {
			    reportKv(id, str) {
			        getGlobal().reporter.reportKv(FAKER_INSTANCE_ID, id, str);
			    },
			    reportRuntimeInfo(data) {
			        getGlobal().reporter.dataReporting(FAKER_INSTANCE_ID, 'runtimeInfo', JSON.stringify(data));
			    },
			});
			class ReportTimer {
			    static start(tag) {
			        this.timeMap[tag] = Date.now();
			    }
			    static end(tag) {
			        let start = this.timeMap[tag];
			        if (isUndefined(start)) {
			            return 0;
			        }
			        else {
			            delete this.timeMap[tag];
			            return Date.now() - start;
			        }
			    }
			} exports('al', ReportTimer);
			ReportTimer.timeMap = {};

			const SyncCallHandlerHandler = exports('aj', {
			    name: ReceiverType.syncCall,
			    handler: (instance, type, args) => {
			        return instance.syncCallManager.dispatch(type, args);
			    },
			});

			var FrameworkType; exports('ap', FrameworkType);
			(function (FrameworkType) {
			    FrameworkType["VueForFlutterPage"] = "VueForFlutterPage";
			    FrameworkType["Vue3ForFlutterPage"] = "Vue3ForFlutterPage";
			    FrameworkType["ReactForFlutterPage"] = "ReactForFlutterPage";
			    FrameworkType["VueForWebPage"] = "VueForWebPage";
			    FrameworkType["VuexForStore"] = "VuexForStore";
			    FrameworkType["NotFramework"] = "NotFramework";
			})(FrameworkType || (exports('ap', FrameworkType = {})));

			var DomApi;
			(function (DomApi) {
			    DomApi["release"] = "release";
			    DomApi["createElement"] = "createElement";
			    DomApi["getParentNode"] = "getParentNode";
			    DomApi["getChildNode"] = "getChildNode";
			    DomApi["appendChild"] = "appendChild";
			    DomApi["insertChild"] = "insertChild";
			    DomApi["removeChild"] = "removeChild";
			    DomApi["replaceChild"] = "replaceChild";
			    DomApi["spliceChild"] = "spliceChild";
			    DomApi["findChildPosition"] = "findChildPosition";
			    DomApi["childrenLength"] = "childrenLength";
			    DomApi["setId"] = "setId";
			    DomApi["setClass"] = "setClass";
			    DomApi["setStyle"] = "setStyle";
			    DomApi["appendStyle"] = "appendStyle";
			    DomApi["replaceStyle"] = "replaceStyle";
			    DomApi["clearStyle"] = "clearStyle";
			    DomApi["requestLayout"] = "requestLayout";
			    DomApi["getWindowWidth"] = "getWindowWidth";
			    DomApi["getWindowHeight"] = "getWindowHeight";
			    DomApi["getBoundingClientRect"] = "getBoundingClientRect";
			    DomApi["getClientLeft"] = "getClientLeft";
			    DomApi["getClientTop"] = "getClientTop";
			    DomApi["getClientWidth"] = "getClientWidth";
			    DomApi["getClientHeight"] = "getClientHeight";
			    DomApi["getOffsetLeft"] = "getOffsetLeft";
			    DomApi["getOffsetTop"] = "getOffsetTop";
			    DomApi["getOffsetWidth"] = "getOffsetWidth";
			    DomApi["getOffsetHeight"] = "getOffsetHeight";
			    DomApi["getComputedStyle"] = "getComputedStyle";
			    DomApi["getScrollPosition"] = "getScrollPosition";
			    DomApi["setScrollPosition"] = "setScrollPosition";
			    DomApi["setAttr"] = "setAttr";
			    DomApi["setText"] = "setText";
			    DomApi["setRootNode"] = "setRootNode";
			    DomApi["getDevicePixelRatio"] = "getDevicePixelRatio";
			    DomApi["eventListenerChange"] = "eventListenerChange";
			    DomApi["querySelector"] = "querySelector";
			    DomApi["querySelectorAll"] = "querySelectorAll";
			    DomApi["createIntersectionObserver"] = "createIntersectionObserver";
			    DomApi["deleteIntersectionObserver"] = "deleteIntersectionObserver";
			    DomApi["addIntersectionObserver"] = "addIntersectionObserver";
			    DomApi["removeIntersectionObserver"] = "removeIntersectionObserver";
			    DomApi["showModal"] = "showModal";
			    DomApi["showToast"] = "showToast";
			    DomApi["hideToast"] = "hideToast";
			    DomApi["showActionSheet"] = "showActionSheet";
			    DomApi["setTitle"] = "setTitle";
			    DomApi["setTitleAlpha"] = "setTitleAlpha";
			    DomApi["callMethod"] = "callMethod";
			})(DomApi || (DomApi = {}));
			var BatchIndex;
			(function (BatchIndex) {
			    BatchIndex[BatchIndex["release"] = 0] = "release";
			    BatchIndex[BatchIndex["createElement"] = 1] = "createElement";
			    BatchIndex[BatchIndex["appendChild"] = 2] = "appendChild";
			    BatchIndex[BatchIndex["insertChild"] = 3] = "insertChild";
			    BatchIndex[BatchIndex["removeChild"] = 4] = "removeChild";
			    BatchIndex[BatchIndex["replaceChild"] = 5] = "replaceChild";
			    BatchIndex[BatchIndex["spliceChild"] = 6] = "spliceChild";
			    BatchIndex[BatchIndex["setId"] = 7] = "setId";
			    BatchIndex[BatchIndex["setClass"] = 8] = "setClass";
			    BatchIndex[BatchIndex["setStyle"] = 9] = "setStyle";
			    BatchIndex[BatchIndex["setAttr"] = 10] = "setAttr";
			    BatchIndex[BatchIndex["setText"] = 11] = "setText";
			    BatchIndex[BatchIndex["eventListenerChange"] = 12] = "eventListenerChange";
			})(BatchIndex || (BatchIndex = {}));

			/**
			 * Checks if `value` is the
			 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
			 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
			 *
			 * @static
			 * @memberOf _
			 * @since 0.1.0
			 * @category Lang
			 * @param {*} value The value to check.
			 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
			 * @example
			 *
			 * _.isObject({});
			 * // => true
			 *
			 * _.isObject([1, 2, 3]);
			 * // => true
			 *
			 * _.isObject(_.noop);
			 * // => true
			 *
			 * _.isObject(null);
			 * // => false
			 */
			function isObject(value) {
			  var type = typeof value;
			  return value != null && (type == 'object' || type == 'function');
			}

			var isObject_1 = exports('at', isObject);

			/** Detect free variable `global` from Node.js. */
			var freeGlobal = typeof commonjsGlobal == 'object' && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;

			var _freeGlobal = freeGlobal;

			/** Detect free variable `self`. */
			var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

			/** Used as a reference to the global object. */
			var root = _freeGlobal || freeSelf || Function('return this')();

			var _root = exports('aq', root);

			/** Built-in value references. */
			var Symbol$1 = _root.Symbol;

			var _Symbol = Symbol$1;

			/** Used for built-in method references. */
			var objectProto$3 = Object.prototype;

			/** Used to check objects for own properties. */
			var hasOwnProperty$2 = objectProto$3.hasOwnProperty;

			/**
			 * Used to resolve the
			 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
			 * of values.
			 */
			var nativeObjectToString$1 = objectProto$3.toString;

			/** Built-in value references. */
			var symToStringTag$1 = _Symbol ? _Symbol.toStringTag : undefined;

			/**
			 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
			 *
			 * @private
			 * @param {*} value The value to query.
			 * @returns {string} Returns the raw `toStringTag`.
			 */
			function getRawTag(value) {
			  var isOwn = hasOwnProperty$2.call(value, symToStringTag$1),
			      tag = value[symToStringTag$1];

			  try {
			    value[symToStringTag$1] = undefined;
			    var unmasked = true;
			  } catch (e) {}

			  var result = nativeObjectToString$1.call(value);
			  if (unmasked) {
			    if (isOwn) {
			      value[symToStringTag$1] = tag;
			    } else {
			      delete value[symToStringTag$1];
			    }
			  }
			  return result;
			}

			var _getRawTag = getRawTag;

			/** Used for built-in method references. */
			var objectProto$2 = Object.prototype;

			/**
			 * Used to resolve the
			 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
			 * of values.
			 */
			var nativeObjectToString = objectProto$2.toString;

			/**
			 * Converts `value` to a string using `Object.prototype.toString`.
			 *
			 * @private
			 * @param {*} value The value to convert.
			 * @returns {string} Returns the converted string.
			 */
			function objectToString(value) {
			  return nativeObjectToString.call(value);
			}

			var _objectToString = objectToString;

			/** `Object#toString` result references. */
			var nullTag = '[object Null]',
			    undefinedTag = '[object Undefined]';

			/** Built-in value references. */
			var symToStringTag = _Symbol ? _Symbol.toStringTag : undefined;

			/**
			 * The base implementation of `getTag` without fallbacks for buggy environments.
			 *
			 * @private
			 * @param {*} value The value to query.
			 * @returns {string} Returns the `toStringTag`.
			 */
			function baseGetTag(value) {
			  if (value == null) {
			    return value === undefined ? undefinedTag : nullTag;
			  }
			  return (symToStringTag && symToStringTag in Object(value))
			    ? _getRawTag(value)
			    : _objectToString(value);
			}

			var _baseGetTag = exports('as', baseGetTag);

			/**
			 * Checks if `value` is object-like. A value is object-like if it's not `null`
			 * and has a `typeof` result of "object".
			 *
			 * @static
			 * @memberOf _
			 * @since 4.0.0
			 * @category Lang
			 * @param {*} value The value to check.
			 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
			 * @example
			 *
			 * _.isObjectLike({});
			 * // => true
			 *
			 * _.isObjectLike([1, 2, 3]);
			 * // => true
			 *
			 * _.isObjectLike(_.noop);
			 * // => false
			 *
			 * _.isObjectLike(null);
			 * // => false
			 */
			function isObjectLike(value) {
			  return value != null && typeof value == 'object';
			}

			var isObjectLike_1 = exports('ar', isObjectLike);

			/** `Object#toString` result references. */
			var asyncTag = '[object AsyncFunction]',
			    funcTag = '[object Function]',
			    genTag = '[object GeneratorFunction]',
			    proxyTag = '[object Proxy]';

			/**
			 * Checks if `value` is classified as a `Function` object.
			 *
			 * @static
			 * @memberOf _
			 * @since 0.1.0
			 * @category Lang
			 * @param {*} value The value to check.
			 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
			 * @example
			 *
			 * _.isFunction(_);
			 * // => true
			 *
			 * _.isFunction(/abc/);
			 * // => false
			 */
			function isFunction(value) {
			  if (!isObject_1(value)) {
			    return false;
			  }
			  // The use of `Object#toString` avoids issues with the `typeof` operator
			  // in Safari 9 which returns 'object' for typed arrays and other constructors.
			  var tag = _baseGetTag(value);
			  return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
			}

			var isFunction_1 = isFunction;

			/** Used to detect overreaching core-js shims. */
			var coreJsData = _root['__core-js_shared__'];

			var _coreJsData = coreJsData;

			/** Used to detect methods masquerading as native. */
			var maskSrcKey = (function() {
			  var uid = /[^.]+$/.exec(_coreJsData && _coreJsData.keys && _coreJsData.keys.IE_PROTO || '');
			  return uid ? ('Symbol(src)_1.' + uid) : '';
			}());

			/**
			 * Checks if `func` has its source masked.
			 *
			 * @private
			 * @param {Function} func The function to check.
			 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
			 */
			function isMasked(func) {
			  return !!maskSrcKey && (maskSrcKey in func);
			}

			var _isMasked = isMasked;

			/** Used for built-in method references. */
			var funcProto$1 = Function.prototype;

			/** Used to resolve the decompiled source of functions. */
			var funcToString$1 = funcProto$1.toString;

			/**
			 * Converts `func` to its source code.
			 *
			 * @private
			 * @param {Function} func The function to convert.
			 * @returns {string} Returns the source code.
			 */
			function toSource(func) {
			  if (func != null) {
			    try {
			      return funcToString$1.call(func);
			    } catch (e) {}
			    try {
			      return (func + '');
			    } catch (e) {}
			  }
			  return '';
			}

			var _toSource = toSource;

			/**
			 * Used to match `RegExp`
			 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
			 */
			var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

			/** Used to detect host constructors (Safari). */
			var reIsHostCtor = /^\[object .+?Constructor\]$/;

			/** Used for built-in method references. */
			var funcProto = Function.prototype,
			    objectProto$1 = Object.prototype;

			/** Used to resolve the decompiled source of functions. */
			var funcToString = funcProto.toString;

			/** Used to check objects for own properties. */
			var hasOwnProperty$1 = objectProto$1.hasOwnProperty;

			/** Used to detect if a method is native. */
			var reIsNative = RegExp('^' +
			  funcToString.call(hasOwnProperty$1).replace(reRegExpChar, '\\$&')
			  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
			);

			/**
			 * The base implementation of `_.isNative` without bad shim checks.
			 *
			 * @private
			 * @param {*} value The value to check.
			 * @returns {boolean} Returns `true` if `value` is a native function,
			 *  else `false`.
			 */
			function baseIsNative(value) {
			  if (!isObject_1(value) || _isMasked(value)) {
			    return false;
			  }
			  var pattern = isFunction_1(value) ? reIsNative : reIsHostCtor;
			  return pattern.test(_toSource(value));
			}

			var _baseIsNative = baseIsNative;

			/**
			 * Gets the value at `key` of `object`.
			 *
			 * @private
			 * @param {Object} [object] The object to query.
			 * @param {string} key The key of the property to get.
			 * @returns {*} Returns the property value.
			 */
			function getValue(object, key) {
			  return object == null ? undefined : object[key];
			}

			var _getValue = getValue;

			/**
			 * Gets the native function at `key` of `object`.
			 *
			 * @private
			 * @param {Object} object The object to query.
			 * @param {string} key The key of the method to get.
			 * @returns {*} Returns the function if it's native, else `undefined`.
			 */
			function getNative(object, key) {
			  var value = _getValue(object, key);
			  return _baseIsNative(value) ? value : undefined;
			}

			var _getNative = getNative;

			/* Built-in method references that are verified to be native. */
			var Map = _getNative(_root, 'Map');

			var _Map = Map;

			/* Built-in method references that are verified to be native. */
			_getNative(Object, 'create');

			((function() {
			  try {
			    var func = _getNative(Object, 'defineProperty');
			    func({}, '', {});
			    return func;
			  } catch (e) {}
			})());

			/** `Object#toString` result references. */
			var argsTag = '[object Arguments]';

			/**
			 * The base implementation of `_.isArguments`.
			 *
			 * @private
			 * @param {*} value The value to check.
			 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
			 */
			function baseIsArguments(value) {
			  return isObjectLike_1(value) && _baseGetTag(value) == argsTag;
			}

			var _baseIsArguments = baseIsArguments;

			/** Used for built-in method references. */
			var objectProto = Object.prototype;

			/** Used to check objects for own properties. */
			var hasOwnProperty = objectProto.hasOwnProperty;

			/** Built-in value references. */
			var propertyIsEnumerable = objectProto.propertyIsEnumerable;

			/**
			 * Checks if `value` is likely an `arguments` object.
			 *
			 * @static
			 * @memberOf _
			 * @since 0.1.0
			 * @category Lang
			 * @param {*} value The value to check.
			 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
			 *  else `false`.
			 * @example
			 *
			 * _.isArguments(function() { return arguments; }());
			 * // => true
			 *
			 * _.isArguments([1, 2, 3]);
			 * // => false
			 */
			_baseIsArguments(function() { return arguments; }()) ? _baseIsArguments : function(value) {
			  return isObjectLike_1(value) && hasOwnProperty.call(value, 'callee') &&
			    !propertyIsEnumerable.call(value, 'callee');
			};

			/**
			 * This method returns `false`.
			 *
			 * @static
			 * @memberOf _
			 * @since 4.13.0
			 * @category Util
			 * @returns {boolean} Returns `false`.
			 * @example
			 *
			 * _.times(2, _.stubFalse);
			 * // => [false, false]
			 */
			function stubFalse() {
			  return false;
			}

			var stubFalse_1 = stubFalse;

			createCommonjsModule(function (module, exports) {
			/** Detect free variable `exports`. */
			var freeExports = exports && !exports.nodeType && exports;

			/** Detect free variable `module`. */
			var freeModule = freeExports && 'object' == 'object' && module && !module.nodeType && module;

			/** Detect the popular CommonJS extension `module.exports`. */
			var moduleExports = freeModule && freeModule.exports === freeExports;

			/** Built-in value references. */
			var Buffer = moduleExports ? _root.Buffer : undefined;

			/* Built-in method references for those with the same name as other `lodash` methods. */
			var nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined;

			/**
			 * Checks if `value` is a buffer.
			 *
			 * @static
			 * @memberOf _
			 * @since 4.3.0
			 * @category Lang
			 * @param {*} value The value to check.
			 * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
			 * @example
			 *
			 * _.isBuffer(new Buffer(2));
			 * // => true
			 *
			 * _.isBuffer(new Uint8Array(2));
			 * // => false
			 */
			var isBuffer = nativeIsBuffer || stubFalse_1;

			module.exports = isBuffer;
			});

			var _nodeUtil = createCommonjsModule(function (module, exports) {
			/** Detect free variable `exports`. */
			var freeExports = exports && !exports.nodeType && exports;

			/** Detect free variable `module`. */
			var freeModule = freeExports && 'object' == 'object' && module && !module.nodeType && module;

			/** Detect the popular CommonJS extension `module.exports`. */
			var moduleExports = freeModule && freeModule.exports === freeExports;

			/** Detect free variable `process` from Node.js. */
			var freeProcess = moduleExports && _freeGlobal.process;

			/** Used to access faster Node.js helpers. */
			var nodeUtil = (function() {
			  try {
			    // Use `util.types` for Node.js 10+.
			    var types = freeModule && freeModule.require && freeModule.require('util').types;

			    if (types) {
			      return types;
			    }

			    // Legacy `process.binding('util')` for Node.js < 10.
			    return freeProcess && freeProcess.binding && freeProcess.binding('util');
			  } catch (e) {}
			}());

			module.exports = nodeUtil;
			});

			/* Node.js helper references. */
			_nodeUtil && _nodeUtil.isTypedArray;

			createCommonjsModule(function (module, exports) {
			/** Detect free variable `exports`. */
			var freeExports = exports && !exports.nodeType && exports;

			/** Detect free variable `module`. */
			var freeModule = freeExports && 'object' == 'object' && module && !module.nodeType && module;

			/** Detect the popular CommonJS extension `module.exports`. */
			var moduleExports = freeModule && freeModule.exports === freeExports;

			/** Built-in value references. */
			var Buffer = moduleExports ? _root.Buffer : undefined,
			    allocUnsafe = Buffer ? Buffer.allocUnsafe : undefined;

			/**
			 * Creates a clone of  `buffer`.
			 *
			 * @private
			 * @param {Buffer} buffer The buffer to clone.
			 * @param {boolean} [isDeep] Specify a deep clone.
			 * @returns {Buffer} Returns the cloned buffer.
			 */
			function cloneBuffer(buffer, isDeep) {
			  if (isDeep) {
			    return buffer.slice();
			  }
			  var length = buffer.length,
			      result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);

			  buffer.copy(result);
			  return result;
			}

			module.exports = cloneBuffer;
			});

			/* Built-in method references that are verified to be native. */
			var DataView = _getNative(_root, 'DataView');

			var _DataView = DataView;

			/* Built-in method references that are verified to be native. */
			var Promise$1 = _getNative(_root, 'Promise');

			var _Promise = Promise$1;

			/* Built-in method references that are verified to be native. */
			var Set = _getNative(_root, 'Set');

			var _Set = Set;

			/* Built-in method references that are verified to be native. */
			var WeakMap = _getNative(_root, 'WeakMap');

			var _WeakMap = WeakMap;

			/** `Object#toString` result references. */
			var mapTag = '[object Map]',
			    objectTag = '[object Object]',
			    promiseTag = '[object Promise]',
			    setTag = '[object Set]',
			    weakMapTag = '[object WeakMap]';

			var dataViewTag = '[object DataView]';

			/** Used to detect maps, sets, and weakmaps. */
			var dataViewCtorString = _toSource(_DataView),
			    mapCtorString = _toSource(_Map),
			    promiseCtorString = _toSource(_Promise),
			    setCtorString = _toSource(_Set),
			    weakMapCtorString = _toSource(_WeakMap);

			/**
			 * Gets the `toStringTag` of `value`.
			 *
			 * @private
			 * @param {*} value The value to query.
			 * @returns {string} Returns the `toStringTag`.
			 */
			var getTag = _baseGetTag;

			// Fallback for data views, maps, sets, and weak maps in IE 11 and promises in Node.js < 6.
			if ((_DataView && getTag(new _DataView(new ArrayBuffer(1))) != dataViewTag) ||
			    (_Map && getTag(new _Map) != mapTag) ||
			    (_Promise && getTag(_Promise.resolve()) != promiseTag) ||
			    (_Set && getTag(new _Set) != setTag) ||
			    (_WeakMap && getTag(new _WeakMap) != weakMapTag)) {
			  getTag = function(value) {
			    var result = _baseGetTag(value),
			        Ctor = result == objectTag ? value.constructor : undefined,
			        ctorString = Ctor ? _toSource(Ctor) : '';

			    if (ctorString) {
			      switch (ctorString) {
			        case dataViewCtorString: return dataViewTag;
			        case mapCtorString: return mapTag;
			        case promiseCtorString: return promiseTag;
			        case setCtorString: return setTag;
			        case weakMapCtorString: return weakMapTag;
			      }
			    }
			    return result;
			  };
			}

			/** Built-in value references. */
			_root.Uint8Array;

			/** Used to convert symbols to primitives and strings. */
			var symbolProto = _Symbol ? _Symbol.prototype : undefined;
			    symbolProto ? symbolProto.valueOf : undefined;

			/* Node.js helper references. */
			_nodeUtil && _nodeUtil.isMap;

			/* Node.js helper references. */
			_nodeUtil && _nodeUtil.isSet;

			var ProcessState;
			(function (ProcessState) {
			    ProcessState[ProcessState["wait"] = 0] = "wait";
			    ProcessState[ProcessState["pass"] = 1] = "pass";
			})(ProcessState || (ProcessState = {}));

			var EventPhase;
			(function (EventPhase) {
			    EventPhase[EventPhase["NONE"] = 0] = "NONE";
			    EventPhase[EventPhase["CAPTURING_PHASE"] = 1] = "CAPTURING_PHASE";
			    EventPhase[EventPhase["AT_TARGET"] = 2] = "AT_TARGET";
			    EventPhase[EventPhase["BUBBLING_PHASE"] = 3] = "BUBBLING_PHASE";
			})(EventPhase || (EventPhase = {}));
			var EventType;
			(function (EventType) {
			    EventType["touchstart"] = "touchstart";
			    EventType["touchmove"] = "touchmove";
			    EventType["touchcancel"] = "touchcancel";
			    EventType["touchend"] = "touchend";
			    EventType["tap"] = "tap";
			    EventType["longpress"] = "longpress";
			    EventType["longtap"] = "longtap";
			    EventType["transitionend"] = "transitionend";
			    EventType["touchforcechange"] = "touchforcechange";
			    EventType["updateProps"] = "lite.updateProps";
			})(EventType || (EventType = {}));

			var NodeType;
			(function (NodeType) {
			    NodeType[NodeType["element"] = 1] = "element";
			    NodeType[NodeType["text"] = 3] = "text";
			    NodeType[NodeType["comment"] = 8] = "comment";
			})(NodeType || (NodeType = {}));

			var UnitType;
			(function (UnitType) {
			    UnitType[UnitType["open"] = 0] = "open";
			    UnitType[UnitType["self"] = 1] = "self";
			    UnitType[UnitType["end"] = 2] = "end";
			    UnitType[UnitType["text"] = 3] = "text";
			    UnitType[UnitType["comment"] = 4] = "comment";
			})(UnitType || (UnitType = {}));

			var TagName;
			(function (TagName) {
			    TagName["div"] = "div";
			    TagName["body"] = "body";
			    TagName["head"] = "head";
			    TagName["style"] = "style";
			    TagName["document"] = "document";
			})(TagName || (TagName = {}));

			[TagName.style];

			var PerformanceMark;
			(function (PerformanceMark) {
			    PerformanceMark["liteSnapshotReadStart"] = "liteSnapshotReadStart";
			    PerformanceMark["liteSnapshotReadEnd"] = "liteSnapshotReadEnd";
			    PerformanceMark["liteSnapshotApplyStart"] = "liteSnapshotApplyStart";
			    PerformanceMark["liteSnapshotApplyEnd"] = "liteSnapshotApplyEnd";
			})(PerformanceMark || (PerformanceMark = {}));

		}
	};
});

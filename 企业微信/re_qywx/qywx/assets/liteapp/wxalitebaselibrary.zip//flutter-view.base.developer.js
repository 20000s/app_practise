System.register([], function (exports) {
	'use strict';
	return {
		execute: function () {

			exports({
				K: createCommonjsModule,
				M: unwrapExports,
				a: getGlobalThis,
				g: getGlobal
			});

			var commonjsGlobal = exports('J', typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {});

			function unwrapExports (x) {
				return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
			}

			function createCommonjsModule(fn, module) {
				return module = { exports: {} }, fn(module, module.exports), module.exports;
			}

			var check = function (it) {
			  return it && it.Math == Math && it;
			};

			// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
			var global_1 =
			  exports('f', // eslint-disable-next-line es/no-global-this -- safe
			  check(typeof globalThis == 'object' && globalThis) ||
			  check(typeof window == 'object' && window) ||
			  // eslint-disable-next-line no-restricted-globals -- safe
			  check(typeof self == 'object' && self) ||
			  check(typeof commonjsGlobal == 'object' && commonjsGlobal) ||
			  // eslint-disable-next-line no-new-func -- fallback
			  (function () { return this; })() || Function('return this')());

			var fails = exports('p', function (exec) {
			  try {
			    return !!exec();
			  } catch (error) {
			    return true;
			  }
			});

			// Detect IE8's incomplete defineProperty implementation
			var descriptors = exports('k', !fails(function () {
			  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
			  return Object.defineProperty({}, 1, { get: function () { return 7; } })[1] != 7;
			}));

			var $propertyIsEnumerable = {}.propertyIsEnumerable;
			// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
			var getOwnPropertyDescriptor$1 = Object.getOwnPropertyDescriptor;

			// Nashorn ~ JDK8 bug
			var NASHORN_BUG = getOwnPropertyDescriptor$1 && !$propertyIsEnumerable.call({ 1: 2 }, 1);

			// `Object.prototype.propertyIsEnumerable` method implementation
			// https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
			var f$5 = NASHORN_BUG ? function propertyIsEnumerable(V) {
			  var descriptor = getOwnPropertyDescriptor$1(this, V);
			  return !!descriptor && descriptor.enumerable;
			} : $propertyIsEnumerable;

			var objectPropertyIsEnumerable = {
				f: f$5
			};

			var createPropertyDescriptor = exports('c', function (bitmap, value) {
			  return {
			    enumerable: !(bitmap & 1),
			    configurable: !(bitmap & 2),
			    writable: !(bitmap & 4),
			    value: value
			  };
			});

			var toString = {}.toString;

			var classofRaw = exports('m', function (it) {
			  return toString.call(it).slice(8, -1);
			});

			var split = ''.split;

			// fallback for non-array-like ES3 and non-enumerable old V8 strings
			var indexedObject = fails(function () {
			  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
			  // eslint-disable-next-line no-prototype-builtins -- safe
			  return !Object('z').propertyIsEnumerable(0);
			}) ? function (it) {
			  return classofRaw(it) == 'String' ? split.call(it, '') : Object(it);
			} : Object;

			// `RequireObjectCoercible` abstract operation
			// https://tc39.es/ecma262/#sec-requireobjectcoercible
			var requireObjectCoercible = function (it) {
			  if (it == undefined) throw TypeError("Can't call method on " + it);
			  return it;
			};

			// toObject with fallback for non-array-like ES3 strings



			var toIndexedObject = function (it) {
			  return indexedObject(requireObjectCoercible(it));
			};

			var isObject = exports('x', function (it) {
			  return typeof it === 'object' ? it !== null : typeof it === 'function';
			});

			var aFunction$1 = function (variable) {
			  return typeof variable == 'function' ? variable : undefined;
			};

			var getBuiltIn = exports('h', function (namespace, method) {
			  return arguments.length < 2 ? aFunction$1(global_1[namespace]) : global_1[namespace] && global_1[namespace][method];
			});

			var engineUserAgent = exports('l', getBuiltIn('navigator', 'userAgent') || '');

			var process = global_1.process;
			var Deno = global_1.Deno;
			var versions = process && process.versions || Deno && Deno.version;
			var v8 = versions && versions.v8;
			var match, version;

			if (v8) {
			  match = v8.split('.');
			  version = match[0] < 4 ? 1 : match[0] + match[1];
			} else if (engineUserAgent) {
			  match = engineUserAgent.match(/Edge\/(\d+)/);
			  if (!match || match[1] >= 74) {
			    match = engineUserAgent.match(/Chrome\/(\d+)/);
			    if (match) version = match[1];
			  }
			}

			var engineV8Version = exports('D', version && +version);

			/* eslint-disable es/no-symbol -- required for testing */



			// eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
			var nativeSymbol = !!Object.getOwnPropertySymbols && !fails(function () {
			  var symbol = Symbol();
			  // Chrome 38 Symbol has incorrect toString conversion
			  // `get-own-property-symbols` polyfill symbols converted to object are not Symbol instances
			  return !String(symbol) || !(Object(symbol) instanceof Symbol) ||
			    // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
			    !Symbol.sham && engineV8Version && engineV8Version < 41;
			});

			/* eslint-disable es/no-symbol -- required for testing */


			var useSymbolAsUid = nativeSymbol
			  && !Symbol.sham
			  && typeof Symbol.iterator == 'symbol';

			var isSymbol = useSymbolAsUid ? function (it) {
			  return typeof it == 'symbol';
			} : function (it) {
			  var $Symbol = getBuiltIn('Symbol');
			  return typeof $Symbol == 'function' && Object(it) instanceof $Symbol;
			};

			// `OrdinaryToPrimitive` abstract operation
			// https://tc39.es/ecma262/#sec-ordinarytoprimitive
			var ordinaryToPrimitive = function (input, pref) {
			  var fn, val;
			  if (pref === 'string' && typeof (fn = input.toString) == 'function' && !isObject(val = fn.call(input))) return val;
			  if (typeof (fn = input.valueOf) == 'function' && !isObject(val = fn.call(input))) return val;
			  if (pref !== 'string' && typeof (fn = input.toString) == 'function' && !isObject(val = fn.call(input))) return val;
			  throw TypeError("Can't convert object to primitive value");
			};

			var isPure = false;

			var setGlobal = function (key, value) {
			  try {
			    // eslint-disable-next-line es/no-object-defineproperty -- safe
			    Object.defineProperty(global_1, key, { value: value, configurable: true, writable: true });
			  } catch (error) {
			    global_1[key] = value;
			  } return value;
			};

			var SHARED = '__core-js_shared__';
			var store$1 = global_1[SHARED] || setGlobal(SHARED, {});

			var sharedStore = store$1;

			var shared = createCommonjsModule(function (module) {
			(module.exports = function (key, value) {
			  return sharedStore[key] || (sharedStore[key] = value !== undefined ? value : {});
			})('versions', []).push({
			  version: '3.16.1',
			  mode: 'global',
			  copyright: '© 2021 Denis Pushkarev (zloirock.ru)'
			});
			});

			// `ToObject` abstract operation
			// https://tc39.es/ecma262/#sec-toobject
			var toObject = function (argument) {
			  return Object(requireObjectCoercible(argument));
			};

			var hasOwnProperty = {}.hasOwnProperty;

			var has$2 = Object.hasOwn || function hasOwn(it, key) {
			  return hasOwnProperty.call(toObject(it), key);
			};

			var id = 0;
			var postfix = Math.random();

			var uid = function (key) {
			  return 'Symbol(' + String(key === undefined ? '' : key) + ')_' + (++id + postfix).toString(36);
			};

			var WellKnownSymbolsStore = shared('wks');
			var Symbol$1 = global_1.Symbol;
			var createWellKnownSymbol = useSymbolAsUid ? Symbol$1 : Symbol$1 && Symbol$1.withoutSetter || uid;

			var wellKnownSymbol = exports('w', function (name) {
			  if (!has$2(WellKnownSymbolsStore, name) || !(nativeSymbol || typeof WellKnownSymbolsStore[name] == 'string')) {
			    if (nativeSymbol && has$2(Symbol$1, name)) {
			      WellKnownSymbolsStore[name] = Symbol$1[name];
			    } else {
			      WellKnownSymbolsStore[name] = createWellKnownSymbol('Symbol.' + name);
			    }
			  } return WellKnownSymbolsStore[name];
			});

			var TO_PRIMITIVE = wellKnownSymbol('toPrimitive');

			// `ToPrimitive` abstract operation
			// https://tc39.es/ecma262/#sec-toprimitive
			var toPrimitive = function (input, pref) {
			  if (!isObject(input) || isSymbol(input)) return input;
			  var exoticToPrim = input[TO_PRIMITIVE];
			  var result;
			  if (exoticToPrim !== undefined) {
			    if (pref === undefined) pref = 'default';
			    result = exoticToPrim.call(input, pref);
			    if (!isObject(result) || isSymbol(result)) return result;
			    throw TypeError("Can't convert object to primitive value");
			  }
			  if (pref === undefined) pref = 'number';
			  return ordinaryToPrimitive(input, pref);
			};

			// `ToPropertyKey` abstract operation
			// https://tc39.es/ecma262/#sec-topropertykey
			var toPropertyKey = function (argument) {
			  var key = toPrimitive(argument, 'string');
			  return isSymbol(key) ? key : String(key);
			};

			var document$1 = global_1.document;
			// typeof document.createElement is 'object' in old IE
			var EXISTS = isObject(document$1) && isObject(document$1.createElement);

			var documentCreateElement = exports('q', function (it) {
			  return EXISTS ? document$1.createElement(it) : {};
			});

			// Thank's IE8 for his funny defineProperty
			var ie8DomDefine = !descriptors && !fails(function () {
			  // eslint-disable-next-line es/no-object-defineproperty -- requied for testing
			  return Object.defineProperty(documentCreateElement('div'), 'a', {
			    get: function () { return 7; }
			  }).a != 7;
			});

			// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
			var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

			// `Object.getOwnPropertyDescriptor` method
			// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
			var f$4 = descriptors ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
			  O = toIndexedObject(O);
			  P = toPropertyKey(P);
			  if (ie8DomDefine) try {
			    return $getOwnPropertyDescriptor(O, P);
			  } catch (error) { /* empty */ }
			  if (has$2(O, P)) return createPropertyDescriptor(!objectPropertyIsEnumerable.f.call(O, P), O[P]);
			};

			var objectGetOwnPropertyDescriptor = exports('s', {
				f: f$4
			});

			var anObject = exports('v', function (it) {
			  if (!isObject(it)) {
			    throw TypeError(String(it) + ' is not an object');
			  } return it;
			});

			// eslint-disable-next-line es/no-object-defineproperty -- safe
			var $defineProperty = Object.defineProperty;

			// `Object.defineProperty` method
			// https://tc39.es/ecma262/#sec-object.defineproperty
			var f$3 = descriptors ? $defineProperty : function defineProperty(O, P, Attributes) {
			  anObject(O);
			  P = toPropertyKey(P);
			  anObject(Attributes);
			  if (ie8DomDefine) try {
			    return $defineProperty(O, P, Attributes);
			  } catch (error) { /* empty */ }
			  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported');
			  if ('value' in Attributes) O[P] = Attributes.value;
			  return O;
			};

			var objectDefineProperty = exports('j', {
				f: f$3
			});

			var createNonEnumerableProperty = exports('e', descriptors ? function (object, key, value) {
			  return objectDefineProperty.f(object, key, createPropertyDescriptor(1, value));
			} : function (object, key, value) {
			  object[key] = value;
			  return object;
			});

			var functionToString = Function.toString;

			// this helper broken in `core-js@3.4.1-3.4.4`, so we can't use `shared` helper
			if (typeof sharedStore.inspectSource != 'function') {
			  sharedStore.inspectSource = function (it) {
			    return functionToString.call(it);
			  };
			}

			var inspectSource = exports('C', sharedStore.inspectSource);

			var WeakMap$1 = global_1.WeakMap;

			var nativeWeakMap = typeof WeakMap$1 === 'function' && /native code/.test(inspectSource(WeakMap$1));

			var keys = shared('keys');

			var sharedKey = function (key) {
			  return keys[key] || (keys[key] = uid(key));
			};

			var hiddenKeys$1 = {};

			var OBJECT_ALREADY_INITIALIZED = 'Object already initialized';
			var WeakMap = global_1.WeakMap;
			var set, get, has$1;

			var enforce = function (it) {
			  return has$1(it) ? get(it) : set(it, {});
			};

			var getterFor = function (TYPE) {
			  return function (it) {
			    var state;
			    if (!isObject(it) || (state = get(it)).type !== TYPE) {
			      throw TypeError('Incompatible receiver, ' + TYPE + ' required');
			    } return state;
			  };
			};

			if (nativeWeakMap || sharedStore.state) {
			  var store = sharedStore.state || (sharedStore.state = new WeakMap());
			  var wmget = store.get;
			  var wmhas = store.has;
			  var wmset = store.set;
			  set = function (it, metadata) {
			    if (wmhas.call(store, it)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
			    metadata.facade = it;
			    wmset.call(store, it, metadata);
			    return metadata;
			  };
			  get = function (it) {
			    return wmget.call(store, it) || {};
			  };
			  has$1 = function (it) {
			    return wmhas.call(store, it);
			  };
			} else {
			  var STATE = sharedKey('state');
			  hiddenKeys$1[STATE] = true;
			  set = function (it, metadata) {
			    if (has$2(it, STATE)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
			    metadata.facade = it;
			    createNonEnumerableProperty(it, STATE, metadata);
			    return metadata;
			  };
			  get = function (it) {
			    return has$2(it, STATE) ? it[STATE] : {};
			  };
			  has$1 = function (it) {
			    return has$2(it, STATE);
			  };
			}

			var internalState = exports('G', {
			  set: set,
			  get: get,
			  has: has$1,
			  enforce: enforce,
			  getterFor: getterFor
			});

			var redefine = exports('A', createCommonjsModule(function (module) {
			var getInternalState = internalState.get;
			var enforceInternalState = internalState.enforce;
			var TEMPLATE = String(String).split('String');

			(module.exports = function (O, key, value, options) {
			  var unsafe = options ? !!options.unsafe : false;
			  var simple = options ? !!options.enumerable : false;
			  var noTargetGet = options ? !!options.noTargetGet : false;
			  var state;
			  if (typeof value == 'function') {
			    if (typeof key == 'string' && !has$2(value, 'name')) {
			      createNonEnumerableProperty(value, 'name', key);
			    }
			    state = enforceInternalState(value);
			    if (!state.source) {
			      state.source = TEMPLATE.join(typeof key == 'string' ? key : '');
			    }
			  }
			  if (O === global_1) {
			    if (simple) O[key] = value;
			    else setGlobal(key, value);
			    return;
			  } else if (!unsafe) {
			    delete O[key];
			  } else if (!noTargetGet && O[key]) {
			    simple = true;
			  }
			  if (simple) O[key] = value;
			  else createNonEnumerableProperty(O, key, value);
			// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
			})(Function.prototype, 'toString', function toString() {
			  return typeof this == 'function' && getInternalState(this).source || inspectSource(this);
			});
			}));

			var ceil$1 = Math.ceil;
			var floor$2 = Math.floor;

			// `ToInteger` abstract operation
			// https://tc39.es/ecma262/#sec-tointeger
			var toInteger = function (argument) {
			  return isNaN(argument = +argument) ? 0 : (argument > 0 ? floor$2 : ceil$1)(argument);
			};

			var min$1 = Math.min;

			// `ToLength` abstract operation
			// https://tc39.es/ecma262/#sec-tolength
			var toLength = function (argument) {
			  return argument > 0 ? min$1(toInteger(argument), 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
			};

			var max = Math.max;
			var min = Math.min;

			// Helper for a popular repeating case of the spec:
			// Let integer be ? ToInteger(index).
			// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
			var toAbsoluteIndex = function (index, length) {
			  var integer = toInteger(index);
			  return integer < 0 ? max(integer + length, 0) : min(integer, length);
			};

			// `Array.prototype.{ indexOf, includes }` methods implementation
			var createMethod$4 = function (IS_INCLUDES) {
			  return function ($this, el, fromIndex) {
			    var O = toIndexedObject($this);
			    var length = toLength(O.length);
			    var index = toAbsoluteIndex(fromIndex, length);
			    var value;
			    // Array#includes uses SameValueZero equality algorithm
			    // eslint-disable-next-line no-self-compare -- NaN check
			    if (IS_INCLUDES && el != el) while (length > index) {
			      value = O[index++];
			      // eslint-disable-next-line no-self-compare -- NaN check
			      if (value != value) return true;
			    // Array#indexOf ignores holes, Array#includes - not
			    } else for (;length > index; index++) {
			      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
			    } return !IS_INCLUDES && -1;
			  };
			};

			var arrayIncludes = {
			  // `Array.prototype.includes` method
			  // https://tc39.es/ecma262/#sec-array.prototype.includes
			  includes: createMethod$4(true),
			  // `Array.prototype.indexOf` method
			  // https://tc39.es/ecma262/#sec-array.prototype.indexof
			  indexOf: createMethod$4(false)
			};

			var indexOf = arrayIncludes.indexOf;


			var objectKeysInternal = function (object, names) {
			  var O = toIndexedObject(object);
			  var i = 0;
			  var result = [];
			  var key;
			  for (key in O) !has$2(hiddenKeys$1, key) && has$2(O, key) && result.push(key);
			  // Don't enum bug & hidden keys
			  while (names.length > i) if (has$2(O, key = names[i++])) {
			    ~indexOf(result, key) || result.push(key);
			  }
			  return result;
			};

			// IE8- don't enum bug keys
			var enumBugKeys = [
			  'constructor',
			  'hasOwnProperty',
			  'isPrototypeOf',
			  'propertyIsEnumerable',
			  'toLocaleString',
			  'toString',
			  'valueOf'
			];

			var hiddenKeys = enumBugKeys.concat('length', 'prototype');

			// `Object.getOwnPropertyNames` method
			// https://tc39.es/ecma262/#sec-object.getownpropertynames
			// eslint-disable-next-line es/no-object-getownpropertynames -- safe
			var f$2 = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
			  return objectKeysInternal(O, hiddenKeys);
			};

			var objectGetOwnPropertyNames = {
				f: f$2
			};

			// eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
			var f$1 = Object.getOwnPropertySymbols;

			var objectGetOwnPropertySymbols = {
				f: f$1
			};

			// all object keys, includes non-enumerable and symbols
			var ownKeys = getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
			  var keys = objectGetOwnPropertyNames.f(anObject(it));
			  var getOwnPropertySymbols = objectGetOwnPropertySymbols.f;
			  return getOwnPropertySymbols ? keys.concat(getOwnPropertySymbols(it)) : keys;
			};

			var copyConstructorProperties = function (target, source) {
			  var keys = ownKeys(source);
			  var defineProperty = objectDefineProperty.f;
			  var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
			  for (var i = 0; i < keys.length; i++) {
			    var key = keys[i];
			    if (!has$2(target, key)) defineProperty(target, key, getOwnPropertyDescriptor(source, key));
			  }
			};

			var replacement = /#|\.prototype\./;

			var isForced = function (feature, detection) {
			  var value = data[normalize(feature)];
			  return value == POLYFILL ? true
			    : value == NATIVE ? false
			    : typeof detection == 'function' ? fails(detection)
			    : !!detection;
			};

			var normalize = isForced.normalize = function (string) {
			  return String(string).replace(replacement, '.').toLowerCase();
			};

			var data = isForced.data = {};
			var NATIVE = isForced.NATIVE = 'N';
			var POLYFILL = isForced.POLYFILL = 'P';

			var isForced_1 = exports('y', isForced);

			var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;






			/*
			  options.target      - name of the target object
			  options.global      - target is the global object
			  options.stat        - export as static methods of target
			  options.proto       - export as prototype methods of target
			  options.real        - real prototype method for the `pure` version
			  options.forced      - export even if the native feature is available
			  options.bind        - bind methods to the target, required for the `pure` version
			  options.wrap        - wrap constructors to preventing global pollution, required for the `pure` version
			  options.unsafe      - use the simple assignment of property instead of delete + defineProperty
			  options.sham        - add a flag to not completely full polyfills
			  options.enumerable  - export as enumerable property
			  options.noTargetGet - prevent calling a getter on target
			*/
			var _export = exports('_', function (options, source) {
			  var TARGET = options.target;
			  var GLOBAL = options.global;
			  var STATIC = options.stat;
			  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
			  if (GLOBAL) {
			    target = global_1;
			  } else if (STATIC) {
			    target = global_1[TARGET] || setGlobal(TARGET, {});
			  } else {
			    target = (global_1[TARGET] || {}).prototype;
			  }
			  if (target) for (key in source) {
			    sourceProperty = source[key];
			    if (options.noTargetGet) {
			      descriptor = getOwnPropertyDescriptor(target, key);
			      targetProperty = descriptor && descriptor.value;
			    } else targetProperty = target[key];
			    FORCED = isForced_1(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
			    // contained in target
			    if (!FORCED && targetProperty !== undefined) {
			      if (typeof sourceProperty === typeof targetProperty) continue;
			      copyConstructorProperties(sourceProperty, targetProperty);
			    }
			    // add a flag to not completely full polyfills
			    if (options.sham || (targetProperty && targetProperty.sham)) {
			      createNonEnumerableProperty(sourceProperty, 'sham', true);
			    }
			    // extend global
			    redefine(target, key, sourceProperty, options);
			  }
			});

			// `Object.keys` method
			// https://tc39.es/ecma262/#sec-object.keys
			// eslint-disable-next-line es/no-object-keys -- safe
			var objectKeys$1 = Object.keys || function keys(O) {
			  return objectKeysInternal(O, enumBugKeys);
			};

			// `Object.defineProperties` method
			// https://tc39.es/ecma262/#sec-object.defineproperties
			// eslint-disable-next-line es/no-object-defineproperties -- safe
			var objectDefineProperties = descriptors ? Object.defineProperties : function defineProperties(O, Properties) {
			  anObject(O);
			  var keys = objectKeys$1(Properties);
			  var length = keys.length;
			  var index = 0;
			  var key;
			  while (length > index) objectDefineProperty.f(O, key = keys[index++], Properties[key]);
			  return O;
			};

			var html = exports('r', getBuiltIn('document', 'documentElement'));

			/* global ActiveXObject -- old IE, WSH */








			var GT = '>';
			var LT = '<';
			var PROTOTYPE = 'prototype';
			var SCRIPT = 'script';
			var IE_PROTO$1 = sharedKey('IE_PROTO');

			var EmptyConstructor = function () { /* empty */ };

			var scriptTag = function (content) {
			  return LT + SCRIPT + GT + content + LT + '/' + SCRIPT + GT;
			};

			// Create object with fake `null` prototype: use ActiveX Object with cleared prototype
			var NullProtoObjectViaActiveX = function (activeXDocument) {
			  activeXDocument.write(scriptTag(''));
			  activeXDocument.close();
			  var temp = activeXDocument.parentWindow.Object;
			  activeXDocument = null; // avoid memory leak
			  return temp;
			};

			// Create object with fake `null` prototype: use iframe Object with cleared prototype
			var NullProtoObjectViaIFrame = function () {
			  // Thrash, waste and sodomy: IE GC bug
			  var iframe = documentCreateElement('iframe');
			  var JS = 'java' + SCRIPT + ':';
			  var iframeDocument;
			  if (iframe.style) {
			    iframe.style.display = 'none';
			    html.appendChild(iframe);
			    // https://github.com/zloirock/core-js/issues/475
			    iframe.src = String(JS);
			    iframeDocument = iframe.contentWindow.document;
			    iframeDocument.open();
			    iframeDocument.write(scriptTag('document.F=Object'));
			    iframeDocument.close();
			    return iframeDocument.F;
			  }
			};

			// Check for document.domain and active x support
			// No need to use active x approach when document.domain is not set
			// see https://github.com/es-shims/es5-shim/issues/150
			// variation of https://github.com/kitcambridge/es5-shim/commit/4f738ac066346
			// avoid IE GC bug
			var activeXDocument;
			var NullProtoObject = function () {
			  try {
			    activeXDocument = new ActiveXObject('htmlfile');
			  } catch (error) { /* ignore */ }
			  NullProtoObject = document.domain && activeXDocument ?
			    NullProtoObjectViaActiveX(activeXDocument) : // old IE
			    NullProtoObjectViaIFrame() ||
			    NullProtoObjectViaActiveX(activeXDocument); // WSH
			  var length = enumBugKeys.length;
			  while (length--) delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
			  return NullProtoObject();
			};

			hiddenKeys$1[IE_PROTO$1] = true;

			// `Object.create` method
			// https://tc39.es/ecma262/#sec-object.create
			var objectCreate = exports('o', Object.create || function create(O, Properties) {
			  var result;
			  if (O !== null) {
			    EmptyConstructor[PROTOTYPE] = anObject(O);
			    result = new EmptyConstructor();
			    EmptyConstructor[PROTOTYPE] = null;
			    // add "__proto__" for Object.getPrototypeOf polyfill
			    result[IE_PROTO$1] = O;
			  } else result = NullProtoObject();
			  return Properties === undefined ? result : objectDefineProperties(result, Properties);
			});

			var UNSCOPABLES = wellKnownSymbol('unscopables');
			var ArrayPrototype$1 = Array.prototype;

			// Array.prototype[@@unscopables]
			// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
			if (ArrayPrototype$1[UNSCOPABLES] == undefined) {
			  objectDefineProperty.f(ArrayPrototype$1, UNSCOPABLES, {
			    configurable: true,
			    value: objectCreate(null)
			  });
			}

			// add a key to Array.prototype[@@unscopables]
			var addToUnscopables = function (key) {
			  ArrayPrototype$1[UNSCOPABLES][key] = true;
			};

			var $includes$1 = arrayIncludes.includes;


			// `Array.prototype.includes` method
			// https://tc39.es/ecma262/#sec-array.prototype.includes
			_export({ target: 'Array', proto: true }, {
			  includes: function includes(el /* , fromIndex = 0 */) {
			    return $includes$1(this, el, arguments.length > 1 ? arguments[1] : undefined);
			  }
			});

			// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
			addToUnscopables('includes');

			var aFunction = exports('u', function (it) {
			  if (typeof it != 'function') {
			    throw TypeError(String(it) + ' is not a function');
			  } return it;
			});

			// optional / simple context binding
			var functionBindContext = exports('n', function (fn, that, length) {
			  aFunction(fn);
			  if (that === undefined) return fn;
			  switch (length) {
			    case 0: return function () {
			      return fn.call(that);
			    };
			    case 1: return function (a) {
			      return fn.call(that, a);
			    };
			    case 2: return function (a, b) {
			      return fn.call(that, a, b);
			    };
			    case 3: return function (a, b, c) {
			      return fn.call(that, a, b, c);
			    };
			  }
			  return function (/* ...args */) {
			    return fn.apply(that, arguments);
			  };
			});

			var call = Function.call;

			var entryUnbind = function (CONSTRUCTOR, METHOD, length) {
			  return functionBindContext(call, global_1[CONSTRUCTOR].prototype[METHOD], length);
			};

			entryUnbind('Array', 'includes');

			// eslint-disable-next-line es/no-typed-arrays -- safe
			var arrayBufferNative = typeof ArrayBuffer !== 'undefined' && typeof DataView !== 'undefined';

			var TO_STRING_TAG$3 = wellKnownSymbol('toStringTag');
			var test = {};

			test[TO_STRING_TAG$3] = 'z';

			var toStringTagSupport = String(test) === '[object z]';

			var TO_STRING_TAG$2 = wellKnownSymbol('toStringTag');
			// ES3 wrong here
			var CORRECT_ARGUMENTS = classofRaw(function () { return arguments; }()) == 'Arguments';

			// fallback for IE11 Script Access Denied error
			var tryGet = function (it, key) {
			  try {
			    return it[key];
			  } catch (error) { /* empty */ }
			};

			// getting tag from ES6+ `Object.prototype.toString`
			var classof = toStringTagSupport ? classofRaw : function (it) {
			  var O, tag, result;
			  return it === undefined ? 'Undefined' : it === null ? 'Null'
			    // @@toStringTag case
			    : typeof (tag = tryGet(O = Object(it), TO_STRING_TAG$2)) == 'string' ? tag
			    // builtinTag case
			    : CORRECT_ARGUMENTS ? classofRaw(O)
			    // ES3 arguments fallback
			    : (result = classofRaw(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : result;
			};

			var correctPrototypeGetter = !fails(function () {
			  function F() { /* empty */ }
			  F.prototype.constructor = null;
			  // eslint-disable-next-line es/no-object-getprototypeof -- required for testing
			  return Object.getPrototypeOf(new F()) !== F.prototype;
			});

			var IE_PROTO = sharedKey('IE_PROTO');
			var ObjectPrototype$1 = Object.prototype;

			// `Object.getPrototypeOf` method
			// https://tc39.es/ecma262/#sec-object.getprototypeof
			// eslint-disable-next-line es/no-object-getprototypeof -- safe
			var objectGetPrototypeOf = exports('d', correctPrototypeGetter ? Object.getPrototypeOf : function (O) {
			  O = toObject(O);
			  if (has$2(O, IE_PROTO)) return O[IE_PROTO];
			  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
			    return O.constructor.prototype;
			  } return O instanceof Object ? ObjectPrototype$1 : null;
			});

			var aPossiblePrototype = function (it) {
			  if (!isObject(it) && it !== null) {
			    throw TypeError("Can't set " + String(it) + ' as a prototype');
			  } return it;
			};

			/* eslint-disable no-proto -- safe */



			// `Object.setPrototypeOf` method
			// https://tc39.es/ecma262/#sec-object.setprototypeof
			// Works with __proto__ only. Old v8 can't work with null proto objects.
			// eslint-disable-next-line es/no-object-setprototypeof -- safe
			var objectSetPrototypeOf = exports('b', Object.setPrototypeOf || ('__proto__' in {} ? function () {
			  var CORRECT_SETTER = false;
			  var test = {};
			  var setter;
			  try {
			    // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
			    setter = Object.getOwnPropertyDescriptor(Object.prototype, '__proto__').set;
			    setter.call(test, []);
			    CORRECT_SETTER = test instanceof Array;
			  } catch (error) { /* empty */ }
			  return function setPrototypeOf(O, proto) {
			    anObject(O);
			    aPossiblePrototype(proto);
			    if (CORRECT_SETTER) setter.call(O, proto);
			    else O.__proto__ = proto;
			    return O;
			  };
			}() : undefined));

			var defineProperty$5 = objectDefineProperty.f;





			var Int8Array = global_1.Int8Array;
			var Int8ArrayPrototype = Int8Array && Int8Array.prototype;
			var Uint8ClampedArray = global_1.Uint8ClampedArray;
			var Uint8ClampedArrayPrototype = Uint8ClampedArray && Uint8ClampedArray.prototype;
			var TypedArray = Int8Array && objectGetPrototypeOf(Int8Array);
			var TypedArrayPrototype = Int8ArrayPrototype && objectGetPrototypeOf(Int8ArrayPrototype);
			var ObjectPrototype = Object.prototype;
			var isPrototypeOf = ObjectPrototype.isPrototypeOf;

			var TO_STRING_TAG$1 = wellKnownSymbol('toStringTag');
			var TYPED_ARRAY_TAG = uid('TYPED_ARRAY_TAG');
			var TYPED_ARRAY_CONSTRUCTOR = uid('TYPED_ARRAY_CONSTRUCTOR');
			// Fixing native typed arrays in Opera Presto crashes the browser, see #595
			var NATIVE_ARRAY_BUFFER_VIEWS = arrayBufferNative && !!objectSetPrototypeOf && classof(global_1.opera) !== 'Opera';
			var TYPED_ARRAY_TAG_REQIRED = false;
			var NAME, Constructor, Prototype;

			var TypedArrayConstructorsList = {
			  Int8Array: 1,
			  Uint8Array: 1,
			  Uint8ClampedArray: 1,
			  Int16Array: 2,
			  Uint16Array: 2,
			  Int32Array: 4,
			  Uint32Array: 4,
			  Float32Array: 4,
			  Float64Array: 8
			};

			var BigIntArrayConstructorsList = {
			  BigInt64Array: 8,
			  BigUint64Array: 8
			};

			var isView = function isView(it) {
			  if (!isObject(it)) return false;
			  var klass = classof(it);
			  return klass === 'DataView'
			    || has$2(TypedArrayConstructorsList, klass)
			    || has$2(BigIntArrayConstructorsList, klass);
			};

			var isTypedArray = function (it) {
			  if (!isObject(it)) return false;
			  var klass = classof(it);
			  return has$2(TypedArrayConstructorsList, klass)
			    || has$2(BigIntArrayConstructorsList, klass);
			};

			var aTypedArray$1 = function (it) {
			  if (isTypedArray(it)) return it;
			  throw TypeError('Target is not a typed array');
			};

			var aTypedArrayConstructor = function (C) {
			  if (objectSetPrototypeOf && !isPrototypeOf.call(TypedArray, C)) {
			    throw TypeError('Target is not a typed array constructor');
			  } return C;
			};

			var exportTypedArrayMethod$1 = function (KEY, property, forced) {
			  if (!descriptors) return;
			  if (forced) for (var ARRAY in TypedArrayConstructorsList) {
			    var TypedArrayConstructor = global_1[ARRAY];
			    if (TypedArrayConstructor && has$2(TypedArrayConstructor.prototype, KEY)) try {
			      delete TypedArrayConstructor.prototype[KEY];
			    } catch (error) { /* empty */ }
			  }
			  if (!TypedArrayPrototype[KEY] || forced) {
			    redefine(TypedArrayPrototype, KEY, forced ? property
			      : NATIVE_ARRAY_BUFFER_VIEWS && Int8ArrayPrototype[KEY] || property);
			  }
			};

			var exportTypedArrayStaticMethod = function (KEY, property, forced) {
			  var ARRAY, TypedArrayConstructor;
			  if (!descriptors) return;
			  if (objectSetPrototypeOf) {
			    if (forced) for (ARRAY in TypedArrayConstructorsList) {
			      TypedArrayConstructor = global_1[ARRAY];
			      if (TypedArrayConstructor && has$2(TypedArrayConstructor, KEY)) try {
			        delete TypedArrayConstructor[KEY];
			      } catch (error) { /* empty */ }
			    }
			    if (!TypedArray[KEY] || forced) {
			      // V8 ~ Chrome 49-50 `%TypedArray%` methods are non-writable non-configurable
			      try {
			        return redefine(TypedArray, KEY, forced ? property : NATIVE_ARRAY_BUFFER_VIEWS && TypedArray[KEY] || property);
			      } catch (error) { /* empty */ }
			    } else return;
			  }
			  for (ARRAY in TypedArrayConstructorsList) {
			    TypedArrayConstructor = global_1[ARRAY];
			    if (TypedArrayConstructor && (!TypedArrayConstructor[KEY] || forced)) {
			      redefine(TypedArrayConstructor, KEY, property);
			    }
			  }
			};

			for (NAME in TypedArrayConstructorsList) {
			  Constructor = global_1[NAME];
			  Prototype = Constructor && Constructor.prototype;
			  if (Prototype) createNonEnumerableProperty(Prototype, TYPED_ARRAY_CONSTRUCTOR, Constructor);
			  else NATIVE_ARRAY_BUFFER_VIEWS = false;
			}

			for (NAME in BigIntArrayConstructorsList) {
			  Constructor = global_1[NAME];
			  Prototype = Constructor && Constructor.prototype;
			  if (Prototype) createNonEnumerableProperty(Prototype, TYPED_ARRAY_CONSTRUCTOR, Constructor);
			}

			// WebKit bug - typed arrays constructors prototype is Object.prototype
			if (!NATIVE_ARRAY_BUFFER_VIEWS || typeof TypedArray != 'function' || TypedArray === Function.prototype) {
			  // eslint-disable-next-line no-shadow -- safe
			  TypedArray = function TypedArray() {
			    throw TypeError('Incorrect invocation');
			  };
			  if (NATIVE_ARRAY_BUFFER_VIEWS) for (NAME in TypedArrayConstructorsList) {
			    if (global_1[NAME]) objectSetPrototypeOf(global_1[NAME], TypedArray);
			  }
			}

			if (!NATIVE_ARRAY_BUFFER_VIEWS || !TypedArrayPrototype || TypedArrayPrototype === ObjectPrototype) {
			  TypedArrayPrototype = TypedArray.prototype;
			  if (NATIVE_ARRAY_BUFFER_VIEWS) for (NAME in TypedArrayConstructorsList) {
			    if (global_1[NAME]) objectSetPrototypeOf(global_1[NAME].prototype, TypedArrayPrototype);
			  }
			}

			// WebKit bug - one more object in Uint8ClampedArray prototype chain
			if (NATIVE_ARRAY_BUFFER_VIEWS && objectGetPrototypeOf(Uint8ClampedArrayPrototype) !== TypedArrayPrototype) {
			  objectSetPrototypeOf(Uint8ClampedArrayPrototype, TypedArrayPrototype);
			}

			if (descriptors && !has$2(TypedArrayPrototype, TO_STRING_TAG$1)) {
			  TYPED_ARRAY_TAG_REQIRED = true;
			  defineProperty$5(TypedArrayPrototype, TO_STRING_TAG$1, { get: function () {
			    return isObject(this) ? this[TYPED_ARRAY_TAG] : undefined;
			  } });
			  for (NAME in TypedArrayConstructorsList) if (global_1[NAME]) {
			    createNonEnumerableProperty(global_1[NAME], TYPED_ARRAY_TAG, NAME);
			  }
			}

			var arrayBufferViewCore = {
			  NATIVE_ARRAY_BUFFER_VIEWS: NATIVE_ARRAY_BUFFER_VIEWS,
			  TYPED_ARRAY_CONSTRUCTOR: TYPED_ARRAY_CONSTRUCTOR,
			  TYPED_ARRAY_TAG: TYPED_ARRAY_TAG_REQIRED && TYPED_ARRAY_TAG,
			  aTypedArray: aTypedArray$1,
			  aTypedArrayConstructor: aTypedArrayConstructor,
			  exportTypedArrayMethod: exportTypedArrayMethod$1,
			  exportTypedArrayStaticMethod: exportTypedArrayStaticMethod,
			  isView: isView,
			  isTypedArray: isTypedArray,
			  TypedArray: TypedArray,
			  TypedArrayPrototype: TypedArrayPrototype
			};

			var $includes = arrayIncludes.includes;

			var aTypedArray = arrayBufferViewCore.aTypedArray;
			var exportTypedArrayMethod = arrayBufferViewCore.exportTypedArrayMethod;

			// `%TypedArray%.prototype.includes` method
			// https://tc39.es/ecma262/#sec-%typedarray%.prototype.includes
			exportTypedArrayMethod('includes', function includes(searchElement /* , fromIndex */) {
			  return $includes(aTypedArray(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
			});

			var es2016ArrayInclude = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2016ArrayInclude);

			var propertyIsEnumerable = objectPropertyIsEnumerable.f;

			// `Object.{ entries, values }` methods implementation
			var createMethod$3 = function (TO_ENTRIES) {
			  return function (it) {
			    var O = toIndexedObject(it);
			    var keys = objectKeys$1(O);
			    var length = keys.length;
			    var i = 0;
			    var result = [];
			    var key;
			    while (length > i) {
			      key = keys[i++];
			      if (!descriptors || propertyIsEnumerable.call(O, key)) {
			        result.push(TO_ENTRIES ? [key, O[key]] : O[key]);
			      }
			    }
			    return result;
			  };
			};

			var objectToArray = {
			  // `Object.entries` method
			  // https://tc39.es/ecma262/#sec-object.entries
			  entries: createMethod$3(true),
			  // `Object.values` method
			  // https://tc39.es/ecma262/#sec-object.values
			  values: createMethod$3(false)
			};

			var $values = objectToArray.values;

			// `Object.values` method
			// https://tc39.es/ecma262/#sec-object.values
			_export({ target: 'Object', stat: true }, {
			  values: function values(O) {
			    return $values(O);
			  }
			});

			var path = exports('H', global_1);

			path.Object.values;

			var $entries = objectToArray.entries;

			// `Object.entries` method
			// https://tc39.es/ecma262/#sec-object.entries
			_export({ target: 'Object', stat: true }, {
			  entries: function entries(O) {
			    return $entries(O);
			  }
			});

			path.Object.entries;

			var createProperty = function (object, key, value) {
			  var propertyKey = toPropertyKey(key);
			  if (propertyKey in object) objectDefineProperty.f(object, propertyKey, createPropertyDescriptor(0, value));
			  else object[propertyKey] = value;
			};

			// `Object.getOwnPropertyDescriptors` method
			// https://tc39.es/ecma262/#sec-object.getownpropertydescriptors
			_export({ target: 'Object', stat: true, sham: !descriptors }, {
			  getOwnPropertyDescriptors: function getOwnPropertyDescriptors(object) {
			    var O = toIndexedObject(object);
			    var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
			    var keys = ownKeys(O);
			    var result = {};
			    var index = 0;
			    var key, descriptor;
			    while (keys.length > index) {
			      descriptor = getOwnPropertyDescriptor(O, key = keys[index++]);
			      if (descriptor !== undefined) createProperty(result, key, descriptor);
			    }
			    return result;
			  }
			});

			path.Object.getOwnPropertyDescriptors;

			var es2017Object = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2017Object);

			var toString_1 = exports('t', function (argument) {
			  if (isSymbol(argument)) throw TypeError('Cannot convert a Symbol value to a string');
			  return String(argument);
			});

			// `String.prototype.repeat` method implementation
			// https://tc39.es/ecma262/#sec-string.prototype.repeat
			var stringRepeat = function repeat(count) {
			  var str = toString_1(requireObjectCoercible(this));
			  var result = '';
			  var n = toInteger(count);
			  if (n < 0 || n == Infinity) throw RangeError('Wrong number of repetitions');
			  for (;n > 0; (n >>>= 1) && (str += str)) if (n & 1) result += str;
			  return result;
			};

			// https://github.com/tc39/proposal-string-pad-start-end





			var ceil = Math.ceil;

			// `String.prototype.{ padStart, padEnd }` methods implementation
			var createMethod$2 = function (IS_END) {
			  return function ($this, maxLength, fillString) {
			    var S = toString_1(requireObjectCoercible($this));
			    var stringLength = S.length;
			    var fillStr = fillString === undefined ? ' ' : toString_1(fillString);
			    var intMaxLength = toLength(maxLength);
			    var fillLen, stringFiller;
			    if (intMaxLength <= stringLength || fillStr == '') return S;
			    fillLen = intMaxLength - stringLength;
			    stringFiller = stringRepeat.call(fillStr, ceil(fillLen / fillStr.length));
			    if (stringFiller.length > fillLen) stringFiller = stringFiller.slice(0, fillLen);
			    return IS_END ? S + stringFiller : stringFiller + S;
			  };
			};

			var stringPad = {
			  // `String.prototype.padStart` method
			  // https://tc39.es/ecma262/#sec-string.prototype.padstart
			  start: createMethod$2(false),
			  // `String.prototype.padEnd` method
			  // https://tc39.es/ecma262/#sec-string.prototype.padend
			  end: createMethod$2(true)
			};

			// https://github.com/zloirock/core-js/issues/280


			// eslint-disable-next-line unicorn/no-unsafe-regex -- safe
			var stringPadWebkitBug = /Version\/10(?:\.\d+){1,2}(?: [\w./]+)?(?: Mobile\/\w+)? Safari\//.test(engineUserAgent);

			var $padStart = stringPad.start;


			// `String.prototype.padStart` method
			// https://tc39.es/ecma262/#sec-string.prototype.padstart
			_export({ target: 'String', proto: true, forced: stringPadWebkitBug }, {
			  padStart: function padStart(maxLength /* , fillString = ' ' */) {
			    return $padStart(this, maxLength, arguments.length > 1 ? arguments[1] : undefined);
			  }
			});

			entryUnbind('String', 'padStart');

			var $padEnd = stringPad.end;


			// `String.prototype.padEnd` method
			// https://tc39.es/ecma262/#sec-string.prototype.padend
			_export({ target: 'String', proto: true, forced: stringPadWebkitBug }, {
			  padEnd: function padEnd(maxLength /* , fillString = ' ' */) {
			    return $padEnd(this, maxLength, arguments.length > 1 ? arguments[1] : undefined);
			  }
			});

			entryUnbind('String', 'padEnd');

			var es2017String = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2017String);

			var f = wellKnownSymbol;

			var wellKnownSymbolWrapped = {
				f: f
			};

			var defineProperty$4 = objectDefineProperty.f;

			var defineWellKnownSymbol = function (NAME) {
			  var Symbol = path.Symbol || (path.Symbol = {});
			  if (!has$2(Symbol, NAME)) defineProperty$4(Symbol, NAME, {
			    value: wellKnownSymbolWrapped.f(NAME)
			  });
			};

			// `Symbol.asyncIterator` well-known symbol
			// https://tc39.es/ecma262/#sec-symbol.asynciterator
			defineWellKnownSymbol('asyncIterator');

			wellKnownSymbolWrapped.f('asyncIterator');

			var es2018AsyncIterable = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2018AsyncIterable);

			// `IsArray` abstract operation
			// https://tc39.es/ecma262/#sec-isarray
			// eslint-disable-next-line es/no-array-isarray -- safe
			var isArray = Array.isArray || function isArray(arg) {
			  return classofRaw(arg) == 'Array';
			};

			// `FlattenIntoArray` abstract operation
			// https://tc39.github.io/proposal-flatMap/#sec-FlattenIntoArray
			var flattenIntoArray = function (target, original, source, sourceLen, start, depth, mapper, thisArg) {
			  var targetIndex = start;
			  var sourceIndex = 0;
			  var mapFn = mapper ? functionBindContext(mapper, thisArg, 3) : false;
			  var element;

			  while (sourceIndex < sourceLen) {
			    if (sourceIndex in source) {
			      element = mapFn ? mapFn(source[sourceIndex], sourceIndex, original) : source[sourceIndex];

			      if (depth > 0 && isArray(element)) {
			        targetIndex = flattenIntoArray(target, original, element, toLength(element.length), targetIndex, depth - 1) - 1;
			      } else {
			        if (targetIndex >= 0x1FFFFFFFFFFFFF) throw TypeError('Exceed the acceptable array length');
			        target[targetIndex] = element;
			      }

			      targetIndex++;
			    }
			    sourceIndex++;
			  }
			  return targetIndex;
			};

			var flattenIntoArray_1 = flattenIntoArray;

			var SPECIES$1 = wellKnownSymbol('species');

			// a part of `ArraySpeciesCreate` abstract operation
			// https://tc39.es/ecma262/#sec-arrayspeciescreate
			var arraySpeciesConstructor = function (originalArray) {
			  var C;
			  if (isArray(originalArray)) {
			    C = originalArray.constructor;
			    // cross-realm fallback
			    if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
			    else if (isObject(C)) {
			      C = C[SPECIES$1];
			      if (C === null) C = undefined;
			    }
			  } return C === undefined ? Array : C;
			};

			// `ArraySpeciesCreate` abstract operation
			// https://tc39.es/ecma262/#sec-arrayspeciescreate
			var arraySpeciesCreate = function (originalArray, length) {
			  return new (arraySpeciesConstructor(originalArray))(length === 0 ? 0 : length);
			};

			// `Array.prototype.flatMap` method
			// https://tc39.es/ecma262/#sec-array.prototype.flatmap
			_export({ target: 'Array', proto: true }, {
			  flatMap: function flatMap(callbackfn /* , thisArg */) {
			    var O = toObject(this);
			    var sourceLen = toLength(O.length);
			    var A;
			    aFunction(callbackfn);
			    A = arraySpeciesCreate(O, 0);
			    A.length = flattenIntoArray_1(A, O, O, sourceLen, 0, 1, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
			    return A;
			  }
			});

			// this method was added to unscopables after implementation
			// in popular engines, so it's moved to a separate module


			// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
			addToUnscopables('flatMap');

			entryUnbind('Array', 'flatMap');

			// `Array.prototype.flat` method
			// https://tc39.es/ecma262/#sec-array.prototype.flat
			_export({ target: 'Array', proto: true }, {
			  flat: function flat(/* depthArg = 1 */) {
			    var depthArg = arguments.length ? arguments[0] : undefined;
			    var O = toObject(this);
			    var sourceLen = toLength(O.length);
			    var A = arraySpeciesCreate(O, 0);
			    A.length = flattenIntoArray_1(A, O, O, sourceLen, 0, depthArg === undefined ? 1 : toInteger(depthArg));
			    return A;
			  }
			});

			// this method was added to unscopables after implementation
			// in popular engines, so it's moved to a separate module


			// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
			addToUnscopables('flat');

			entryUnbind('Array', 'flat');

			var es2019Array = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2019Array);

			var iterators = {};

			var ITERATOR$5 = wellKnownSymbol('iterator');
			var BUGGY_SAFARI_ITERATORS$1 = false;

			var returnThis$2 = function () { return this; };

			// `%IteratorPrototype%` object
			// https://tc39.es/ecma262/#sec-%iteratorprototype%-object
			var IteratorPrototype$2, PrototypeOfArrayIteratorPrototype, arrayIterator;

			/* eslint-disable es/no-array-prototype-keys -- safe */
			if ([].keys) {
			  arrayIterator = [].keys();
			  // Safari 8 has buggy iterators w/o `next`
			  if (!('next' in arrayIterator)) BUGGY_SAFARI_ITERATORS$1 = true;
			  else {
			    PrototypeOfArrayIteratorPrototype = objectGetPrototypeOf(objectGetPrototypeOf(arrayIterator));
			    if (PrototypeOfArrayIteratorPrototype !== Object.prototype) IteratorPrototype$2 = PrototypeOfArrayIteratorPrototype;
			  }
			}

			var NEW_ITERATOR_PROTOTYPE = IteratorPrototype$2 == undefined || fails(function () {
			  var test = {};
			  // FF44- legacy iterators case
			  return IteratorPrototype$2[ITERATOR$5].call(test) !== test;
			});

			if (NEW_ITERATOR_PROTOTYPE) IteratorPrototype$2 = {};

			// `%IteratorPrototype%[@@iterator]()` method
			// https://tc39.es/ecma262/#sec-%iteratorprototype%-@@iterator
			if (!has$2(IteratorPrototype$2, ITERATOR$5)) {
			  createNonEnumerableProperty(IteratorPrototype$2, ITERATOR$5, returnThis$2);
			}

			var iteratorsCore = {
			  IteratorPrototype: IteratorPrototype$2,
			  BUGGY_SAFARI_ITERATORS: BUGGY_SAFARI_ITERATORS$1
			};

			var defineProperty$3 = objectDefineProperty.f;



			var TO_STRING_TAG = wellKnownSymbol('toStringTag');

			var setToStringTag = exports('B', function (it, TAG, STATIC) {
			  if (it && !has$2(it = STATIC ? it : it.prototype, TO_STRING_TAG)) {
			    defineProperty$3(it, TO_STRING_TAG, { configurable: true, value: TAG });
			  }
			});

			var IteratorPrototype$1 = iteratorsCore.IteratorPrototype;





			var returnThis$1 = function () { return this; };

			var createIteratorConstructor = function (IteratorConstructor, NAME, next) {
			  var TO_STRING_TAG = NAME + ' Iterator';
			  IteratorConstructor.prototype = objectCreate(IteratorPrototype$1, { next: createPropertyDescriptor(1, next) });
			  setToStringTag(IteratorConstructor, TO_STRING_TAG, false);
			  iterators[TO_STRING_TAG] = returnThis$1;
			  return IteratorConstructor;
			};

			var IteratorPrototype = iteratorsCore.IteratorPrototype;
			var BUGGY_SAFARI_ITERATORS = iteratorsCore.BUGGY_SAFARI_ITERATORS;
			var ITERATOR$4 = wellKnownSymbol('iterator');
			var KEYS = 'keys';
			var VALUES = 'values';
			var ENTRIES = 'entries';

			var returnThis = function () { return this; };

			var defineIterator = function (Iterable, NAME, IteratorConstructor, next, DEFAULT, IS_SET, FORCED) {
			  createIteratorConstructor(IteratorConstructor, NAME, next);

			  var getIterationMethod = function (KIND) {
			    if (KIND === DEFAULT && defaultIterator) return defaultIterator;
			    if (!BUGGY_SAFARI_ITERATORS && KIND in IterablePrototype) return IterablePrototype[KIND];
			    switch (KIND) {
			      case KEYS: return function keys() { return new IteratorConstructor(this, KIND); };
			      case VALUES: return function values() { return new IteratorConstructor(this, KIND); };
			      case ENTRIES: return function entries() { return new IteratorConstructor(this, KIND); };
			    } return function () { return new IteratorConstructor(this); };
			  };

			  var TO_STRING_TAG = NAME + ' Iterator';
			  var INCORRECT_VALUES_NAME = false;
			  var IterablePrototype = Iterable.prototype;
			  var nativeIterator = IterablePrototype[ITERATOR$4]
			    || IterablePrototype['@@iterator']
			    || DEFAULT && IterablePrototype[DEFAULT];
			  var defaultIterator = !BUGGY_SAFARI_ITERATORS && nativeIterator || getIterationMethod(DEFAULT);
			  var anyNativeIterator = NAME == 'Array' ? IterablePrototype.entries || nativeIterator : nativeIterator;
			  var CurrentIteratorPrototype, methods, KEY;

			  // fix native
			  if (anyNativeIterator) {
			    CurrentIteratorPrototype = objectGetPrototypeOf(anyNativeIterator.call(new Iterable()));
			    if (IteratorPrototype !== Object.prototype && CurrentIteratorPrototype.next) {
			      if (objectGetPrototypeOf(CurrentIteratorPrototype) !== IteratorPrototype) {
			        if (objectSetPrototypeOf) {
			          objectSetPrototypeOf(CurrentIteratorPrototype, IteratorPrototype);
			        } else if (typeof CurrentIteratorPrototype[ITERATOR$4] != 'function') {
			          createNonEnumerableProperty(CurrentIteratorPrototype, ITERATOR$4, returnThis);
			        }
			      }
			      // Set @@toStringTag to native iterators
			      setToStringTag(CurrentIteratorPrototype, TO_STRING_TAG, true);
			    }
			  }

			  // fix Array.prototype.{ values, @@iterator }.name in V8 / FF
			  if (DEFAULT == VALUES && nativeIterator && nativeIterator.name !== VALUES) {
			    INCORRECT_VALUES_NAME = true;
			    defaultIterator = function values() { return nativeIterator.call(this); };
			  }

			  // define iterator
			  if (IterablePrototype[ITERATOR$4] !== defaultIterator) {
			    createNonEnumerableProperty(IterablePrototype, ITERATOR$4, defaultIterator);
			  }
			  iterators[NAME] = defaultIterator;

			  // export additional methods
			  if (DEFAULT) {
			    methods = {
			      values: getIterationMethod(VALUES),
			      keys: IS_SET ? defaultIterator : getIterationMethod(KEYS),
			      entries: getIterationMethod(ENTRIES)
			    };
			    if (FORCED) for (KEY in methods) {
			      if (BUGGY_SAFARI_ITERATORS || INCORRECT_VALUES_NAME || !(KEY in IterablePrototype)) {
			        redefine(IterablePrototype, KEY, methods[KEY]);
			      }
			    } else _export({ target: NAME, proto: true, forced: BUGGY_SAFARI_ITERATORS || INCORRECT_VALUES_NAME }, methods);
			  }

			  return methods;
			};

			var ARRAY_ITERATOR = 'Array Iterator';
			var setInternalState$4 = internalState.set;
			var getInternalState$3 = internalState.getterFor(ARRAY_ITERATOR);

			// `Array.prototype.entries` method
			// https://tc39.es/ecma262/#sec-array.prototype.entries
			// `Array.prototype.keys` method
			// https://tc39.es/ecma262/#sec-array.prototype.keys
			// `Array.prototype.values` method
			// https://tc39.es/ecma262/#sec-array.prototype.values
			// `Array.prototype[@@iterator]` method
			// https://tc39.es/ecma262/#sec-array.prototype-@@iterator
			// `CreateArrayIterator` internal method
			// https://tc39.es/ecma262/#sec-createarrayiterator
			var es_array_iterator = exports('I', defineIterator(Array, 'Array', function (iterated, kind) {
			  setInternalState$4(this, {
			    type: ARRAY_ITERATOR,
			    target: toIndexedObject(iterated), // target
			    index: 0,                          // next index
			    kind: kind                         // kind
			  });
			// `%ArrayIteratorPrototype%.next` method
			// https://tc39.es/ecma262/#sec-%arrayiteratorprototype%.next
			}, function () {
			  var state = getInternalState$3(this);
			  var target = state.target;
			  var kind = state.kind;
			  var index = state.index++;
			  if (!target || index >= target.length) {
			    state.target = undefined;
			    return { value: undefined, done: true };
			  }
			  if (kind == 'keys') return { value: index, done: false };
			  if (kind == 'values') return { value: target[index], done: false };
			  return { value: [index, target[index]], done: false };
			}, 'values'));

			// argumentsList[@@iterator] is %ArrayProto_values%
			// https://tc39.es/ecma262/#sec-createunmappedargumentsobject
			// https://tc39.es/ecma262/#sec-createmappedargumentsobject
			iterators.Arguments = iterators.Array;

			// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
			addToUnscopables('keys');
			addToUnscopables('values');
			addToUnscopables('entries');

			var ITERATOR$3 = wellKnownSymbol('iterator');
			var ArrayPrototype = Array.prototype;

			// check on default Array iterator
			var isArrayIteratorMethod = function (it) {
			  return it !== undefined && (iterators.Array === it || ArrayPrototype[ITERATOR$3] === it);
			};

			var ITERATOR$2 = wellKnownSymbol('iterator');

			var getIteratorMethod = function (it) {
			  if (it != undefined) return it[ITERATOR$2]
			    || it['@@iterator']
			    || iterators[classof(it)];
			};

			var iteratorClose = function (iterator) {
			  var returnMethod = iterator['return'];
			  if (returnMethod !== undefined) {
			    return anObject(returnMethod.call(iterator)).value;
			  }
			};

			var Result = function (stopped, result) {
			  this.stopped = stopped;
			  this.result = result;
			};

			var iterate = exports('i', function (iterable, unboundFunction, options) {
			  var that = options && options.that;
			  var AS_ENTRIES = !!(options && options.AS_ENTRIES);
			  var IS_ITERATOR = !!(options && options.IS_ITERATOR);
			  var INTERRUPTED = !!(options && options.INTERRUPTED);
			  var fn = functionBindContext(unboundFunction, that, 1 + AS_ENTRIES + INTERRUPTED);
			  var iterator, iterFn, index, length, result, next, step;

			  var stop = function (condition) {
			    if (iterator) iteratorClose(iterator);
			    return new Result(true, condition);
			  };

			  var callFn = function (value) {
			    if (AS_ENTRIES) {
			      anObject(value);
			      return INTERRUPTED ? fn(value[0], value[1], stop) : fn(value[0], value[1]);
			    } return INTERRUPTED ? fn(value, stop) : fn(value);
			  };

			  if (IS_ITERATOR) {
			    iterator = iterable;
			  } else {
			    iterFn = getIteratorMethod(iterable);
			    if (typeof iterFn != 'function') throw TypeError('Target is not iterable');
			    // optimisation for array iterators
			    if (isArrayIteratorMethod(iterFn)) {
			      for (index = 0, length = toLength(iterable.length); length > index; index++) {
			        result = callFn(iterable[index]);
			        if (result && result instanceof Result) return result;
			      } return new Result(false);
			    }
			    iterator = iterFn.call(iterable);
			  }

			  next = iterator.next;
			  while (!(step = next.call(iterator)).done) {
			    try {
			      result = callFn(step.value);
			    } catch (error) {
			      iteratorClose(iterator);
			      throw error;
			    }
			    if (typeof result == 'object' && result && result instanceof Result) return result;
			  } return new Result(false);
			});

			// `Object.fromEntries` method
			// https://github.com/tc39/proposal-object-from-entries
			_export({ target: 'Object', stat: true }, {
			  fromEntries: function fromEntries(iterable) {
			    var obj = {};
			    iterate(iterable, function (k, v) {
			      createProperty(obj, k, v);
			    }, { AS_ENTRIES: true });
			    return obj;
			  }
			});

			path.Object.fromEntries;

			var es2019Object = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2019Object);

			// a string of all valid unicode whitespaces
			var whitespaces = '\u0009\u000A\u000B\u000C\u000D\u0020\u00A0\u1680\u2000\u2001\u2002' +
			  '\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';

			var whitespace = '[' + whitespaces + ']';
			var ltrim = RegExp('^' + whitespace + whitespace + '*');
			var rtrim = RegExp(whitespace + whitespace + '*$');

			// `String.prototype.{ trim, trimStart, trimEnd, trimLeft, trimRight }` methods implementation
			var createMethod$1 = function (TYPE) {
			  return function ($this) {
			    var string = toString_1(requireObjectCoercible($this));
			    if (TYPE & 1) string = string.replace(ltrim, '');
			    if (TYPE & 2) string = string.replace(rtrim, '');
			    return string;
			  };
			};

			var stringTrim = {
			  // `String.prototype.{ trimLeft, trimStart }` methods
			  // https://tc39.es/ecma262/#sec-string.prototype.trimstart
			  start: createMethod$1(1),
			  // `String.prototype.{ trimRight, trimEnd }` methods
			  // https://tc39.es/ecma262/#sec-string.prototype.trimend
			  end: createMethod$1(2),
			  // `String.prototype.trim` method
			  // https://tc39.es/ecma262/#sec-string.prototype.trim
			  trim: createMethod$1(3)
			};

			var non = '\u200B\u0085\u180E';

			// check that a method works with the correct list
			// of whitespaces and has a correct name
			var stringTrimForced = function (METHOD_NAME) {
			  return fails(function () {
			    return !!whitespaces[METHOD_NAME]() || non[METHOD_NAME]() != non || whitespaces[METHOD_NAME].name !== METHOD_NAME;
			  });
			};

			var $trimEnd = stringTrim.end;


			var FORCED$1 = stringTrimForced('trimEnd');

			var trimEnd = FORCED$1 ? function trimEnd() {
			  return $trimEnd(this);
			// eslint-disable-next-line es/no-string-prototype-trimstart-trimend -- safe
			} : ''.trimEnd;

			// `String.prototype.{ trimEnd, trimRight }` methods
			// https://tc39.es/ecma262/#sec-string.prototype.trimend
			// https://tc39.es/ecma262/#String.prototype.trimright
			_export({ target: 'String', proto: true, forced: FORCED$1 }, {
			  trimEnd: trimEnd,
			  trimRight: trimEnd
			});

			entryUnbind('String', 'trimRight');

			var $trimStart = stringTrim.start;


			var FORCED = stringTrimForced('trimStart');

			var trimStart = FORCED ? function trimStart() {
			  return $trimStart(this);
			// eslint-disable-next-line es/no-string-prototype-trimstart-trimend -- safe
			} : ''.trimStart;

			// `String.prototype.{ trimStart, trimLeft }` methods
			// https://tc39.es/ecma262/#sec-string.prototype.trimstart
			// https://tc39.es/ecma262/#String.prototype.trimleft
			_export({ target: 'String', proto: true, forced: FORCED }, {
			  trimStart: trimStart,
			  trimLeft: trimStart
			});

			entryUnbind('String', 'trimLeft');

			entryUnbind('String', 'trimLeft');

			entryUnbind('String', 'trimRight');

			var es2019String = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2019String);

			var defineProperty$2 = objectDefineProperty.f;


			var NativeSymbol = global_1.Symbol;

			if (descriptors && typeof NativeSymbol == 'function' && (!('description' in NativeSymbol.prototype) ||
			  // Safari 12 bug
			  NativeSymbol().description !== undefined
			)) {
			  var EmptyStringDescriptionStore = {};
			  // wrap Symbol constructor for correct work with undefined description
			  var SymbolWrapper = function Symbol() {
			    var description = arguments.length < 1 || arguments[0] === undefined ? undefined : String(arguments[0]);
			    var result = this instanceof SymbolWrapper
			      ? new NativeSymbol(description)
			      // in Edge 13, String(Symbol(undefined)) === 'Symbol(undefined)'
			      : description === undefined ? NativeSymbol() : NativeSymbol(description);
			    if (description === '') EmptyStringDescriptionStore[result] = true;
			    return result;
			  };
			  copyConstructorProperties(SymbolWrapper, NativeSymbol);
			  var symbolPrototype = SymbolWrapper.prototype = NativeSymbol.prototype;
			  symbolPrototype.constructor = SymbolWrapper;

			  var symbolToString = symbolPrototype.toString;
			  var native = String(NativeSymbol('test')) == 'Symbol(test)';
			  var regexp = /^Symbol\((.*)\)[^)]+$/;
			  defineProperty$2(symbolPrototype, 'description', {
			    configurable: true,
			    get: function description() {
			      var symbol = isObject(this) ? this.valueOf() : this;
			      var string = symbolToString.call(symbol);
			      if (has$2(EmptyStringDescriptionStore, symbol)) return '';
			      var desc = native ? string.slice(7, -1) : string.replace(regexp, '$1');
			      return desc === '' ? undefined : desc;
			    }
			  });

			  _export({ global: true, forced: true }, {
			    Symbol: SymbolWrapper
			  });
			}

			var es2019Symbol = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2019Symbol);

			// `Object.prototype.toString` method implementation
			// https://tc39.es/ecma262/#sec-object.prototype.tostring
			var objectToString = toStringTagSupport ? {}.toString : function toString() {
			  return '[object ' + classof(this) + ']';
			};

			// `Object.prototype.toString` method
			// https://tc39.es/ecma262/#sec-object.prototype.tostring
			if (!toStringTagSupport) {
			  redefine(Object.prototype, 'toString', objectToString, { unsafe: true });
			}

			// `RegExp.prototype.flags` getter implementation
			// https://tc39.es/ecma262/#sec-get-regexp.prototype.flags
			var regexpFlags = function () {
			  var that = anObject(this);
			  var result = '';
			  if (that.global) result += 'g';
			  if (that.ignoreCase) result += 'i';
			  if (that.multiline) result += 'm';
			  if (that.dotAll) result += 's';
			  if (that.unicode) result += 'u';
			  if (that.sticky) result += 'y';
			  return result;
			};

			// babel-minify transpiles RegExp('a', 'y') -> /a/y and it causes SyntaxError,
			var RE = function (s, f) {
			  return RegExp(s, f);
			};

			var UNSUPPORTED_Y$1 = fails(function () {
			  var re = RE('a', 'y');
			  re.lastIndex = 2;
			  return re.exec('abcd') != null;
			});

			var BROKEN_CARET = fails(function () {
			  // https://bugzilla.mozilla.org/show_bug.cgi?id=773687
			  var re = RE('^r', 'gy');
			  re.lastIndex = 2;
			  return re.exec('str') != null;
			});

			var regexpStickyHelpers = {
				UNSUPPORTED_Y: UNSUPPORTED_Y$1,
				BROKEN_CARET: BROKEN_CARET
			};

			var regexpUnsupportedDotAll = fails(function () {
			  // babel-minify transpiles RegExp('.', 's') -> /./s and it causes SyntaxError
			  var re = RegExp('.', (typeof '').charAt(0));
			  return !(re.dotAll && re.exec('\n') && re.flags === 's');
			});

			var regexpUnsupportedNcg = fails(function () {
			  // babel-minify transpiles RegExp('.', 'g') -> /./g and it causes SyntaxError
			  var re = RegExp('(?<a>b)', (typeof '').charAt(5));
			  return re.exec('b').groups.a !== 'b' ||
			    'b'.replace(re, '$<a>c') !== 'bc';
			});

			/* eslint-disable regexp/no-assertion-capturing-group, regexp/no-empty-group, regexp/no-lazy-ends -- testing */
			/* eslint-disable regexp/no-useless-quantifier -- testing */





			var getInternalState$2 = internalState.get;



			var nativeExec = RegExp.prototype.exec;
			var nativeReplace = shared('native-string-replace', String.prototype.replace);

			var patchedExec = nativeExec;

			var UPDATES_LAST_INDEX_WRONG = (function () {
			  var re1 = /a/;
			  var re2 = /b*/g;
			  nativeExec.call(re1, 'a');
			  nativeExec.call(re2, 'a');
			  return re1.lastIndex !== 0 || re2.lastIndex !== 0;
			})();

			var UNSUPPORTED_Y = regexpStickyHelpers.UNSUPPORTED_Y || regexpStickyHelpers.BROKEN_CARET;

			// nonparticipating capturing group, copied from es5-shim's String#split patch.
			var NPCG_INCLUDED = /()??/.exec('')[1] !== undefined;

			var PATCH = UPDATES_LAST_INDEX_WRONG || NPCG_INCLUDED || UNSUPPORTED_Y || regexpUnsupportedDotAll || regexpUnsupportedNcg;

			if (PATCH) {
			  // eslint-disable-next-line max-statements -- TODO
			  patchedExec = function exec(string) {
			    var re = this;
			    var state = getInternalState$2(re);
			    var str = toString_1(string);
			    var raw = state.raw;
			    var result, reCopy, lastIndex, match, i, object, group;

			    if (raw) {
			      raw.lastIndex = re.lastIndex;
			      result = patchedExec.call(raw, str);
			      re.lastIndex = raw.lastIndex;
			      return result;
			    }

			    var groups = state.groups;
			    var sticky = UNSUPPORTED_Y && re.sticky;
			    var flags = regexpFlags.call(re);
			    var source = re.source;
			    var charsAdded = 0;
			    var strCopy = str;

			    if (sticky) {
			      flags = flags.replace('y', '');
			      if (flags.indexOf('g') === -1) {
			        flags += 'g';
			      }

			      strCopy = str.slice(re.lastIndex);
			      // Support anchored sticky behavior.
			      if (re.lastIndex > 0 && (!re.multiline || re.multiline && str.charAt(re.lastIndex - 1) !== '\n')) {
			        source = '(?: ' + source + ')';
			        strCopy = ' ' + strCopy;
			        charsAdded++;
			      }
			      // ^(? + rx + ) is needed, in combination with some str slicing, to
			      // simulate the 'y' flag.
			      reCopy = new RegExp('^(?:' + source + ')', flags);
			    }

			    if (NPCG_INCLUDED) {
			      reCopy = new RegExp('^' + source + '$(?!\\s)', flags);
			    }
			    if (UPDATES_LAST_INDEX_WRONG) lastIndex = re.lastIndex;

			    match = nativeExec.call(sticky ? reCopy : re, strCopy);

			    if (sticky) {
			      if (match) {
			        match.input = match.input.slice(charsAdded);
			        match[0] = match[0].slice(charsAdded);
			        match.index = re.lastIndex;
			        re.lastIndex += match[0].length;
			      } else re.lastIndex = 0;
			    } else if (UPDATES_LAST_INDEX_WRONG && match) {
			      re.lastIndex = re.global ? match.index + match[0].length : lastIndex;
			    }
			    if (NPCG_INCLUDED && match && match.length > 1) {
			      // Fix browsers whose `exec` methods don't consistently return `undefined`
			      // for NPCG, like IE8. NOTE: This doesn' work for /(.?)?/
			      nativeReplace.call(match[0], reCopy, function () {
			        for (i = 1; i < arguments.length - 2; i++) {
			          if (arguments[i] === undefined) match[i] = undefined;
			        }
			      });
			    }

			    if (match && groups) {
			      match.groups = object = objectCreate(null);
			      for (i = 0; i < groups.length; i++) {
			        group = groups[i];
			        object[group[0]] = match[group[1]];
			      }
			    }

			    return match;
			  };
			}

			var regexpExec = patchedExec;

			// `RegExp.prototype.exec` method
			// https://tc39.es/ecma262/#sec-regexp.prototype.exec
			_export({ target: 'RegExp', proto: true, forced: /./.exec !== regexpExec }, {
			  exec: regexpExec
			});

			var MATCH = wellKnownSymbol('match');

			// `IsRegExp` abstract operation
			// https://tc39.es/ecma262/#sec-isregexp
			var isRegexp = function (it) {
			  var isRegExp;
			  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : classofRaw(it) == 'RegExp');
			};

			var SPECIES = wellKnownSymbol('species');

			// `SpeciesConstructor` abstract operation
			// https://tc39.es/ecma262/#sec-speciesconstructor
			var speciesConstructor = exports('F', function (O, defaultConstructor) {
			  var C = anObject(O).constructor;
			  var S;
			  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? defaultConstructor : aFunction(S);
			});

			// `String.prototype.codePointAt` methods implementation
			var createMethod = function (CONVERT_TO_STRING) {
			  return function ($this, pos) {
			    var S = toString_1(requireObjectCoercible($this));
			    var position = toInteger(pos);
			    var size = S.length;
			    var first, second;
			    if (position < 0 || position >= size) return CONVERT_TO_STRING ? '' : undefined;
			    first = S.charCodeAt(position);
			    return first < 0xD800 || first > 0xDBFF || position + 1 === size
			      || (second = S.charCodeAt(position + 1)) < 0xDC00 || second > 0xDFFF
			        ? CONVERT_TO_STRING ? S.charAt(position) : first
			        : CONVERT_TO_STRING ? S.slice(position, position + 2) : (first - 0xD800 << 10) + (second - 0xDC00) + 0x10000;
			  };
			};

			var stringMultibyte = {
			  // `String.prototype.codePointAt` method
			  // https://tc39.es/ecma262/#sec-string.prototype.codepointat
			  codeAt: createMethod(false),
			  // `String.prototype.at` method
			  // https://github.com/mathiasbynens/String.prototype.at
			  charAt: createMethod(true)
			};

			var charAt$1 = stringMultibyte.charAt;

			// `AdvanceStringIndex` abstract operation
			// https://tc39.es/ecma262/#sec-advancestringindex
			var advanceStringIndex = function (S, index, unicode) {
			  return index + (unicode ? charAt$1(S, index).length : 1);
			};

			/* eslint-disable es/no-string-prototype-matchall -- safe */


















			var MATCH_ALL = wellKnownSymbol('matchAll');
			var REGEXP_STRING = 'RegExp String';
			var REGEXP_STRING_ITERATOR = REGEXP_STRING + ' Iterator';
			var setInternalState$3 = internalState.set;
			var getInternalState$1 = internalState.getterFor(REGEXP_STRING_ITERATOR);
			var RegExpPrototype = RegExp.prototype;
			var regExpBuiltinExec = RegExpPrototype.exec;
			var nativeMatchAll = ''.matchAll;

			var WORKS_WITH_NON_GLOBAL_REGEX = !!nativeMatchAll && !fails(function () {
			  'a'.matchAll(/./);
			});

			var regExpExec = function (R, S) {
			  var exec = R.exec;
			  var result;
			  if (typeof exec == 'function') {
			    result = exec.call(R, S);
			    if (typeof result != 'object') throw TypeError('Incorrect exec result');
			    return result;
			  } return regExpBuiltinExec.call(R, S);
			};

			// eslint-disable-next-line max-len -- ignore
			var $RegExpStringIterator = createIteratorConstructor(function RegExpStringIterator(regexp, string, global, fullUnicode) {
			  setInternalState$3(this, {
			    type: REGEXP_STRING_ITERATOR,
			    regexp: regexp,
			    string: string,
			    global: global,
			    unicode: fullUnicode,
			    done: false
			  });
			}, REGEXP_STRING, function next() {
			  var state = getInternalState$1(this);
			  if (state.done) return { value: undefined, done: true };
			  var R = state.regexp;
			  var S = state.string;
			  var match = regExpExec(R, S);
			  if (match === null) return { value: undefined, done: state.done = true };
			  if (state.global) {
			    if (toString_1(match[0]) === '') R.lastIndex = advanceStringIndex(S, toLength(R.lastIndex), state.unicode);
			    return { value: match, done: false };
			  }
			  state.done = true;
			  return { value: match, done: false };
			});

			var $matchAll = function (string) {
			  var R = anObject(this);
			  var S = toString_1(string);
			  var C, flagsValue, flags, matcher, global, fullUnicode;
			  C = speciesConstructor(R, RegExp);
			  flagsValue = R.flags;
			  if (flagsValue === undefined && R instanceof RegExp && !('flags' in RegExpPrototype)) {
			    flagsValue = regexpFlags.call(R);
			  }
			  flags = flagsValue === undefined ? '' : toString_1(flagsValue);
			  matcher = new C(C === RegExp ? R.source : R, flags);
			  global = !!~flags.indexOf('g');
			  fullUnicode = !!~flags.indexOf('u');
			  matcher.lastIndex = toLength(R.lastIndex);
			  return new $RegExpStringIterator(matcher, S, global, fullUnicode);
			};

			// `String.prototype.matchAll` method
			// https://tc39.es/ecma262/#sec-string.prototype.matchall
			_export({ target: 'String', proto: true, forced: WORKS_WITH_NON_GLOBAL_REGEX }, {
			  matchAll: function matchAll(regexp) {
			    var O = requireObjectCoercible(this);
			    var flags, S, matcher, rx;
			    if (regexp != null) {
			      if (isRegexp(regexp)) {
			        flags = toString_1(requireObjectCoercible('flags' in RegExpPrototype
			          ? regexp.flags
			          : regexpFlags.call(regexp)
			        ));
			        if (!~flags.indexOf('g')) throw TypeError('`.matchAll` does not allow non-global regexes');
			      }
			      if (WORKS_WITH_NON_GLOBAL_REGEX) return nativeMatchAll.apply(O, arguments);
			      matcher = regexp[MATCH_ALL];
			      if (matcher === undefined && isPure && classofRaw(regexp) == 'RegExp') matcher = $matchAll;
			      if (matcher != null) return aFunction(matcher).call(regexp, O);
			    } else if (WORKS_WITH_NON_GLOBAL_REGEX) return nativeMatchAll.apply(O, arguments);
			    S = toString_1(O);
			    rx = new RegExp(regexp, 'g');
			    return rx[MATCH_ALL](S);
			  }
			});

			MATCH_ALL in RegExpPrototype || createNonEnumerableProperty(RegExpPrototype, MATCH_ALL, $matchAll);

			entryUnbind('String', 'matchAll');

			var es2020String = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2020String);

			var es2020SymbolWellknown = createCommonjsModule(function (module, exports) {
			Object.defineProperty(exports, "__esModule", { value: true });
			});

			unwrapExports(es2020SymbolWellknown);

			var toStr$2 = Object.prototype.toString;

			var isArguments = function isArguments(value) {
				var str = toStr$2.call(value);
				var isArgs = str === '[object Arguments]';
				if (!isArgs) {
					isArgs = str !== '[object Array]' &&
						value !== null &&
						typeof value === 'object' &&
						typeof value.length === 'number' &&
						value.length >= 0 &&
						toStr$2.call(value.callee) === '[object Function]';
				}
				return isArgs;
			};

			var keysShim$1;
			if (!Object.keys) {
				// modified from https://github.com/es-shims/es5-shim
				var has = Object.prototype.hasOwnProperty;
				var toStr$1 = Object.prototype.toString;
				var isArgs = isArguments; // eslint-disable-line global-require
				var isEnumerable = Object.prototype.propertyIsEnumerable;
				var hasDontEnumBug = !isEnumerable.call({ toString: null }, 'toString');
				var hasProtoEnumBug = isEnumerable.call(function () {}, 'prototype');
				var dontEnums = [
					'toString',
					'toLocaleString',
					'valueOf',
					'hasOwnProperty',
					'isPrototypeOf',
					'propertyIsEnumerable',
					'constructor'
				];
				var equalsConstructorPrototype = function (o) {
					var ctor = o.constructor;
					return ctor && ctor.prototype === o;
				};
				var excludedKeys = {
					$applicationCache: true,
					$console: true,
					$external: true,
					$frame: true,
					$frameElement: true,
					$frames: true,
					$innerHeight: true,
					$innerWidth: true,
					$onmozfullscreenchange: true,
					$onmozfullscreenerror: true,
					$outerHeight: true,
					$outerWidth: true,
					$pageXOffset: true,
					$pageYOffset: true,
					$parent: true,
					$scrollLeft: true,
					$scrollTop: true,
					$scrollX: true,
					$scrollY: true,
					$self: true,
					$webkitIndexedDB: true,
					$webkitStorageInfo: true,
					$window: true
				};
				var hasAutomationEqualityBug = (function () {
					/* global window */
					if (typeof window === 'undefined') { return false; }
					for (var k in window) {
						try {
							if (!excludedKeys['$' + k] && has.call(window, k) && window[k] !== null && typeof window[k] === 'object') {
								try {
									equalsConstructorPrototype(window[k]);
								} catch (e) {
									return true;
								}
							}
						} catch (e) {
							return true;
						}
					}
					return false;
				}());
				var equalsConstructorPrototypeIfNotBuggy = function (o) {
					/* global window */
					if (typeof window === 'undefined' || !hasAutomationEqualityBug) {
						return equalsConstructorPrototype(o);
					}
					try {
						return equalsConstructorPrototype(o);
					} catch (e) {
						return false;
					}
				};

				keysShim$1 = function keys(object) {
					var isObject = object !== null && typeof object === 'object';
					var isFunction = toStr$1.call(object) === '[object Function]';
					var isArguments = isArgs(object);
					var isString = isObject && toStr$1.call(object) === '[object String]';
					var theKeys = [];

					if (!isObject && !isFunction && !isArguments) {
						throw new TypeError('Object.keys called on a non-object');
					}

					var skipProto = hasProtoEnumBug && isFunction;
					if (isString && object.length > 0 && !has.call(object, 0)) {
						for (var i = 0; i < object.length; ++i) {
							theKeys.push(String(i));
						}
					}

					if (isArguments && object.length > 0) {
						for (var j = 0; j < object.length; ++j) {
							theKeys.push(String(j));
						}
					} else {
						for (var name in object) {
							if (!(skipProto && name === 'prototype') && has.call(object, name)) {
								theKeys.push(String(name));
							}
						}
					}

					if (hasDontEnumBug) {
						var skipConstructor = equalsConstructorPrototypeIfNotBuggy(object);

						for (var k = 0; k < dontEnums.length; ++k) {
							if (!(skipConstructor && dontEnums[k] === 'constructor') && has.call(object, dontEnums[k])) {
								theKeys.push(dontEnums[k]);
							}
						}
					}
					return theKeys;
				};
			}
			var implementation = keysShim$1;

			var slice = Array.prototype.slice;


			var origKeys = Object.keys;
			var keysShim = origKeys ? function keys(o) { return origKeys(o); } : implementation;

			var originalKeys = Object.keys;

			keysShim.shim = function shimObjectKeys() {
				if (Object.keys) {
					var keysWorksWithArguments = (function () {
						// Safari 5.0 bug
						var args = Object.keys(arguments);
						return args && args.length === arguments.length;
					}(1, 2));
					if (!keysWorksWithArguments) {
						Object.keys = function keys(object) { // eslint-disable-line func-name-matching
							if (isArguments(object)) {
								return originalKeys(slice.call(object));
							}
							return originalKeys(object);
						};
					}
				} else {
					Object.keys = keysShim;
				}
				return Object.keys || keysShim;
			};

			var objectKeys = keysShim;

			var hasSymbols = typeof Symbol === 'function' && typeof Symbol('foo') === 'symbol';

			var toStr = Object.prototype.toString;
			var concat = Array.prototype.concat;
			var origDefineProperty = Object.defineProperty;

			var isFunction = function (fn) {
				return typeof fn === 'function' && toStr.call(fn) === '[object Function]';
			};

			var arePropertyDescriptorsSupported = function () {
				var obj = {};
				try {
					origDefineProperty(obj, 'x', { enumerable: false, value: obj });
					// eslint-disable-next-line no-unused-vars, no-restricted-syntax
					for (var _ in obj) { // jscs:ignore disallowUnusedVariables
						return false;
					}
					return obj.x === obj;
				} catch (e) { /* this is IE 8. */
					return false;
				}
			};
			var supportsDescriptors = origDefineProperty && arePropertyDescriptorsSupported();

			var defineProperty$1 = function (object, name, value, predicate) {
				if (name in object && (!isFunction(predicate) || !predicate())) {
					return;
				}
				if (supportsDescriptors) {
					origDefineProperty(object, name, {
						configurable: true,
						enumerable: false,
						value: value,
						writable: true
					});
				} else {
					object[name] = value;
				}
			};

			var defineProperties = function (object, map) {
				var predicates = arguments.length > 2 ? arguments[2] : {};
				var props = objectKeys(map);
				if (hasSymbols) {
					props = concat.call(props, Object.getOwnPropertySymbols(map));
				}
				for (var i = 0; i < props.length; i += 1) {
					defineProperty$1(object, props[i], map[props[i]], predicates[props[i]]);
				}
			};

			defineProperties.supportsDescriptors = !!supportsDescriptors;

			var defineProperties_1 = defineProperties;

			var implementation_browser = createCommonjsModule(function (module) {

			if (typeof self !== 'undefined') {
				module.exports = self;
			} else if (typeof window !== 'undefined') {
				module.exports = window;
			} else {
				module.exports = Function('return this')();
			}
			});

			var polyfill$1 = function getPolyfill() {
				if (typeof commonjsGlobal !== 'object' || !commonjsGlobal || commonjsGlobal.Math !== Math || commonjsGlobal.Array !== Array) {
					return implementation_browser;
				}
				return commonjsGlobal;
			};

			var shim = function shimGlobal() {
				var polyfill = polyfill$1();
				if (defineProperties_1.supportsDescriptors) {
					var descriptor = Object.getOwnPropertyDescriptor(polyfill, 'globalThis');
					if (!descriptor || (descriptor.configurable && (descriptor.enumerable || descriptor.writable || globalThis !== polyfill))) { // eslint-disable-line max-len
						Object.defineProperty(polyfill, 'globalThis', {
							configurable: true,
							enumerable: false,
							value: polyfill,
							writable: false
						});
					}
				} else if (typeof globalThis !== 'object' || globalThis !== polyfill) {
					polyfill.globalThis = polyfill;
				}
				return polyfill;
			};

			var polyfill = polyfill$1();

			var getGlobal$1 = function () { return polyfill; };

			defineProperties_1(getGlobal$1, {
				getPolyfill: polyfill$1,
				implementation: implementation_browser,
				shim: shim
			});

			var globalthis = getGlobal$1;

			const theGlobalThis = globalthis();
			function getGlobalThis() {
			    return theGlobalThis;
			}
			let _global = getGlobalThis();
			if (!_global.process) {
			    _global.process = {
			        env: {}
			    };
			}
			if (!_global.frameworks) {
			    _global.frameworks = {};
			}
			Object.assign(_global.process.env, {
			    NODE_ENV: 'production'
			});
			function getGlobal() {
			    return _global;
			}

			const request = getGlobalThis().Request || {};
			request.prototype = {
			    constructor: () => { }
			};

			var charAt = stringMultibyte.charAt;




			var STRING_ITERATOR = 'String Iterator';
			var setInternalState$2 = internalState.set;
			var getInternalState = internalState.getterFor(STRING_ITERATOR);

			// `String.prototype[@@iterator]` method
			// https://tc39.es/ecma262/#sec-string.prototype-@@iterator
			defineIterator(String, 'String', function (iterated) {
			  setInternalState$2(this, {
			    type: STRING_ITERATOR,
			    string: toString_1(iterated),
			    index: 0
			  });
			// `%StringIteratorPrototype%.next` method
			// https://tc39.es/ecma262/#sec-%stringiteratorprototype%.next
			}, function next() {
			  var state = getInternalState(this);
			  var string = state.string;
			  var index = state.index;
			  var point;
			  if (index >= string.length) return { value: undefined, done: true };
			  point = charAt(string, index);
			  state.index += point.length;
			  return { value: point, done: false };
			});

			var ITERATOR$1 = wellKnownSymbol('iterator');

			var nativeUrl = !fails(function () {
			  var url = new URL('b?a=1&b=2&c=3', 'http://a');
			  var searchParams = url.searchParams;
			  var result = '';
			  url.pathname = 'c%20d';
			  searchParams.forEach(function (value, key) {
			    searchParams['delete']('b');
			    result += key + value;
			  });
			  return (isPure && !url.toJSON)
			    || !searchParams.sort
			    || url.href !== 'http://a/c%20d?a=1&c=3'
			    || searchParams.get('c') !== '3'
			    || String(new URLSearchParams('?a=1')) !== 'a=1'
			    || !searchParams[ITERATOR$1]
			    // throws in Edge
			    || new URL('https://a@b').username !== 'a'
			    || new URLSearchParams(new URLSearchParams('a=b')).get('a') !== 'b'
			    // not punycoded in Edge
			    || new URL('http://тест').host !== 'xn--e1aybc'
			    // not escaped in Chrome 62-
			    || new URL('http://a#б').hash !== '#%D0%B1'
			    // fails in Chrome 66-
			    || result !== 'a1c3'
			    // throws in Safari
			    || new URL('http://x', undefined).host !== 'x';
			});

			var anInstance = exports('E', function (it, Constructor, name) {
			  if (!(it instanceof Constructor)) {
			    throw TypeError('Incorrect ' + (name ? name + ' ' : '') + 'invocation');
			  } return it;
			});

			// eslint-disable-next-line es/no-object-assign -- safe
			var $assign = Object.assign;
			// eslint-disable-next-line es/no-object-defineproperty -- required for testing
			var defineProperty = Object.defineProperty;

			// `Object.assign` method
			// https://tc39.es/ecma262/#sec-object.assign
			var objectAssign = !$assign || fails(function () {
			  // should have correct order of operations (Edge bug)
			  if (descriptors && $assign({ b: 1 }, $assign(defineProperty({}, 'a', {
			    enumerable: true,
			    get: function () {
			      defineProperty(this, 'b', {
			        value: 3,
			        enumerable: false
			      });
			    }
			  }), { b: 2 })).b !== 1) return true;
			  // should work with symbols and should have deterministic property order (V8 bug)
			  var A = {};
			  var B = {};
			  // eslint-disable-next-line es/no-symbol -- safe
			  var symbol = Symbol();
			  var alphabet = 'abcdefghijklmnopqrst';
			  A[symbol] = 7;
			  alphabet.split('').forEach(function (chr) { B[chr] = chr; });
			  return $assign({}, A)[symbol] != 7 || objectKeys$1($assign({}, B)).join('') != alphabet;
			}) ? function assign(target, source) { // eslint-disable-line no-unused-vars -- required for `.length`
			  var T = toObject(target);
			  var argumentsLength = arguments.length;
			  var index = 1;
			  var getOwnPropertySymbols = objectGetOwnPropertySymbols.f;
			  var propertyIsEnumerable = objectPropertyIsEnumerable.f;
			  while (argumentsLength > index) {
			    var S = indexedObject(arguments[index++]);
			    var keys = getOwnPropertySymbols ? objectKeys$1(S).concat(getOwnPropertySymbols(S)) : objectKeys$1(S);
			    var length = keys.length;
			    var j = 0;
			    var key;
			    while (length > j) {
			      key = keys[j++];
			      if (!descriptors || propertyIsEnumerable.call(S, key)) T[key] = S[key];
			    }
			  } return T;
			} : $assign;

			// call something on iterator step with safe closing on error
			var callWithSafeIterationClosing = function (iterator, fn, value, ENTRIES) {
			  try {
			    return ENTRIES ? fn(anObject(value)[0], value[1]) : fn(value);
			  } catch (error) {
			    iteratorClose(iterator);
			    throw error;
			  }
			};

			// `Array.from` method implementation
			// https://tc39.es/ecma262/#sec-array.from
			var arrayFrom = function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
			  var O = toObject(arrayLike);
			  var C = typeof this == 'function' ? this : Array;
			  var argumentsLength = arguments.length;
			  var mapfn = argumentsLength > 1 ? arguments[1] : undefined;
			  var mapping = mapfn !== undefined;
			  var iteratorMethod = getIteratorMethod(O);
			  var index = 0;
			  var length, result, step, iterator, next, value;
			  if (mapping) mapfn = functionBindContext(mapfn, argumentsLength > 2 ? arguments[2] : undefined, 2);
			  // if the target is not iterable or it's an array with the default iterator - use a simple case
			  if (iteratorMethod != undefined && !(C == Array && isArrayIteratorMethod(iteratorMethod))) {
			    iterator = iteratorMethod.call(O);
			    next = iterator.next;
			    result = new C();
			    for (;!(step = next.call(iterator)).done; index++) {
			      value = mapping ? callWithSafeIterationClosing(iterator, mapfn, [step.value, index], true) : step.value;
			      createProperty(result, index, value);
			    }
			  } else {
			    length = toLength(O.length);
			    result = new C(length);
			    for (;length > index; index++) {
			      value = mapping ? mapfn(O[index], index) : O[index];
			      createProperty(result, index, value);
			    }
			  }
			  result.length = index;
			  return result;
			};

			// based on https://github.com/bestiejs/punycode.js/blob/master/punycode.js
			var maxInt = 2147483647; // aka. 0x7FFFFFFF or 2^31-1
			var base = 36;
			var tMin = 1;
			var tMax = 26;
			var skew = 38;
			var damp = 700;
			var initialBias = 72;
			var initialN = 128; // 0x80
			var delimiter = '-'; // '\x2D'
			var regexNonASCII = /[^\0-\u007E]/; // non-ASCII chars
			var regexSeparators = /[.\u3002\uFF0E\uFF61]/g; // RFC 3490 separators
			var OVERFLOW_ERROR = 'Overflow: input needs wider integers to process';
			var baseMinusTMin = base - tMin;
			var floor$1 = Math.floor;
			var stringFromCharCode = String.fromCharCode;

			/**
			 * Creates an array containing the numeric code points of each Unicode
			 * character in the string. While JavaScript uses UCS-2 internally,
			 * this function will convert a pair of surrogate halves (each of which
			 * UCS-2 exposes as separate characters) into a single code point,
			 * matching UTF-16.
			 */
			var ucs2decode = function (string) {
			  var output = [];
			  var counter = 0;
			  var length = string.length;
			  while (counter < length) {
			    var value = string.charCodeAt(counter++);
			    if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
			      // It's a high surrogate, and there is a next character.
			      var extra = string.charCodeAt(counter++);
			      if ((extra & 0xFC00) == 0xDC00) { // Low surrogate.
			        output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
			      } else {
			        // It's an unmatched surrogate; only append this code unit, in case the
			        // next code unit is the high surrogate of a surrogate pair.
			        output.push(value);
			        counter--;
			      }
			    } else {
			      output.push(value);
			    }
			  }
			  return output;
			};

			/**
			 * Converts a digit/integer into a basic code point.
			 */
			var digitToBasic = function (digit) {
			  //  0..25 map to ASCII a..z or A..Z
			  // 26..35 map to ASCII 0..9
			  return digit + 22 + 75 * (digit < 26);
			};

			/**
			 * Bias adaptation function as per section 3.4 of RFC 3492.
			 * https://tools.ietf.org/html/rfc3492#section-3.4
			 */
			var adapt = function (delta, numPoints, firstTime) {
			  var k = 0;
			  delta = firstTime ? floor$1(delta / damp) : delta >> 1;
			  delta += floor$1(delta / numPoints);
			  for (; delta > baseMinusTMin * tMax >> 1; k += base) {
			    delta = floor$1(delta / baseMinusTMin);
			  }
			  return floor$1(k + (baseMinusTMin + 1) * delta / (delta + skew));
			};

			/**
			 * Converts a string of Unicode symbols (e.g. a domain name label) to a
			 * Punycode string of ASCII-only symbols.
			 */
			// eslint-disable-next-line max-statements -- TODO
			var encode = function (input) {
			  var output = [];

			  // Convert the input in UCS-2 to an array of Unicode code points.
			  input = ucs2decode(input);

			  // Cache the length.
			  var inputLength = input.length;

			  // Initialize the state.
			  var n = initialN;
			  var delta = 0;
			  var bias = initialBias;
			  var i, currentValue;

			  // Handle the basic code points.
			  for (i = 0; i < input.length; i++) {
			    currentValue = input[i];
			    if (currentValue < 0x80) {
			      output.push(stringFromCharCode(currentValue));
			    }
			  }

			  var basicLength = output.length; // number of basic code points.
			  var handledCPCount = basicLength; // number of code points that have been handled;

			  // Finish the basic string with a delimiter unless it's empty.
			  if (basicLength) {
			    output.push(delimiter);
			  }

			  // Main encoding loop:
			  while (handledCPCount < inputLength) {
			    // All non-basic code points < n have been handled already. Find the next larger one:
			    var m = maxInt;
			    for (i = 0; i < input.length; i++) {
			      currentValue = input[i];
			      if (currentValue >= n && currentValue < m) {
			        m = currentValue;
			      }
			    }

			    // Increase `delta` enough to advance the decoder's <n,i> state to <m,0>, but guard against overflow.
			    var handledCPCountPlusOne = handledCPCount + 1;
			    if (m - n > floor$1((maxInt - delta) / handledCPCountPlusOne)) {
			      throw RangeError(OVERFLOW_ERROR);
			    }

			    delta += (m - n) * handledCPCountPlusOne;
			    n = m;

			    for (i = 0; i < input.length; i++) {
			      currentValue = input[i];
			      if (currentValue < n && ++delta > maxInt) {
			        throw RangeError(OVERFLOW_ERROR);
			      }
			      if (currentValue == n) {
			        // Represent delta as a generalized variable-length integer.
			        var q = delta;
			        for (var k = base; /* no condition */; k += base) {
			          var t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);
			          if (q < t) break;
			          var qMinusT = q - t;
			          var baseMinusT = base - t;
			          output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT)));
			          q = floor$1(qMinusT / baseMinusT);
			        }

			        output.push(stringFromCharCode(digitToBasic(q)));
			        bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
			        delta = 0;
			        ++handledCPCount;
			      }
			    }

			    ++delta;
			    ++n;
			  }
			  return output.join('');
			};

			var stringPunycodeToAscii = function (input) {
			  var encoded = [];
			  var labels = input.toLowerCase().replace(regexSeparators, '\u002E').split('.');
			  var i, label;
			  for (i = 0; i < labels.length; i++) {
			    label = labels[i];
			    encoded.push(regexNonASCII.test(label) ? 'xn--' + encode(label) : label);
			  }
			  return encoded.join('.');
			};

			var redefineAll = exports('z', function (target, src, options) {
			  for (var key in src) redefine(target, key, src[key], options);
			  return target;
			});

			var getIterator = function (it) {
			  var iteratorMethod = getIteratorMethod(it);
			  if (typeof iteratorMethod != 'function') {
			    throw TypeError(String(it) + ' is not iterable');
			  } return anObject(iteratorMethod.call(it));
			};

			// TODO: in core-js@4, move /modules/ dependencies to public entries for better optimization by tools like `preset-env`






















			var nativeFetch = getBuiltIn('fetch');
			var NativeRequest = getBuiltIn('Request');
			var RequestPrototype = NativeRequest && NativeRequest.prototype;
			var Headers = getBuiltIn('Headers');
			var ITERATOR = wellKnownSymbol('iterator');
			var URL_SEARCH_PARAMS = 'URLSearchParams';
			var URL_SEARCH_PARAMS_ITERATOR = URL_SEARCH_PARAMS + 'Iterator';
			var setInternalState$1 = internalState.set;
			var getInternalParamsState = internalState.getterFor(URL_SEARCH_PARAMS);
			var getInternalIteratorState = internalState.getterFor(URL_SEARCH_PARAMS_ITERATOR);

			var plus = /\+/g;
			var sequences = Array(4);

			var percentSequence = function (bytes) {
			  return sequences[bytes - 1] || (sequences[bytes - 1] = RegExp('((?:%[\\da-f]{2}){' + bytes + '})', 'gi'));
			};

			var percentDecode = function (sequence) {
			  try {
			    return decodeURIComponent(sequence);
			  } catch (error) {
			    return sequence;
			  }
			};

			var deserialize = function (it) {
			  var result = it.replace(plus, ' ');
			  var bytes = 4;
			  try {
			    return decodeURIComponent(result);
			  } catch (error) {
			    while (bytes) {
			      result = result.replace(percentSequence(bytes--), percentDecode);
			    }
			    return result;
			  }
			};

			var find = /[!'()~]|%20/g;

			var replace = {
			  '!': '%21',
			  "'": '%27',
			  '(': '%28',
			  ')': '%29',
			  '~': '%7E',
			  '%20': '+'
			};

			var replacer = function (match) {
			  return replace[match];
			};

			var serialize = function (it) {
			  return encodeURIComponent(it).replace(find, replacer);
			};

			var parseSearchParams = function (result, query) {
			  if (query) {
			    var attributes = query.split('&');
			    var index = 0;
			    var attribute, entry;
			    while (index < attributes.length) {
			      attribute = attributes[index++];
			      if (attribute.length) {
			        entry = attribute.split('=');
			        result.push({
			          key: deserialize(entry.shift()),
			          value: deserialize(entry.join('='))
			        });
			      }
			    }
			  }
			};

			var updateSearchParams = function (query) {
			  this.entries.length = 0;
			  parseSearchParams(this.entries, query);
			};

			var validateArgumentsLength = function (passed, required) {
			  if (passed < required) throw TypeError('Not enough arguments');
			};

			var URLSearchParamsIterator = createIteratorConstructor(function Iterator(params, kind) {
			  setInternalState$1(this, {
			    type: URL_SEARCH_PARAMS_ITERATOR,
			    iterator: getIterator(getInternalParamsState(params).entries),
			    kind: kind
			  });
			}, 'Iterator', function next() {
			  var state = getInternalIteratorState(this);
			  var kind = state.kind;
			  var step = state.iterator.next();
			  var entry = step.value;
			  if (!step.done) {
			    step.value = kind === 'keys' ? entry.key : kind === 'values' ? entry.value : [entry.key, entry.value];
			  } return step;
			});

			// `URLSearchParams` constructor
			// https://url.spec.whatwg.org/#interface-urlsearchparams
			var URLSearchParamsConstructor = function URLSearchParams(/* init */) {
			  anInstance(this, URLSearchParamsConstructor, URL_SEARCH_PARAMS);
			  var init = arguments.length > 0 ? arguments[0] : undefined;
			  var that = this;
			  var entries = [];
			  var iteratorMethod, iterator, next, step, entryIterator, entryNext, first, second, key;

			  setInternalState$1(that, {
			    type: URL_SEARCH_PARAMS,
			    entries: entries,
			    updateURL: function () { /* empty */ },
			    updateSearchParams: updateSearchParams
			  });

			  if (init !== undefined) {
			    if (isObject(init)) {
			      iteratorMethod = getIteratorMethod(init);
			      if (typeof iteratorMethod === 'function') {
			        iterator = iteratorMethod.call(init);
			        next = iterator.next;
			        while (!(step = next.call(iterator)).done) {
			          entryIterator = getIterator(anObject(step.value));
			          entryNext = entryIterator.next;
			          if (
			            (first = entryNext.call(entryIterator)).done ||
			            (second = entryNext.call(entryIterator)).done ||
			            !entryNext.call(entryIterator).done
			          ) throw TypeError('Expected sequence with length 2');
			          entries.push({ key: toString_1(first.value), value: toString_1(second.value) });
			        }
			      } else for (key in init) if (has$2(init, key)) entries.push({ key: key, value: toString_1(init[key]) });
			    } else {
			      parseSearchParams(
			        entries,
			        typeof init === 'string' ? init.charAt(0) === '?' ? init.slice(1) : init : toString_1(init)
			      );
			    }
			  }
			};

			var URLSearchParamsPrototype = URLSearchParamsConstructor.prototype;

			redefineAll(URLSearchParamsPrototype, {
			  // `URLSearchParams.prototype.append` method
			  // https://url.spec.whatwg.org/#dom-urlsearchparams-append
			  append: function append(name, value) {
			    validateArgumentsLength(arguments.length, 2);
			    var state = getInternalParamsState(this);
			    state.entries.push({ key: toString_1(name), value: toString_1(value) });
			    state.updateURL();
			  },
			  // `URLSearchParams.prototype.delete` method
			  // https://url.spec.whatwg.org/#dom-urlsearchparams-delete
			  'delete': function (name) {
			    validateArgumentsLength(arguments.length, 1);
			    var state = getInternalParamsState(this);
			    var entries = state.entries;
			    var key = toString_1(name);
			    var index = 0;
			    while (index < entries.length) {
			      if (entries[index].key === key) entries.splice(index, 1);
			      else index++;
			    }
			    state.updateURL();
			  },
			  // `URLSearchParams.prototype.get` method
			  // https://url.spec.whatwg.org/#dom-urlsearchparams-get
			  get: function get(name) {
			    validateArgumentsLength(arguments.length, 1);
			    var entries = getInternalParamsState(this).entries;
			    var key = toString_1(name);
			    var index = 0;
			    for (; index < entries.length; index++) {
			      if (entries[index].key === key) return entries[index].value;
			    }
			    return null;
			  },
			  // `URLSearchParams.prototype.getAll` method
			  // https://url.spec.whatwg.org/#dom-urlsearchparams-getall
			  getAll: function getAll(name) {
			    validateArgumentsLength(arguments.length, 1);
			    var entries = getInternalParamsState(this).entries;
			    var key = toString_1(name);
			    var result = [];
			    var index = 0;
			    for (; index < entries.length; index++) {
			      if (entries[index].key === key) result.push(entries[index].value);
			    }
			    return result;
			  },
			  // `URLSearchParams.prototype.has` method
			  // https://url.spec.whatwg.org/#dom-urlsearchparams-has
			  has: function has(name) {
			    validateArgumentsLength(arguments.length, 1);
			    var entries = getInternalParamsState(this).entries;
			    var key = toString_1(name);
			    var index = 0;
			    while (index < entries.length) {
			      if (entries[index++].key === key) return true;
			    }
			    return false;
			  },
			  // `URLSearchParams.prototype.set` method
			  // https://url.spec.whatwg.org/#dom-urlsearchparams-set
			  set: function set(name, value) {
			    validateArgumentsLength(arguments.length, 1);
			    var state = getInternalParamsState(this);
			    var entries = state.entries;
			    var found = false;
			    var key = toString_1(name);
			    var val = toString_1(value);
			    var index = 0;
			    var entry;
			    for (; index < entries.length; index++) {
			      entry = entries[index];
			      if (entry.key === key) {
			        if (found) entries.splice(index--, 1);
			        else {
			          found = true;
			          entry.value = val;
			        }
			      }
			    }
			    if (!found) entries.push({ key: key, value: val });
			    state.updateURL();
			  },
			  // `URLSearchParams.prototype.sort` method
			  // https://url.spec.whatwg.org/#dom-urlsearchparams-sort
			  sort: function sort() {
			    var state = getInternalParamsState(this);
			    var entries = state.entries;
			    // Array#sort is not stable in some engines
			    var slice = entries.slice();
			    var entry, entriesIndex, sliceIndex;
			    entries.length = 0;
			    for (sliceIndex = 0; sliceIndex < slice.length; sliceIndex++) {
			      entry = slice[sliceIndex];
			      for (entriesIndex = 0; entriesIndex < sliceIndex; entriesIndex++) {
			        if (entries[entriesIndex].key > entry.key) {
			          entries.splice(entriesIndex, 0, entry);
			          break;
			        }
			      }
			      if (entriesIndex === sliceIndex) entries.push(entry);
			    }
			    state.updateURL();
			  },
			  // `URLSearchParams.prototype.forEach` method
			  forEach: function forEach(callback /* , thisArg */) {
			    var entries = getInternalParamsState(this).entries;
			    var boundFunction = functionBindContext(callback, arguments.length > 1 ? arguments[1] : undefined, 3);
			    var index = 0;
			    var entry;
			    while (index < entries.length) {
			      entry = entries[index++];
			      boundFunction(entry.value, entry.key, this);
			    }
			  },
			  // `URLSearchParams.prototype.keys` method
			  keys: function keys() {
			    return new URLSearchParamsIterator(this, 'keys');
			  },
			  // `URLSearchParams.prototype.values` method
			  values: function values() {
			    return new URLSearchParamsIterator(this, 'values');
			  },
			  // `URLSearchParams.prototype.entries` method
			  entries: function entries() {
			    return new URLSearchParamsIterator(this, 'entries');
			  }
			}, { enumerable: true });

			// `URLSearchParams.prototype[@@iterator]` method
			redefine(URLSearchParamsPrototype, ITERATOR, URLSearchParamsPrototype.entries);

			// `URLSearchParams.prototype.toString` method
			// https://url.spec.whatwg.org/#urlsearchparams-stringification-behavior
			redefine(URLSearchParamsPrototype, 'toString', function toString() {
			  var entries = getInternalParamsState(this).entries;
			  var result = [];
			  var index = 0;
			  var entry;
			  while (index < entries.length) {
			    entry = entries[index++];
			    result.push(serialize(entry.key) + '=' + serialize(entry.value));
			  } return result.join('&');
			}, { enumerable: true });

			setToStringTag(URLSearchParamsConstructor, URL_SEARCH_PARAMS);

			_export({ global: true, forced: !nativeUrl }, {
			  URLSearchParams: URLSearchParamsConstructor
			});

			// Wrap `fetch` and `Request` for correct work with polyfilled `URLSearchParams`
			if (!nativeUrl && typeof Headers == 'function') {
			  var wrapRequestOptions = function (init) {
			    if (isObject(init)) {
			      var body = init.body;
			      var headers;
			      if (classof(body) === URL_SEARCH_PARAMS) {
			        headers = init.headers ? new Headers(init.headers) : new Headers();
			        if (!headers.has('content-type')) {
			          headers.set('content-type', 'application/x-www-form-urlencoded;charset=UTF-8');
			        }
			        return objectCreate(init, {
			          body: createPropertyDescriptor(0, String(body)),
			          headers: createPropertyDescriptor(0, headers)
			        });
			      }
			    } return init;
			  };

			  if (typeof nativeFetch == 'function') {
			    _export({ global: true, enumerable: true, forced: true }, {
			      fetch: function fetch(input /* , init */) {
			        return nativeFetch(input, arguments.length > 1 ? wrapRequestOptions(arguments[1]) : {});
			      }
			    });
			  }

			  if (typeof NativeRequest == 'function') {
			    var RequestConstructor = function Request(input /* , init */) {
			      anInstance(this, RequestConstructor, 'Request');
			      return new NativeRequest(input, arguments.length > 1 ? wrapRequestOptions(arguments[1]) : {});
			    };

			    RequestPrototype.constructor = RequestConstructor;
			    RequestConstructor.prototype = RequestPrototype;

			    _export({ global: true, forced: true }, {
			      Request: RequestConstructor
			    });
			  }
			}

			var web_urlSearchParams = {
			  URLSearchParams: URLSearchParamsConstructor,
			  getState: getInternalParamsState
			};

			// TODO: in core-js@4, move /modules/ dependencies to public entries for better optimization by tools like `preset-env`











			var codeAt = stringMultibyte.codeAt;






			var NativeURL = global_1.URL;
			var URLSearchParams$1 = web_urlSearchParams.URLSearchParams;
			var getInternalSearchParamsState = web_urlSearchParams.getState;
			var setInternalState = internalState.set;
			var getInternalURLState = internalState.getterFor('URL');
			var floor = Math.floor;
			var pow = Math.pow;

			var INVALID_AUTHORITY = 'Invalid authority';
			var INVALID_SCHEME = 'Invalid scheme';
			var INVALID_HOST = 'Invalid host';
			var INVALID_PORT = 'Invalid port';

			var ALPHA = /[A-Za-z]/;
			// eslint-disable-next-line regexp/no-obscure-range -- safe
			var ALPHANUMERIC = /[\d+-.A-Za-z]/;
			var DIGIT = /\d/;
			var HEX_START = /^0x/i;
			var OCT = /^[0-7]+$/;
			var DEC = /^\d+$/;
			var HEX = /^[\dA-Fa-f]+$/;
			/* eslint-disable no-control-regex -- safe */
			var FORBIDDEN_HOST_CODE_POINT = /[\0\t\n\r #%/:<>?@[\\\]^|]/;
			var FORBIDDEN_HOST_CODE_POINT_EXCLUDING_PERCENT = /[\0\t\n\r #/:<>?@[\\\]^|]/;
			var LEADING_AND_TRAILING_C0_CONTROL_OR_SPACE = /^[\u0000-\u0020]+|[\u0000-\u0020]+$/g;
			var TAB_AND_NEW_LINE = /[\t\n\r]/g;
			/* eslint-enable no-control-regex -- safe */
			var EOF;

			var parseHost = function (url, input) {
			  var result, codePoints, index;
			  if (input.charAt(0) == '[') {
			    if (input.charAt(input.length - 1) != ']') return INVALID_HOST;
			    result = parseIPv6(input.slice(1, -1));
			    if (!result) return INVALID_HOST;
			    url.host = result;
			  // opaque host
			  } else if (!isSpecial(url)) {
			    if (FORBIDDEN_HOST_CODE_POINT_EXCLUDING_PERCENT.test(input)) return INVALID_HOST;
			    result = '';
			    codePoints = arrayFrom(input);
			    for (index = 0; index < codePoints.length; index++) {
			      result += percentEncode(codePoints[index], C0ControlPercentEncodeSet);
			    }
			    url.host = result;
			  } else {
			    input = stringPunycodeToAscii(input);
			    if (FORBIDDEN_HOST_CODE_POINT.test(input)) return INVALID_HOST;
			    result = parseIPv4(input);
			    if (result === null) return INVALID_HOST;
			    url.host = result;
			  }
			};

			var parseIPv4 = function (input) {
			  var parts = input.split('.');
			  var partsLength, numbers, index, part, radix, number, ipv4;
			  if (parts.length && parts[parts.length - 1] == '') {
			    parts.pop();
			  }
			  partsLength = parts.length;
			  if (partsLength > 4) return input;
			  numbers = [];
			  for (index = 0; index < partsLength; index++) {
			    part = parts[index];
			    if (part == '') return input;
			    radix = 10;
			    if (part.length > 1 && part.charAt(0) == '0') {
			      radix = HEX_START.test(part) ? 16 : 8;
			      part = part.slice(radix == 8 ? 1 : 2);
			    }
			    if (part === '') {
			      number = 0;
			    } else {
			      if (!(radix == 10 ? DEC : radix == 8 ? OCT : HEX).test(part)) return input;
			      number = parseInt(part, radix);
			    }
			    numbers.push(number);
			  }
			  for (index = 0; index < partsLength; index++) {
			    number = numbers[index];
			    if (index == partsLength - 1) {
			      if (number >= pow(256, 5 - partsLength)) return null;
			    } else if (number > 255) return null;
			  }
			  ipv4 = numbers.pop();
			  for (index = 0; index < numbers.length; index++) {
			    ipv4 += numbers[index] * pow(256, 3 - index);
			  }
			  return ipv4;
			};

			// eslint-disable-next-line max-statements -- TODO
			var parseIPv6 = function (input) {
			  var address = [0, 0, 0, 0, 0, 0, 0, 0];
			  var pieceIndex = 0;
			  var compress = null;
			  var pointer = 0;
			  var value, length, numbersSeen, ipv4Piece, number, swaps, swap;

			  var char = function () {
			    return input.charAt(pointer);
			  };

			  if (char() == ':') {
			    if (input.charAt(1) != ':') return;
			    pointer += 2;
			    pieceIndex++;
			    compress = pieceIndex;
			  }
			  while (char()) {
			    if (pieceIndex == 8) return;
			    if (char() == ':') {
			      if (compress !== null) return;
			      pointer++;
			      pieceIndex++;
			      compress = pieceIndex;
			      continue;
			    }
			    value = length = 0;
			    while (length < 4 && HEX.test(char())) {
			      value = value * 16 + parseInt(char(), 16);
			      pointer++;
			      length++;
			    }
			    if (char() == '.') {
			      if (length == 0) return;
			      pointer -= length;
			      if (pieceIndex > 6) return;
			      numbersSeen = 0;
			      while (char()) {
			        ipv4Piece = null;
			        if (numbersSeen > 0) {
			          if (char() == '.' && numbersSeen < 4) pointer++;
			          else return;
			        }
			        if (!DIGIT.test(char())) return;
			        while (DIGIT.test(char())) {
			          number = parseInt(char(), 10);
			          if (ipv4Piece === null) ipv4Piece = number;
			          else if (ipv4Piece == 0) return;
			          else ipv4Piece = ipv4Piece * 10 + number;
			          if (ipv4Piece > 255) return;
			          pointer++;
			        }
			        address[pieceIndex] = address[pieceIndex] * 256 + ipv4Piece;
			        numbersSeen++;
			        if (numbersSeen == 2 || numbersSeen == 4) pieceIndex++;
			      }
			      if (numbersSeen != 4) return;
			      break;
			    } else if (char() == ':') {
			      pointer++;
			      if (!char()) return;
			    } else if (char()) return;
			    address[pieceIndex++] = value;
			  }
			  if (compress !== null) {
			    swaps = pieceIndex - compress;
			    pieceIndex = 7;
			    while (pieceIndex != 0 && swaps > 0) {
			      swap = address[pieceIndex];
			      address[pieceIndex--] = address[compress + swaps - 1];
			      address[compress + --swaps] = swap;
			    }
			  } else if (pieceIndex != 8) return;
			  return address;
			};

			var findLongestZeroSequence = function (ipv6) {
			  var maxIndex = null;
			  var maxLength = 1;
			  var currStart = null;
			  var currLength = 0;
			  var index = 0;
			  for (; index < 8; index++) {
			    if (ipv6[index] !== 0) {
			      if (currLength > maxLength) {
			        maxIndex = currStart;
			        maxLength = currLength;
			      }
			      currStart = null;
			      currLength = 0;
			    } else {
			      if (currStart === null) currStart = index;
			      ++currLength;
			    }
			  }
			  if (currLength > maxLength) {
			    maxIndex = currStart;
			    maxLength = currLength;
			  }
			  return maxIndex;
			};

			var serializeHost = function (host) {
			  var result, index, compress, ignore0;
			  // ipv4
			  if (typeof host == 'number') {
			    result = [];
			    for (index = 0; index < 4; index++) {
			      result.unshift(host % 256);
			      host = floor(host / 256);
			    } return result.join('.');
			  // ipv6
			  } else if (typeof host == 'object') {
			    result = '';
			    compress = findLongestZeroSequence(host);
			    for (index = 0; index < 8; index++) {
			      if (ignore0 && host[index] === 0) continue;
			      if (ignore0) ignore0 = false;
			      if (compress === index) {
			        result += index ? ':' : '::';
			        ignore0 = true;
			      } else {
			        result += host[index].toString(16);
			        if (index < 7) result += ':';
			      }
			    }
			    return '[' + result + ']';
			  } return host;
			};

			var C0ControlPercentEncodeSet = {};
			var fragmentPercentEncodeSet = objectAssign({}, C0ControlPercentEncodeSet, {
			  ' ': 1, '"': 1, '<': 1, '>': 1, '`': 1
			});
			var pathPercentEncodeSet = objectAssign({}, fragmentPercentEncodeSet, {
			  '#': 1, '?': 1, '{': 1, '}': 1
			});
			var userinfoPercentEncodeSet = objectAssign({}, pathPercentEncodeSet, {
			  '/': 1, ':': 1, ';': 1, '=': 1, '@': 1, '[': 1, '\\': 1, ']': 1, '^': 1, '|': 1
			});

			var percentEncode = function (char, set) {
			  var code = codeAt(char, 0);
			  return code > 0x20 && code < 0x7F && !has$2(set, char) ? char : encodeURIComponent(char);
			};

			var specialSchemes = {
			  ftp: 21,
			  file: null,
			  http: 80,
			  https: 443,
			  ws: 80,
			  wss: 443
			};

			var isSpecial = function (url) {
			  return has$2(specialSchemes, url.scheme);
			};

			var includesCredentials = function (url) {
			  return url.username != '' || url.password != '';
			};

			var cannotHaveUsernamePasswordPort = function (url) {
			  return !url.host || url.cannotBeABaseURL || url.scheme == 'file';
			};

			var isWindowsDriveLetter = function (string, normalized) {
			  var second;
			  return string.length == 2 && ALPHA.test(string.charAt(0))
			    && ((second = string.charAt(1)) == ':' || (!normalized && second == '|'));
			};

			var startsWithWindowsDriveLetter = function (string) {
			  var third;
			  return string.length > 1 && isWindowsDriveLetter(string.slice(0, 2)) && (
			    string.length == 2 ||
			    ((third = string.charAt(2)) === '/' || third === '\\' || third === '?' || third === '#')
			  );
			};

			var shortenURLsPath = function (url) {
			  var path = url.path;
			  var pathSize = path.length;
			  if (pathSize && (url.scheme != 'file' || pathSize != 1 || !isWindowsDriveLetter(path[0], true))) {
			    path.pop();
			  }
			};

			var isSingleDot = function (segment) {
			  return segment === '.' || segment.toLowerCase() === '%2e';
			};

			var isDoubleDot = function (segment) {
			  segment = segment.toLowerCase();
			  return segment === '..' || segment === '%2e.' || segment === '.%2e' || segment === '%2e%2e';
			};

			// States:
			var SCHEME_START = {};
			var SCHEME = {};
			var NO_SCHEME = {};
			var SPECIAL_RELATIVE_OR_AUTHORITY = {};
			var PATH_OR_AUTHORITY = {};
			var RELATIVE = {};
			var RELATIVE_SLASH = {};
			var SPECIAL_AUTHORITY_SLASHES = {};
			var SPECIAL_AUTHORITY_IGNORE_SLASHES = {};
			var AUTHORITY = {};
			var HOST = {};
			var HOSTNAME = {};
			var PORT = {};
			var FILE = {};
			var FILE_SLASH = {};
			var FILE_HOST = {};
			var PATH_START = {};
			var PATH = {};
			var CANNOT_BE_A_BASE_URL_PATH = {};
			var QUERY = {};
			var FRAGMENT = {};

			// eslint-disable-next-line max-statements -- TODO
			var parseURL = function (url, input, stateOverride, base) {
			  var state = stateOverride || SCHEME_START;
			  var pointer = 0;
			  var buffer = '';
			  var seenAt = false;
			  var seenBracket = false;
			  var seenPasswordToken = false;
			  var codePoints, char, bufferCodePoints, failure;

			  if (!stateOverride) {
			    url.scheme = '';
			    url.username = '';
			    url.password = '';
			    url.host = null;
			    url.port = null;
			    url.path = [];
			    url.query = null;
			    url.fragment = null;
			    url.cannotBeABaseURL = false;
			    input = input.replace(LEADING_AND_TRAILING_C0_CONTROL_OR_SPACE, '');
			  }

			  input = input.replace(TAB_AND_NEW_LINE, '');

			  codePoints = arrayFrom(input);

			  while (pointer <= codePoints.length) {
			    char = codePoints[pointer];
			    switch (state) {
			      case SCHEME_START:
			        if (char && ALPHA.test(char)) {
			          buffer += char.toLowerCase();
			          state = SCHEME;
			        } else if (!stateOverride) {
			          state = NO_SCHEME;
			          continue;
			        } else return INVALID_SCHEME;
			        break;

			      case SCHEME:
			        if (char && (ALPHANUMERIC.test(char) || char == '+' || char == '-' || char == '.')) {
			          buffer += char.toLowerCase();
			        } else if (char == ':') {
			          if (stateOverride && (
			            (isSpecial(url) != has$2(specialSchemes, buffer)) ||
			            (buffer == 'file' && (includesCredentials(url) || url.port !== null)) ||
			            (url.scheme == 'file' && !url.host)
			          )) return;
			          url.scheme = buffer;
			          if (stateOverride) {
			            if (isSpecial(url) && specialSchemes[url.scheme] == url.port) url.port = null;
			            return;
			          }
			          buffer = '';
			          if (url.scheme == 'file') {
			            state = FILE;
			          } else if (isSpecial(url) && base && base.scheme == url.scheme) {
			            state = SPECIAL_RELATIVE_OR_AUTHORITY;
			          } else if (isSpecial(url)) {
			            state = SPECIAL_AUTHORITY_SLASHES;
			          } else if (codePoints[pointer + 1] == '/') {
			            state = PATH_OR_AUTHORITY;
			            pointer++;
			          } else {
			            url.cannotBeABaseURL = true;
			            url.path.push('');
			            state = CANNOT_BE_A_BASE_URL_PATH;
			          }
			        } else if (!stateOverride) {
			          buffer = '';
			          state = NO_SCHEME;
			          pointer = 0;
			          continue;
			        } else return INVALID_SCHEME;
			        break;

			      case NO_SCHEME:
			        if (!base || (base.cannotBeABaseURL && char != '#')) return INVALID_SCHEME;
			        if (base.cannotBeABaseURL && char == '#') {
			          url.scheme = base.scheme;
			          url.path = base.path.slice();
			          url.query = base.query;
			          url.fragment = '';
			          url.cannotBeABaseURL = true;
			          state = FRAGMENT;
			          break;
			        }
			        state = base.scheme == 'file' ? FILE : RELATIVE;
			        continue;

			      case SPECIAL_RELATIVE_OR_AUTHORITY:
			        if (char == '/' && codePoints[pointer + 1] == '/') {
			          state = SPECIAL_AUTHORITY_IGNORE_SLASHES;
			          pointer++;
			        } else {
			          state = RELATIVE;
			          continue;
			        } break;

			      case PATH_OR_AUTHORITY:
			        if (char == '/') {
			          state = AUTHORITY;
			          break;
			        } else {
			          state = PATH;
			          continue;
			        }

			      case RELATIVE:
			        url.scheme = base.scheme;
			        if (char == EOF) {
			          url.username = base.username;
			          url.password = base.password;
			          url.host = base.host;
			          url.port = base.port;
			          url.path = base.path.slice();
			          url.query = base.query;
			        } else if (char == '/' || (char == '\\' && isSpecial(url))) {
			          state = RELATIVE_SLASH;
			        } else if (char == '?') {
			          url.username = base.username;
			          url.password = base.password;
			          url.host = base.host;
			          url.port = base.port;
			          url.path = base.path.slice();
			          url.query = '';
			          state = QUERY;
			        } else if (char == '#') {
			          url.username = base.username;
			          url.password = base.password;
			          url.host = base.host;
			          url.port = base.port;
			          url.path = base.path.slice();
			          url.query = base.query;
			          url.fragment = '';
			          state = FRAGMENT;
			        } else {
			          url.username = base.username;
			          url.password = base.password;
			          url.host = base.host;
			          url.port = base.port;
			          url.path = base.path.slice();
			          url.path.pop();
			          state = PATH;
			          continue;
			        } break;

			      case RELATIVE_SLASH:
			        if (isSpecial(url) && (char == '/' || char == '\\')) {
			          state = SPECIAL_AUTHORITY_IGNORE_SLASHES;
			        } else if (char == '/') {
			          state = AUTHORITY;
			        } else {
			          url.username = base.username;
			          url.password = base.password;
			          url.host = base.host;
			          url.port = base.port;
			          state = PATH;
			          continue;
			        } break;

			      case SPECIAL_AUTHORITY_SLASHES:
			        state = SPECIAL_AUTHORITY_IGNORE_SLASHES;
			        if (char != '/' || buffer.charAt(pointer + 1) != '/') continue;
			        pointer++;
			        break;

			      case SPECIAL_AUTHORITY_IGNORE_SLASHES:
			        if (char != '/' && char != '\\') {
			          state = AUTHORITY;
			          continue;
			        } break;

			      case AUTHORITY:
			        if (char == '@') {
			          if (seenAt) buffer = '%40' + buffer;
			          seenAt = true;
			          bufferCodePoints = arrayFrom(buffer);
			          for (var i = 0; i < bufferCodePoints.length; i++) {
			            var codePoint = bufferCodePoints[i];
			            if (codePoint == ':' && !seenPasswordToken) {
			              seenPasswordToken = true;
			              continue;
			            }
			            var encodedCodePoints = percentEncode(codePoint, userinfoPercentEncodeSet);
			            if (seenPasswordToken) url.password += encodedCodePoints;
			            else url.username += encodedCodePoints;
			          }
			          buffer = '';
			        } else if (
			          char == EOF || char == '/' || char == '?' || char == '#' ||
			          (char == '\\' && isSpecial(url))
			        ) {
			          if (seenAt && buffer == '') return INVALID_AUTHORITY;
			          pointer -= arrayFrom(buffer).length + 1;
			          buffer = '';
			          state = HOST;
			        } else buffer += char;
			        break;

			      case HOST:
			      case HOSTNAME:
			        if (stateOverride && url.scheme == 'file') {
			          state = FILE_HOST;
			          continue;
			        } else if (char == ':' && !seenBracket) {
			          if (buffer == '') return INVALID_HOST;
			          failure = parseHost(url, buffer);
			          if (failure) return failure;
			          buffer = '';
			          state = PORT;
			          if (stateOverride == HOSTNAME) return;
			        } else if (
			          char == EOF || char == '/' || char == '?' || char == '#' ||
			          (char == '\\' && isSpecial(url))
			        ) {
			          if (isSpecial(url) && buffer == '') return INVALID_HOST;
			          if (stateOverride && buffer == '' && (includesCredentials(url) || url.port !== null)) return;
			          failure = parseHost(url, buffer);
			          if (failure) return failure;
			          buffer = '';
			          state = PATH_START;
			          if (stateOverride) return;
			          continue;
			        } else {
			          if (char == '[') seenBracket = true;
			          else if (char == ']') seenBracket = false;
			          buffer += char;
			        } break;

			      case PORT:
			        if (DIGIT.test(char)) {
			          buffer += char;
			        } else if (
			          char == EOF || char == '/' || char == '?' || char == '#' ||
			          (char == '\\' && isSpecial(url)) ||
			          stateOverride
			        ) {
			          if (buffer != '') {
			            var port = parseInt(buffer, 10);
			            if (port > 0xFFFF) return INVALID_PORT;
			            url.port = (isSpecial(url) && port === specialSchemes[url.scheme]) ? null : port;
			            buffer = '';
			          }
			          if (stateOverride) return;
			          state = PATH_START;
			          continue;
			        } else return INVALID_PORT;
			        break;

			      case FILE:
			        url.scheme = 'file';
			        if (char == '/' || char == '\\') state = FILE_SLASH;
			        else if (base && base.scheme == 'file') {
			          if (char == EOF) {
			            url.host = base.host;
			            url.path = base.path.slice();
			            url.query = base.query;
			          } else if (char == '?') {
			            url.host = base.host;
			            url.path = base.path.slice();
			            url.query = '';
			            state = QUERY;
			          } else if (char == '#') {
			            url.host = base.host;
			            url.path = base.path.slice();
			            url.query = base.query;
			            url.fragment = '';
			            state = FRAGMENT;
			          } else {
			            if (!startsWithWindowsDriveLetter(codePoints.slice(pointer).join(''))) {
			              url.host = base.host;
			              url.path = base.path.slice();
			              shortenURLsPath(url);
			            }
			            state = PATH;
			            continue;
			          }
			        } else {
			          state = PATH;
			          continue;
			        } break;

			      case FILE_SLASH:
			        if (char == '/' || char == '\\') {
			          state = FILE_HOST;
			          break;
			        }
			        if (base && base.scheme == 'file' && !startsWithWindowsDriveLetter(codePoints.slice(pointer).join(''))) {
			          if (isWindowsDriveLetter(base.path[0], true)) url.path.push(base.path[0]);
			          else url.host = base.host;
			        }
			        state = PATH;
			        continue;

			      case FILE_HOST:
			        if (char == EOF || char == '/' || char == '\\' || char == '?' || char == '#') {
			          if (!stateOverride && isWindowsDriveLetter(buffer)) {
			            state = PATH;
			          } else if (buffer == '') {
			            url.host = '';
			            if (stateOverride) return;
			            state = PATH_START;
			          } else {
			            failure = parseHost(url, buffer);
			            if (failure) return failure;
			            if (url.host == 'localhost') url.host = '';
			            if (stateOverride) return;
			            buffer = '';
			            state = PATH_START;
			          } continue;
			        } else buffer += char;
			        break;

			      case PATH_START:
			        if (isSpecial(url)) {
			          state = PATH;
			          if (char != '/' && char != '\\') continue;
			        } else if (!stateOverride && char == '?') {
			          url.query = '';
			          state = QUERY;
			        } else if (!stateOverride && char == '#') {
			          url.fragment = '';
			          state = FRAGMENT;
			        } else if (char != EOF) {
			          state = PATH;
			          if (char != '/') continue;
			        } break;

			      case PATH:
			        if (
			          char == EOF || char == '/' ||
			          (char == '\\' && isSpecial(url)) ||
			          (!stateOverride && (char == '?' || char == '#'))
			        ) {
			          if (isDoubleDot(buffer)) {
			            shortenURLsPath(url);
			            if (char != '/' && !(char == '\\' && isSpecial(url))) {
			              url.path.push('');
			            }
			          } else if (isSingleDot(buffer)) {
			            if (char != '/' && !(char == '\\' && isSpecial(url))) {
			              url.path.push('');
			            }
			          } else {
			            if (url.scheme == 'file' && !url.path.length && isWindowsDriveLetter(buffer)) {
			              if (url.host) url.host = '';
			              buffer = buffer.charAt(0) + ':'; // normalize windows drive letter
			            }
			            url.path.push(buffer);
			          }
			          buffer = '';
			          if (url.scheme == 'file' && (char == EOF || char == '?' || char == '#')) {
			            while (url.path.length > 1 && url.path[0] === '') {
			              url.path.shift();
			            }
			          }
			          if (char == '?') {
			            url.query = '';
			            state = QUERY;
			          } else if (char == '#') {
			            url.fragment = '';
			            state = FRAGMENT;
			          }
			        } else {
			          buffer += percentEncode(char, pathPercentEncodeSet);
			        } break;

			      case CANNOT_BE_A_BASE_URL_PATH:
			        if (char == '?') {
			          url.query = '';
			          state = QUERY;
			        } else if (char == '#') {
			          url.fragment = '';
			          state = FRAGMENT;
			        } else if (char != EOF) {
			          url.path[0] += percentEncode(char, C0ControlPercentEncodeSet);
			        } break;

			      case QUERY:
			        if (!stateOverride && char == '#') {
			          url.fragment = '';
			          state = FRAGMENT;
			        } else if (char != EOF) {
			          if (char == "'" && isSpecial(url)) url.query += '%27';
			          else if (char == '#') url.query += '%23';
			          else url.query += percentEncode(char, C0ControlPercentEncodeSet);
			        } break;

			      case FRAGMENT:
			        if (char != EOF) url.fragment += percentEncode(char, fragmentPercentEncodeSet);
			        break;
			    }

			    pointer++;
			  }
			};

			// `URL` constructor
			// https://url.spec.whatwg.org/#url-class
			var URLConstructor = function URL(url /* , base */) {
			  var that = anInstance(this, URLConstructor, 'URL');
			  var base = arguments.length > 1 ? arguments[1] : undefined;
			  var urlString = toString_1(url);
			  var state = setInternalState(that, { type: 'URL' });
			  var baseState, failure;
			  if (base !== undefined) {
			    if (base instanceof URLConstructor) baseState = getInternalURLState(base);
			    else {
			      failure = parseURL(baseState = {}, toString_1(base));
			      if (failure) throw TypeError(failure);
			    }
			  }
			  failure = parseURL(state, urlString, null, baseState);
			  if (failure) throw TypeError(failure);
			  var searchParams = state.searchParams = new URLSearchParams$1();
			  var searchParamsState = getInternalSearchParamsState(searchParams);
			  searchParamsState.updateSearchParams(state.query);
			  searchParamsState.updateURL = function () {
			    state.query = String(searchParams) || null;
			  };
			  if (!descriptors) {
			    that.href = serializeURL.call(that);
			    that.origin = getOrigin.call(that);
			    that.protocol = getProtocol.call(that);
			    that.username = getUsername.call(that);
			    that.password = getPassword.call(that);
			    that.host = getHost.call(that);
			    that.hostname = getHostname.call(that);
			    that.port = getPort.call(that);
			    that.pathname = getPathname.call(that);
			    that.search = getSearch.call(that);
			    that.searchParams = getSearchParams.call(that);
			    that.hash = getHash.call(that);
			  }
			};

			var URLPrototype = URLConstructor.prototype;

			var serializeURL = function () {
			  var url = getInternalURLState(this);
			  var scheme = url.scheme;
			  var username = url.username;
			  var password = url.password;
			  var host = url.host;
			  var port = url.port;
			  var path = url.path;
			  var query = url.query;
			  var fragment = url.fragment;
			  var output = scheme + ':';
			  if (host !== null) {
			    output += '//';
			    if (includesCredentials(url)) {
			      output += username + (password ? ':' + password : '') + '@';
			    }
			    output += serializeHost(host);
			    if (port !== null) output += ':' + port;
			  } else if (scheme == 'file') output += '//';
			  output += url.cannotBeABaseURL ? path[0] : path.length ? '/' + path.join('/') : '';
			  if (query !== null) output += '?' + query;
			  if (fragment !== null) output += '#' + fragment;
			  return output;
			};

			var getOrigin = function () {
			  var url = getInternalURLState(this);
			  var scheme = url.scheme;
			  var port = url.port;
			  if (scheme == 'blob') try {
			    return new URLConstructor(scheme.path[0]).origin;
			  } catch (error) {
			    return 'null';
			  }
			  if (scheme == 'file' || !isSpecial(url)) return 'null';
			  return scheme + '://' + serializeHost(url.host) + (port !== null ? ':' + port : '');
			};

			var getProtocol = function () {
			  return getInternalURLState(this).scheme + ':';
			};

			var getUsername = function () {
			  return getInternalURLState(this).username;
			};

			var getPassword = function () {
			  return getInternalURLState(this).password;
			};

			var getHost = function () {
			  var url = getInternalURLState(this);
			  var host = url.host;
			  var port = url.port;
			  return host === null ? ''
			    : port === null ? serializeHost(host)
			    : serializeHost(host) + ':' + port;
			};

			var getHostname = function () {
			  var host = getInternalURLState(this).host;
			  return host === null ? '' : serializeHost(host);
			};

			var getPort = function () {
			  var port = getInternalURLState(this).port;
			  return port === null ? '' : String(port);
			};

			var getPathname = function () {
			  var url = getInternalURLState(this);
			  var path = url.path;
			  return url.cannotBeABaseURL ? path[0] : path.length ? '/' + path.join('/') : '';
			};

			var getSearch = function () {
			  var query = getInternalURLState(this).query;
			  return query ? '?' + query : '';
			};

			var getSearchParams = function () {
			  return getInternalURLState(this).searchParams;
			};

			var getHash = function () {
			  var fragment = getInternalURLState(this).fragment;
			  return fragment ? '#' + fragment : '';
			};

			var accessorDescriptor = function (getter, setter) {
			  return { get: getter, set: setter, configurable: true, enumerable: true };
			};

			if (descriptors) {
			  objectDefineProperties(URLPrototype, {
			    // `URL.prototype.href` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-href
			    href: accessorDescriptor(serializeURL, function (href) {
			      var url = getInternalURLState(this);
			      var urlString = toString_1(href);
			      var failure = parseURL(url, urlString);
			      if (failure) throw TypeError(failure);
			      getInternalSearchParamsState(url.searchParams).updateSearchParams(url.query);
			    }),
			    // `URL.prototype.origin` getter
			    // https://url.spec.whatwg.org/#dom-url-origin
			    origin: accessorDescriptor(getOrigin),
			    // `URL.prototype.protocol` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-protocol
			    protocol: accessorDescriptor(getProtocol, function (protocol) {
			      var url = getInternalURLState(this);
			      parseURL(url, toString_1(protocol) + ':', SCHEME_START);
			    }),
			    // `URL.prototype.username` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-username
			    username: accessorDescriptor(getUsername, function (username) {
			      var url = getInternalURLState(this);
			      var codePoints = arrayFrom(toString_1(username));
			      if (cannotHaveUsernamePasswordPort(url)) return;
			      url.username = '';
			      for (var i = 0; i < codePoints.length; i++) {
			        url.username += percentEncode(codePoints[i], userinfoPercentEncodeSet);
			      }
			    }),
			    // `URL.prototype.password` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-password
			    password: accessorDescriptor(getPassword, function (password) {
			      var url = getInternalURLState(this);
			      var codePoints = arrayFrom(toString_1(password));
			      if (cannotHaveUsernamePasswordPort(url)) return;
			      url.password = '';
			      for (var i = 0; i < codePoints.length; i++) {
			        url.password += percentEncode(codePoints[i], userinfoPercentEncodeSet);
			      }
			    }),
			    // `URL.prototype.host` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-host
			    host: accessorDescriptor(getHost, function (host) {
			      var url = getInternalURLState(this);
			      if (url.cannotBeABaseURL) return;
			      parseURL(url, toString_1(host), HOST);
			    }),
			    // `URL.prototype.hostname` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-hostname
			    hostname: accessorDescriptor(getHostname, function (hostname) {
			      var url = getInternalURLState(this);
			      if (url.cannotBeABaseURL) return;
			      parseURL(url, toString_1(hostname), HOSTNAME);
			    }),
			    // `URL.prototype.port` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-port
			    port: accessorDescriptor(getPort, function (port) {
			      var url = getInternalURLState(this);
			      if (cannotHaveUsernamePasswordPort(url)) return;
			      port = toString_1(port);
			      if (port == '') url.port = null;
			      else parseURL(url, port, PORT);
			    }),
			    // `URL.prototype.pathname` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-pathname
			    pathname: accessorDescriptor(getPathname, function (pathname) {
			      var url = getInternalURLState(this);
			      if (url.cannotBeABaseURL) return;
			      url.path = [];
			      parseURL(url, toString_1(pathname), PATH_START);
			    }),
			    // `URL.prototype.search` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-search
			    search: accessorDescriptor(getSearch, function (search) {
			      var url = getInternalURLState(this);
			      search = toString_1(search);
			      if (search == '') {
			        url.query = null;
			      } else {
			        if ('?' == search.charAt(0)) search = search.slice(1);
			        url.query = '';
			        parseURL(url, search, QUERY);
			      }
			      getInternalSearchParamsState(url.searchParams).updateSearchParams(url.query);
			    }),
			    // `URL.prototype.searchParams` getter
			    // https://url.spec.whatwg.org/#dom-url-searchparams
			    searchParams: accessorDescriptor(getSearchParams),
			    // `URL.prototype.hash` accessors pair
			    // https://url.spec.whatwg.org/#dom-url-hash
			    hash: accessorDescriptor(getHash, function (hash) {
			      var url = getInternalURLState(this);
			      hash = toString_1(hash);
			      if (hash == '') {
			        url.fragment = null;
			        return;
			      }
			      if ('#' == hash.charAt(0)) hash = hash.slice(1);
			      url.fragment = '';
			      parseURL(url, hash, FRAGMENT);
			    })
			  });
			}

			// `URL.prototype.toJSON` method
			// https://url.spec.whatwg.org/#dom-url-tojson
			redefine(URLPrototype, 'toJSON', function toJSON() {
			  return serializeURL.call(this);
			}, { enumerable: true });

			// `URL.prototype.toString` method
			// https://url.spec.whatwg.org/#URL-stringification-behavior
			redefine(URLPrototype, 'toString', function toString() {
			  return serializeURL.call(this);
			}, { enumerable: true });

			if (NativeURL) {
			  var nativeCreateObjectURL = NativeURL.createObjectURL;
			  var nativeRevokeObjectURL = NativeURL.revokeObjectURL;
			  // `URL.createObjectURL` method
			  // https://developer.mozilla.org/en-US/docs/Web/API/URL/createObjectURL
			  // eslint-disable-next-line no-unused-vars -- required for `.length`
			  if (nativeCreateObjectURL) redefine(URLConstructor, 'createObjectURL', function createObjectURL(blob) {
			    return nativeCreateObjectURL.apply(NativeURL, arguments);
			  });
			  // `URL.revokeObjectURL` method
			  // https://developer.mozilla.org/en-US/docs/Web/API/URL/revokeObjectURL
			  // eslint-disable-next-line no-unused-vars -- required for `.length`
			  if (nativeRevokeObjectURL) redefine(URLConstructor, 'revokeObjectURL', function revokeObjectURL(url) {
			    return nativeRevokeObjectURL.apply(NativeURL, arguments);
			  });
			}

			setToStringTag(URLConstructor, 'URL');

			_export({ global: true, forced: !nativeUrl, sham: !descriptors }, {
			  URL: URLConstructor
			});

			// `URL.prototype.toJSON` method
			// https://url.spec.whatwg.org/#dom-url-tojson
			_export({ target: 'URL', proto: true, enumerable: true }, {
			  toJSON: function toJSON() {
			    return URL.prototype.toString.call(this);
			  }
			});

			path.URL;

			var FrameworkType; exports('L', FrameworkType);
			(function (FrameworkType) {
			    FrameworkType["VueForFlutterPage"] = "VueForFlutterPage";
			    FrameworkType["Vue3ForFlutterPage"] = "Vue3ForFlutterPage";
			    FrameworkType["ReactForFlutterPage"] = "ReactForFlutterPage";
			    FrameworkType["VueForWebPage"] = "VueForWebPage";
			    FrameworkType["VuexForStore"] = "VuexForStore";
			    FrameworkType["NotFramework"] = "NotFramework";
			})(FrameworkType || (exports('L', FrameworkType = {})));

		}
	};
});
